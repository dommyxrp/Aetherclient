package net.spectre.client.module.impl.misc;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.spectre.client.builder.AhBuyerService;
import net.spectre.client.builder.MaterialPlan;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.gui.BuilderPanel;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public final class AutoAhBuyerModule extends ClientModule {
    public static volatile AutoAhBuyerModule active;

    private final NumberSetting delay = this.addSetting("delay", new NumberSetting("Action Delay (ticks)", 12.0F, 4.0F, 40.0F).step(1.0F));
    private final BooleanSetting autoConfirm = this.addSetting("auto-confirm", new BooleanSetting("Auto Confirm Purchase", true));
    private final BooleanSetting autoPack = this.addSetting("auto-pack", new BooleanSetting("Auto Pack Shulkers", true));
    private final NumberSetting maxPrice = this.addSetting("max-price", new NumberSetting("Max Unit Price", 0.0F, 0.0F, 1000000.0F).step(1000.0F));
    private final BooleanSetting useUnderscores = this.addSetting("use-underscores", new BooleanSetting("Underscore Search", false));

    public AutoAhBuyerModule() {
        super("ah-buyer", "AH Auto Buyer", "Automatically searches /ah for schematic materials, purchases needed amounts, and organizes them into shulkers.", ModuleCategory.DONUT);
    }

    @Override
    protected void onEnable() {
        active = this;
        syncSettings();

        MaterialPlan plan = BuilderPanel.currentMaterials();
        if (plan == null || plan.rows().isEmpty()) {
            ModuleChat.send(this, ModuleChat.body().danger("No schematic loaded").text(". Import or open a schematic in ").name("Base Builder").text(" first!"));
            this.setEnabled(false);
            return;
        }

        AhBuyerService.INSTANCE.start(plan);
        this.on(TickEvent.TYPE, this::onTick);
    }

    @Override
    protected void onDisable() {
        active = null;
        if (AhBuyerService.INSTANCE.running()) {
            AhBuyerService.INSTANCE.stop();
        }
    }

    private void syncSettings() {
        AhBuyerService.INSTANCE.setActionDelayTicks((int) this.delay.get());
        AhBuyerService.INSTANCE.setAutoConfirm(this.autoConfirm.get());
        AhBuyerService.INSTANCE.setAutoPackShulkers(this.autoPack.get());
        AhBuyerService.INSTANCE.setMaxPricePerItem(this.maxPrice.get());
        AhBuyerService.INSTANCE.setUseUnderscores(this.useUnderscores.get());
    }

    private void onTick(TickEvent event) {
        if (!this.isEnabled()) return;
        syncSettings();

        if (!AhBuyerService.INSTANCE.running() && AhBuyerService.INSTANCE.getState() == AhBuyerService.State.FINISHED) {
            ModuleChat.send(this, ModuleChat.body().good("All schematic materials").text(" sourced and packed into shulkers!"));
            this.setEnabled(false);
        } else if (!AhBuyerService.INSTANCE.running() && AhBuyerService.INSTANCE.getState() == AhBuyerService.State.IDLE) {
            this.setEnabled(false);
        }
    }
}
