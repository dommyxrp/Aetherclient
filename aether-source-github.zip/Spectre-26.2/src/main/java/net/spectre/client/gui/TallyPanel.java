package net.spectre.client.gui;

import dev.doughbay.core.model.MarketStats;
import dev.doughbay.core.model.Opportunity;
import dev.doughbay.fabric.DoughBayClient;
import dev.doughbay.fabric.MarketWatcher;
import dev.doughbay.fabric.PerformanceStatsSnapshot;
import dev.doughbay.fabric.TallyBridge;
import dev.doughbay.fabric.automation.AutomationSessionController;
import imgui.ImColor;
import imgui.ImDrawList;
import imgui.ImGui;
import imgui.type.ImBoolean;
import imgui.type.ImFloat;
import imgui.type.ImString;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.spectre.client.tally.TallyPresets;

/**
 * Native In-Client Subpanel and Trading Desk for Tally / GoNuts on DonutSMP.
 * Directly integrates with Tally's core automation engine, market watcher,
 * capital ledger, and execution driver.
 */
public final class TallyPanel {

    private static int studioColor(int rgb, float alpha) {
        int a = (int) (Math.max(0, Math.min(1, alpha)) * 255);
        return GuiPalette.abgr((a << 24) | (rgb & 0xFFFFFF));
    }

    private static void studioText(ImDrawList dl, float x, float y, String text, int rgb) {
        dl.addText(x, y, studioColor(rgb, 1.0f), text);
    }

    private static boolean openRequested = false;
    private static int activeTab = 0; // 0=Dashboard, 1=Opportunities, 2=Markets, 3=AutoPilot, 4=API & Settings

    private static final ImString searchFilter = new ImString(64);
    private static final ImString apiKeyDraft = new ImString(128);
    private static final ImBoolean showApiKey = new ImBoolean(false);
    private static final ImFloat minProfitFilter = new ImFloat(5000);
    private static final ImFloat minRoiFilter = new ImFloat(10.0f);
    private static final ImFloat maxPerTradeM = new ImFloat(25.0f);
    private static final ImFloat maxPerSessionM = new ImFloat(100.0f);

    private static String statusNotice = "";
    private static long statusNoticeAt = 0;

    private TallyPanel() {}

    public static void ensureTallyInitialized() {
        TallyBridge.ensureInitialized();
    }

    public static void openNativeDesk() {
        TallyBridge.openDoughBayScreen(Minecraft.getInstance());
    }

    public static void open() {
        openRequested = true;
        ensureTallyInitialized();
        var cfg = DoughBayClient.activeConfig();
        if (cfg != null && apiKeyDraft.get().isBlank() && cfg.apiKey() != null) {
            apiKeyDraft.set(cfg.apiKey());
        }
    }

    public static boolean takeOpenRequest() {
        boolean req = openRequested;
        openRequested = false;
        return req;
    }

    public static void setNotice(String text) {
        statusNotice = text;
        statusNoticeAt = System.currentTimeMillis();
    }

    public static void setLimits(float tradeM, float sessionM, float minProfit, float minRoi) {
        maxPerTradeM.set(tradeM);
        maxPerSessionM.set(sessionM);
        minProfitFilter.set(minProfit);
        minRoiFilter.set(minRoi);
    }

    public static String formatMoney(long amount) {
        if (Math.abs(amount) >= 1_000_000_000L) {
            return String.format(Locale.ROOT, "%.2fB", amount / 1_000_000_000.0);
        }
        if (Math.abs(amount) >= 1_000_000L) {
            return String.format(Locale.ROOT, "%.2fM", amount / 1_000_000.0);
        }
        if (Math.abs(amount) >= 1_000L) {
            return String.format(Locale.ROOT, "%.1fK", amount / 1_000.0);
        }
        return String.format(Locale.ROOT, "%,d", amount);
    }

    public static String formatItemName(String itemKey) {
        if (itemKey == null || itemKey.isBlank()) return "Unknown Item";
        String clean = itemKey.replace("minecraft:", "").replace('_', ' ').toLowerCase(Locale.ROOT);
        String[] parts = clean.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (!p.isBlank()) {
                sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(" ");
            }
        }
        return sb.toString().trim();
    }

    public static void renderContents() {
        ensureTallyInitialized();

        var sessionSnap = TallyBridge.sessionSnapshot();
        var marketSnap = TallyBridge.marketSnapshot();
        var ledgerSnap = TallyBridge.ledgerSnapshot();

        float availW = ImGui.getContentRegionAvailX();
        float availH = ImGui.getContentRegionAvailY();

        ImDrawList dl = ImGui.getWindowDrawList();
        float startX = ImGui.getCursorScreenPosX();
        float startY = ImGui.getCursorScreenPosY();

        // 1. Header Card
        renderHeader(dl, startX, startY, availW, sessionSnap, marketSnap);

        // Explicitly restore local cursor to left edge (x = 8) under the header card (y = 74)
        ImGui.setCursorPos(8, 74);

        // 2. Tab Navigation Bar
        renderTabBar(availW - 16);
        ImGui.setCursorPosX(8);
        ImGui.separator();
        ImGui.dummy(0, 4);

        // 3. Main Body Tabs
        float contentW = availW - 16;
        float contentH = Math.max(120, ImGui.getContentRegionAvailY() - 8);
        ImGui.setCursorPosX(8);
        if (ImGui.beginChild("##tally_tab_content", contentW, contentH, false)) {
            switch (activeTab) {
                case 0 -> renderDashboardTab(sessionSnap, marketSnap, ledgerSnap);
                case 1 -> renderOpportunitiesTab(marketSnap);
                case 2 -> renderMarketsTab(marketSnap);
                case 3 -> renderAutoPilotTab(sessionSnap);
                case 4 -> renderSettingsTab(marketSnap);
            }
        }
        ImGui.endChild();
    }

    private static void renderHeader(ImDrawList dl, float x, float y, float w,
                                     AutomationSessionController.SessionSnapshot session,
                                     MarketWatcher.Snapshot market) {
        float h = 64;
        dl.addRectFilled(x, y, x + w, y + h, ImColor.rgba(12, 20, 32, 240), 8);
        dl.addRect(x, y, x + w, y + h, ImColor.rgba(27, 44, 66, 255), 8, 0, 1.0f);
        dl.addLine(x + 14, y, x + 160, y, ImColor.rgba(114, 230, 239, 200), 2.0f);

        // Title and Subtitle
        studioText(dl, x + 16, y + 14, "TALLY TRADING DESK", 0xFFF8FAFC);
        String sub = session != null && !session.detail().isBlank()
                ? session.detail()
                : "Live DonutSMP Auction Intelligence & Automated Trading Engine";
        studioText(dl, x + 16, y + 36, SpectreWidgets.ellipsize(ImGui.getFont(), sub, w * 0.45f), 0xFF94A3B8);

        // Right side buttons and status
        float rx = x + w - 16;

        // Open Native Tally Screen button
        float deskW = 125, btnH = 28;
        rx -= deskW;
        ImGui.setCursorScreenPos(rx, y + 18);
        ImGui.pushStyleColor(21, ImColor.rgba(18, 38, 58, 255));
        ImGui.pushStyleColor(22, ImColor.rgba(26, 52, 78, 255));
        if (ImGui.button("Native Desk ##tally_native_desk", deskW, btnH)) {
            openNativeDesk();
        }
        ImGui.popStyleColor(2);

        // Autopilot Toggle Button
        boolean active = session != null && session.active();
        float autoW = 140;
        rx -= (autoW + 8);
        ImGui.setCursorScreenPos(rx, y + 18);
        if (active) {
            ImGui.pushStyleColor(21, ImColor.rgba(220, 38, 38, 255));
            ImGui.pushStyleColor(22, ImColor.rgba(239, 68, 68, 255));
            if (ImGui.button("STOP AUTOPILOT", autoW, btnH)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) c.emergencyStop();
                setNotice("Autopilot stopped by user");
            }
            ImGui.popStyleColor(2);
        } else {
            ImGui.pushStyleColor(21, ImColor.rgba(16, 185, 129, 255));
            ImGui.pushStyleColor(22, ImColor.rgba(5, 150, 105, 255));
            if (ImGui.button("START AUTOPILOT", autoW, btnH)) {
                if (net.spectre.client.module.impl.misc.TallyModule.instance() != null
                        && !net.spectre.client.module.impl.misc.TallyModule.instance().isEnabled()) {
                    net.spectre.client.module.impl.misc.TallyModule.instance().setEnabled(true);
                }
                startContinuousTrading();
            }
            ImGui.popStyleColor(2);
        }

        // Module Active Toggle (Controls on-screen GoNuts HUD & module state)
        boolean modEnabled = net.spectre.client.module.impl.misc.TallyModule.isModuleEnabled();
        float modW = 115;
        rx -= (modW + 8);
        ImGui.setCursorScreenPos(rx, y + 18);
        if (modEnabled) {
            ImGui.pushStyleColor(21, ImColor.rgba(14, 165, 233, 255));
            ImGui.pushStyleColor(22, ImColor.rgba(2, 132, 199, 255));
            if (ImGui.button("HUD / MOD: ON", modW, btnH)) {
                if (net.spectre.client.module.impl.misc.TallyModule.instance() != null) {
                    net.spectre.client.module.impl.misc.TallyModule.instance().setEnabled(false);
                }
            }
            ImGui.popStyleColor(2);
        } else {
            ImGui.pushStyleColor(21, ImColor.rgba(30, 41, 59, 255));
            ImGui.pushStyleColor(22, ImColor.rgba(51, 65, 85, 255));
            if (ImGui.button("HUD / MOD: OFF", modW, btnH)) {
                if (net.spectre.client.module.impl.misc.TallyModule.instance() != null) {
                    net.spectre.client.module.impl.misc.TallyModule.instance().setEnabled(true);
                }
            }
            ImGui.popStyleColor(2);
        }

        // Session State Pill
        rx -= 120;
        String stateName = session != null ? session.state().name() : "OFFLINE";
        int stateCol = switch (stateName) {
            case "SCANNING", "BUYING", "LISTING", "MONITORING" -> 0xFF10B981;
            case "PAUSED", "COOLDOWN", "AUDITING_SLOTS", "READING_ORDERS", "BID_DESK", "REPRICING" -> 0xFFF59E0B;
            default -> 0xFF64748B;
        };
        dl.addRectFilled(rx, y + 20, rx + 110, y + 44, (stateCol & 0x00FFFFFF) | 0x22000000, 6);
        dl.addRect(rx, y + 20, rx + 110, y + 44, stateCol, 6);
        studioText(dl, rx + 12, y + 25, stateName, stateCol);
    }

    private static void renderTabBar(float w) {
        String[] tabs = {"Dashboard", "Opportunities", "Markets", "AutoPilot", "API & Settings"};
        float gap = 6;
        float tabW = Math.max(90, Math.min(145, (w - gap * (tabs.length - 1)) / tabs.length));
        for (int i = 0; i < tabs.length; i++) {
            if (i > 0) ImGui.sameLine(0, gap);
            boolean isCur = activeTab == i;
            if (isCur) {
                ImGui.pushStyleColor(21, ImColor.rgba(14, 165, 233, 230)); // bright cyan/sky
                ImGui.pushStyleColor(22, ImColor.rgba(2, 132, 199, 255));
                ImGui.pushStyleColor(23, ImColor.rgba(56, 189, 248, 255));
            } else {
                ImGui.pushStyleColor(21, ImColor.rgba(15, 23, 42, 220)); // obsidian/slate
                ImGui.pushStyleColor(22, ImColor.rgba(30, 41, 59, 255));
                ImGui.pushStyleColor(23, ImColor.rgba(51, 65, 85, 255));
            }
            if (ImGui.button(tabs[i] + "##tab_" + i, tabW, 28)) {
                activeTab = i;
            }
            ImGui.popStyleColor(3);
        }
    }

    private static void renderDashboardTab(AutomationSessionController.SessionSnapshot session,
                                           MarketWatcher.Snapshot market,
                                           PerformanceStatsSnapshot ledger) {
        float availW = ImGui.getContentRegionAvailX();
        int cols = availW >= 640 ? 4 : 2;
        float cardW = (availW - 8 * (cols - 1)) / cols;

        ImDrawList dl = ImGui.getWindowDrawList();
        float cx = ImGui.getCursorScreenPosX();
        float cy = ImGui.getCursorScreenPosY();

        // 1. Row of 4 KPI Metric Cards
        long profit = ledger != null ? ledger.realizedProfit() : 0;
        int sales = ledger != null ? ledger.completedSales() : 0;
        int profitable = ledger != null ? ledger.profitableSales() : 0;
        double winRate = sales > 0 ? (profitable * 100.0 / sales) : 100.0;
        int activeSignals = market != null && market.opportunities() != null ? market.opportunities().size() : 0;
        long balance = market != null && market.accountBalance() > 0 ? market.accountBalance() : 0;
        if (balance == 0 && session != null) {
            var c = DoughBayClient.automationSessionController();
            if (c != null) balance = c.knownBalance();
        }

        renderKpiCard(dl, cx, cy, cardW, 58, "REALIZED PROFIT",
                "+$" + formatMoney(profit), "Settled closed positions", 0xFF10B981);

        renderKpiCard(dl, cx + (cardW + 8), cy, cardW, 58, "WIN RATE",
                String.format(Locale.ROOT, "%.1f%%", winRate), sales + " total trades completed", 0xFF72E6EF);

        renderKpiCard(dl, cx + (cardW + 8) * (cols == 4 ? 2 : 0), cy + (cols == 4 ? 0 : 66), cardW, 58, "ACTIVE SIGNALS",
                activeSignals + " Flips", "Meeting profit/ROI filters", 0xFFF59E0B);

        renderKpiCard(dl, cx + (cardW + 8) * (cols == 4 ? 3 : 1), cy + (cols == 4 ? 0 : 66), cardW, 58, "DONUTSMP BALANCE",
                balance > 0 ? "$" + formatMoney(balance) : "Auto-Tracking", "Live server wallet balance", 0xFFF8FAFC);

        ImGui.dummy(0, cols == 4 ? 66 : 132);

        // Alert banner if paused
        if (session != null && session.state() == AutomationSessionController.State.PAUSED) {
            ImGui.textColored(0.96f, 0.62f, 0.04f, 1.0f, "⚠ AUTOPILOT PAUSED: " + session.detail());
            ImGui.sameLine();
            if (ImGui.button("Resume ##dash_resume", 75, 22)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) {
                    var res = c.resumeFromPlayer();
                    if (res != null && !res.ok()) c.forceReset(Minecraft.getInstance());
                    setNotice("Resumed!");
                }
            }
            ImGui.sameLine();
            if (ImGui.button("Clear Lock / Force Reset ##dash_reset", 180, 22)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) {
                    c.forceReset(Minecraft.getInstance());
                    setNotice("Stale recovery lock cleared! Ready to scan.");
                }
            }
            ImGui.separator();
            ImGui.dummy(0, 4);
        }

        // 2. Cumulative Profit Chart Card
        float chartH = 140;
        renderProfitChart(dl, ImGui.getCursorScreenPosX(), ImGui.getCursorScreenPosY(), availW, chartH,
                ledger != null ? ledger.profitHistory() : null);
        ImGui.dummy(0, chartH + 12);

        // 3. Bottom Split Section: Left = Top Opportunities, Right = Recent Activity Feed
        float splitW = (availW - 12) * 0.55f;
        float rightW = availW - splitW - 12;

        ImGui.columns(2, "##tally_dash_split", false);
        ImGui.setColumnWidth(0, splitW + 6);
        ImGui.setColumnWidth(1, rightW + 6);

        // Left Column: Top Opportunities
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "TOP FLIP SIGNALS ON DONUTSMP");
        ImGui.separator();
        if (market == null || market.opportunities() == null || market.opportunities().isEmpty()) {
            ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Scanning order books for underpriced listings...");
            ImGui.textWrapped("Tally calculates real-time weighted median resale values and alerts when profitable flips appear.");
        } else {
            int shown = Math.min(3, market.opportunities().size());
            for (int i = 0; i < shown; i++) {
                Opportunity opp = market.opportunities().get(i);
                renderOpportunityCard(opp);
            }
        }

        ImGui.nextColumn();

        // Right Column: Live Activity Feed
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "LIVE ACTIVITY & ALERTS STREAM");
        ImGui.separator();

        List<TallyBridge.AlertView> activities = TallyBridge.recentActivity();
        if (activities.isEmpty()) {
            ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Session active. Monitoring order books...");
            if (session != null) {
                ImGui.textUnformatted("• Current State: " + session.state().name());
                ImGui.textUnformatted("• Trades Started: " + session.tradesStarted());
                ImGui.textUnformatted("• Committed Spend: $" + formatMoney(session.committedSpend()));
                ImGui.textUnformatted("• Open Listings: " + session.openListings());
            }
        } else {
            for (TallyBridge.AlertView alert : activities) {
                ImGui.textColored(0.95f, 0.95f, 0.95f, 1.0f, alert.title());
                if (alert.lineOne() != null && !alert.lineOne().isBlank()) {
                    ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, alert.lineOne());
                }
                if (alert.lineTwo() != null && !alert.lineTwo().isBlank()) {
                    ImGui.textColored(0.45f, 0.55f, 0.68f, 1.0f, alert.lineTwo());
                }
                ImGui.separator();
            }
        }

        ImGui.columns(1);
    }

    private static void renderKpiCard(ImDrawList dl, float x, float y, float w, float h,
                                      String label, String value, String note, int color) {
        dl.addRectFilled(x, y, x + w, y + h, ImColor.rgba(16, 26, 40, 240), 6);
        dl.addRect(x, y, x + w, y + h, ImColor.rgba(30, 48, 72, 255), 6, 0, 1.0f);
        studioText(dl, x + 10, y + 7, label, 0xFF94A3B8);
        studioText(dl, x + 10, y + 23, value, color);
        studioText(dl, x + 10, y + 42, note, 0xFF64748B);
    }

    private static void renderProfitChart(ImDrawList dl, float x, float y, float w, float h,
                                          List<PerformanceStatsSnapshot.ProfitPoint> history) {
        dl.addRectFilled(x, y, x + w, y + h, ImColor.rgba(14, 22, 34, 240), 6);
        dl.addRect(x, y, x + w, y + h, ImColor.rgba(28, 44, 66, 255), 6, 0, 1.0f);
        studioText(dl, x + 12, y + 10, "CUMULATIVE REALIZED PROFIT CURVE", 0xFF94A3B8);

        float padX = 16, padY = 32;
        float plotX = x + padX, plotY = y + padY;
        float plotW = w - padX * 2, plotH = h - padY - 14;

        dl.addLine(plotX, plotY + plotH, plotX + plotW, plotY + plotH, ImColor.rgba(38, 56, 80, 255), 1.0f);

        if (history != null && history.size() >= 2) {
            long minP = Long.MAX_VALUE, maxP = Long.MIN_VALUE;
            for (var pt : history) {
                minP = Math.min(minP, pt.cumulativeProfit());
                maxP = Math.max(maxP, pt.cumulativeProfit());
            }
            if (minP == maxP) {
                maxP = minP + 1000;
                minP = 0;
            }

            for (int i = 0; i < history.size() - 1; i++) {
                var p1 = history.get(i);
                var p2 = history.get(i + 1);
                float x1 = plotX + (i / (float) (history.size() - 1)) * plotW;
                float y1 = plotY + plotH - ((float) (p1.cumulativeProfit() - minP) / (maxP - minP)) * plotH;
                float x2 = plotX + ((i + 1) / (float) (history.size() - 1)) * plotW;
                float y2 = plotY + plotH - ((float) (p2.cumulativeProfit() - minP) / (maxP - minP)) * plotH;

                dl.addLine(x1, y1, x2, y2, ImColor.rgba(16, 185, 129, 255), 2.0f);
            }
        } else {
            // Baseline preview line
            dl.addLine(plotX, plotY + plotH * 0.7f, plotX + plotW, plotY + plotH * 0.7f, ImColor.rgba(114, 230, 239, 120), 1.5f);
            studioText(dl, plotX + plotW * 0.35f, plotY + plotH * 0.4f, "Trades and profit accumulate live as flips complete", 0xFF64748B);
        }
    }

    private static void renderOpportunityCard(Opportunity opp) {
        float availW = ImGui.getContentRegionAvailX();
        float h = 68;

        ImDrawList dl = ImGui.getWindowDrawList();
        float screenX = ImGui.getCursorScreenPosX();
        float screenY = ImGui.getCursorScreenPosY();
        float startLocalX = ImGui.getCursorPosX();
        float startLocalY = ImGui.getCursorPosY();

        dl.addRectFilled(screenX, screenY, screenX + availW, screenY + h, ImColor.rgba(16, 26, 40, 220), 6);
        dl.addRect(screenX, screenY, screenX + availW, screenY + h, ImColor.rgba(30, 48, 72, 255), 6, 0, 1.0f);

        String itemLabel = opp.listing() != null ? (opp.listing().itemCount() + "x " + formatItemName(opp.listing().itemKey())) : "Item";
        studioText(dl, screenX + 10, screenY + 8, itemLabel, 0xFFF8FAFC);

        String prices = String.format(Locale.ROOT, "Ask: $%s  ➔  Target: $%s",
                formatMoney(opp.buyPrice()), formatMoney(opp.recommendedSellPrice()));
        studioText(dl, screenX + 10, screenY + 26, prices, 0xFF94A3B8);

        String metrics = String.format(Locale.ROOT, "+$%s Net Profit (%.1f%% ROI)",
                formatMoney((long) opp.expectedNetProfit()), opp.expectedRoiPercent());
        studioText(dl, screenX + 10, screenY + 44, metrics, 0xFF10B981);

        // Action button on the right
        float btnW = 95, btnH = 24;
        ImGui.setCursorPos(startLocalX + availW - btnW - 8, startLocalY + 22);
        String seller = opp.listing() != null && opp.listing().sellerName() != null ? opp.listing().sellerName() : "";
        if (ImGui.button("View /ah ##opp_" + (opp.listing() != null ? opp.listing().listingKey() : ""), btnW, btnH)) {
            if (!seller.isBlank()) {
                Minecraft.getInstance().keyboardHandler.setClipboard("/ah view " + seller);
                setNotice("Copied '/ah view " + seller + "' to clipboard!");
            }
        }

        ImGui.setCursorPos(startLocalX, startLocalY + h + 6);
        ImGui.dummy(availW, 1);
    }

    private static void renderOpportunitiesTab(MarketWatcher.Snapshot market) {
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "LIVE ARBITRAGE & RESALE OPPORTUNITIES");
        ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Filtered by conservative weighted margin, market velocity, and liquidity gates.");
        ImGui.separator();

        ImGui.inputTextWithHint("##opp_search", "Search items...", searchFilter);
        ImGui.sameLine();
        ImGui.sliderFloat("Min Profit ($)", minProfitFilter.getData(), 1000, 100000, "%.0f");
        ImGui.sameLine();
        ImGui.sliderFloat("Min ROI (%)", minRoiFilter.getData(), 5.0f, 50.0f, "%.1f%%");

        if (!statusNotice.isBlank() && System.currentTimeMillis() - statusNoticeAt < 4000) {
            ImGui.textColored(0.13f, 0.77f, 0.36f, 1.0f, statusNotice);
        }

        ImGui.dummy(0, 4);

        if (market == null || market.opportunities() == null || market.opportunities().isEmpty()) {
            ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "No active opportunities currently match your filter criteria.");
            return;
        }

        String filter = searchFilter.get().toLowerCase(Locale.ROOT).trim();
        float minProf = minProfitFilter.get();
        float minRoi = minRoiFilter.get();

        int count = 0;
        for (Opportunity opp : market.opportunities()) {
            if (opp.expectedNetProfit() < minProf || opp.expectedRoiPercent() < minRoi) continue;
            String itemName = opp.listing() != null ? opp.listing().itemKey().toLowerCase(Locale.ROOT) : "";
            if (!filter.isEmpty() && !itemName.contains(filter)) continue;

            renderOpportunityCard(opp);
            count++;
        }

        if (count == 0) {
            ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Zero flips match active filters. Try lowering Min Profit or Min ROI thresholds.");
        }
    }

    private static void renderMarketsTab(MarketWatcher.Snapshot market) {
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "DONUTSMP COMMODITY MARKET METRICS");
        ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Real-time pricing models, median values, volume, and volatility tracking.");
        ImGui.separator();

        ImGui.inputTextWithHint("##market_search", "Search commodity markets...", searchFilter);
        ImGui.dummy(0, 4);

        if (market == null || market.markets() == null || market.markets().isEmpty()) {
            ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Gathering market statistics from DonutSMP feeds...");
            return;
        }

        ImGui.columns(5, "##market_table", true);
        ImGui.setColumnWidth(0, 220);
        ImGui.setColumnWidth(1, 130);
        ImGui.setColumnWidth(2, 130);
        ImGui.setColumnWidth(3, 100);
        ImGui.setColumnWidth(4, 90);

        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "Item"); ImGui.nextColumn();
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "7d Median"); ImGui.nextColumn();
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "Resale Target"); ImGui.nextColumn();
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "Sales/Hr"); ImGui.nextColumn();
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "Samples"); ImGui.nextColumn();
        ImGui.separator();

        String filter = searchFilter.get().toLowerCase(Locale.ROOT).trim();
        for (MarketStats stats : market.markets()) {
            if (!stats.hasPrices()) continue;
            String name = formatItemName(stats.itemKey());
            if (!filter.isEmpty() && !stats.itemKey().toLowerCase(Locale.ROOT).contains(filter)) continue;

            ImGui.textUnformatted(name); ImGui.nextColumn();
            ImGui.textUnformatted("$" + formatMoney((long) stats.weightedMedian())); ImGui.nextColumn();
            ImGui.textColored(0.06f, 0.72f, 0.50f, 1.0f, "$" + formatMoney((long) stats.quickSalePrice())); ImGui.nextColumn();
            ImGui.textUnformatted(String.format(Locale.ROOT, "%.1f", stats.salesPerHour())); ImGui.nextColumn();
            ImGui.textUnformatted(String.valueOf(stats.sampleCount())); ImGui.nextColumn();
        }

        ImGui.columns(1);
    }

    private static void renderAutoPilotTab(AutomationSessionController.SessionSnapshot session) {
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "AUTOPILOT / CONTINUOUS FLIP COPILOT");
        ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Fully automated buy-verify-relist cycle with strict bankroll risk controls.");
        ImGui.separator();

        boolean active = session != null && session.active();
        boolean paused = session != null && session.state() == AutomationSessionController.State.PAUSED;

        // Big action buttons
        if (active) {
            ImGui.pushStyleColor(21, ImColor.rgba(239, 68, 68, 255));
            if (ImGui.button("EMERGENCY STOP ##ap_stop", 160, 34)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) c.emergencyStop();
                setNotice("Autopilot stopped!");
            }
            ImGui.popStyleColor();

            ImGui.sameLine();
            ImGui.pushStyleColor(21, ImColor.rgba(245, 158, 11, 255));
            if (ImGui.button("PAUSE SESSION ##ap_pause", 140, 34)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) c.pause("Paused by player from subpanel");
                setNotice("Autopilot paused!");
            }
            ImGui.popStyleColor();
        } else if (paused) {
            ImGui.pushStyleColor(21, ImColor.rgba(16, 185, 129, 255));
            if (ImGui.button("RESUME SESSION ##ap_resume", 160, 34)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) {
                    var res = c.resumeFromPlayer();
                    if (res != null && !res.ok()) {
                        c.forceReset(Minecraft.getInstance());
                        setNotice("Stale lock cleared & resumed!");
                    } else {
                        setNotice("Autopilot resumed!");
                    }
                }
            }
            ImGui.popStyleColor();

            ImGui.sameLine();
            ImGui.pushStyleColor(21, ImColor.rgba(245, 158, 11, 255));
            if (ImGui.button("FORCE RESET & CLEAR LOCK ##ap_force_reset", 210, 34)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) {
                    c.forceReset(Minecraft.getInstance());
                    setNotice("Stale recovery lock cleared! Ready to start fresh.");
                }
            }
            ImGui.popStyleColor();

            ImGui.sameLine();
            ImGui.pushStyleColor(21, ImColor.rgba(239, 68, 68, 255));
            if (ImGui.button("END SESSION ##ap_end", 140, 34)) {
                var c = DoughBayClient.automationSessionController();
                if (c != null) c.emergencyStop();
                setNotice("Session ended!");
            }
            ImGui.popStyleColor();
        } else {
            ImGui.pushStyleColor(21, ImColor.rgba(16, 185, 129, 255));
            if (ImGui.button("START CONTINUOUS TRADING ##ap_start", 220, 34)) {
                startContinuousTrading();
            }
            ImGui.popStyleColor();
        }

        ImGui.sameLine();
        if (ImGui.button("Sweep Inventory & List ##ap_sweep", 180, 34)) {
            var c = DoughBayClient.automationSessionController();
            if (c != null) {
                c.requestInventoryList();
                setNotice("Requested inventory sweep & listing!");
            }
        }

        if (!statusNotice.isBlank() && System.currentTimeMillis() - statusNoticeAt < 4000) {
            ImGui.sameLine();
            ImGui.textColored(0.13f, 0.77f, 0.36f, 1.0f, statusNotice);
        }

        ImGui.dummy(0, 10);
        ImGui.separator();

        // --- STRATEGY PRESETS ---
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "STRATEGY PRESETS");
        ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "One-click tuning for bankroll size, order pacing, and item value brackets:");
        ImGui.dummy(0, 4);

        float availPresetW = ImGui.getContentRegionAvailX();
        float pBtnW = (availPresetW - 12) / 3.0f;

        // 1. Starter / Low Balance
        boolean isStarter = TallyPresets.getActivePreset() == TallyPresets.Preset.STARTER_LOW_BALANCE;
        if (isStarter) {
            ImGui.pushStyleColor(21, ImColor.rgba(14, 165, 233, 255));
        } else {
            ImGui.pushStyleColor(21, ImColor.rgba(18, 30, 46, 255));
        }
        if (ImGui.button("🪙 STARTER / LOW BAL ##preset_starter", pBtnW, 36)) {
            TallyPresets.apply(TallyPresets.Preset.STARTER_LOW_BALANCE);
        }
        ImGui.popStyleColor();

        ImGui.sameLine(0, 6);

        // 2. Whale / High Value
        boolean isWhale = TallyPresets.getActivePreset() == TallyPresets.Preset.WHALE_HIGH_VALUE;
        if (isWhale) {
            ImGui.pushStyleColor(21, ImColor.rgba(168, 85, 247, 255));
        } else {
            ImGui.pushStyleColor(21, ImColor.rgba(36, 18, 48, 255));
        }
        if (ImGui.button("💎 WHALE / HIGH VALUE ##preset_whale", pBtnW, 36)) {
            TallyPresets.apply(TallyPresets.Preset.WHALE_HIGH_VALUE);
        }
        ImGui.popStyleColor();

        ImGui.sameLine(0, 6);

        // 3. Balanced Default
        boolean isBalanced = TallyPresets.getActivePreset() == TallyPresets.Preset.BALANCED_DEFAULT;
        if (isBalanced) {
            ImGui.pushStyleColor(21, ImColor.rgba(16, 185, 129, 255));
        } else {
            ImGui.pushStyleColor(21, ImColor.rgba(16, 36, 28, 255));
        }
        if (ImGui.button("⚖️ BALANCED DEFAULT ##preset_bal", pBtnW, 36)) {
            TallyPresets.apply(TallyPresets.Preset.BALANCED_DEFAULT);
        }
        ImGui.popStyleColor();

        // Active Preset Details Callout
        TallyPresets.Preset curPreset = TallyPresets.getActivePreset();
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "Active Strategy: " + curPreset.displayName);
        ImGui.textColored(0.70f, 0.78f, 0.88f, 1.0f, curPreset.description);

        ImGui.dummy(0, 8);
        ImGui.separator();

        // Spend limits & Guardrails
        ImGui.textColored(0.85f, 0.85f, 0.85f, 1.0f, "Spend Limits & Allocation");
        ImGui.sliderFloat("Max Spend Per Trade ($M) ##trade_cap", maxPerTradeM.getData(), 1.0f, 500.0f, "%.0fM");
        ImGui.sliderFloat("Max Spend Per Session ($M) ##sess_cap", maxPerSessionM.getData(), 5.0f, 2000.0f, "%.0fM");

        if (ImGui.button("Apply Spend Limits ##save_limits", 160, 26)) {
            long trade = (long) (maxPerTradeM.get() * 1_000_000L);
            long sess = (long) (maxPerSessionM.get() * 1_000_000L);
            String server = "donutsmp.net";
            try {
                if (Minecraft.getInstance().getCurrentServer() != null && Minecraft.getInstance().getCurrentServer().ip != null) {
                    server = Minecraft.getInstance().getCurrentServer().ip;
                }
            } catch (Throwable ignored) {}
            String res = DoughBayClient.setDonutAutomation(true, trade, sess, server);
            setNotice(res.isBlank() ? "Spend limits saved successfully!" : res);
        }

        ImGui.dummy(0, 10);
        ImGui.separator();

        // Active Session Status Inspection
        ImGui.textColored(0.85f, 0.85f, 0.85f, 1.0f, "Session Telemetry");
        if (session != null) {
            ImGui.textUnformatted("• State: " + session.state().name());
            ImGui.textUnformatted("• Mode: " + session.runMode().name());
            ImGui.textUnformatted("• Trades Started: " + session.tradesStarted());
            ImGui.textUnformatted("• Committed Spend: $" + formatMoney(session.committedSpend()));
            ImGui.textUnformatted("• Open Resale Listings: " + session.openListings());
            ImGui.textUnformatted("• Recovery Status: " + session.persistenceStatus());
            if (!session.detail().isBlank()) {
                ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "• Detail: " + session.detail());
            }
        } else {
            ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "Automation controller offline.");
        }
    }

    private static void renderSettingsTab(MarketWatcher.Snapshot market) {
        ImGui.textColored(0.45f, 0.90f, 0.94f, 1.0f, "API CREDENTIALS & WORKSTATION SETTINGS");
        ImGui.textColored(0.58f, 0.64f, 0.72f, 1.0f, "DonutSMP API Key configuration and direct access to Tally's native workstation screen.");
        ImGui.separator();

        ImGui.textUnformatted("DonutSMP Official API Key:");
        int flags = showApiKey.get() ? 0 : 32;
        ImGui.inputText("##api_key_input", apiKeyDraft, flags);

        ImGui.sameLine();
        ImGui.checkbox("Show##show_key", showApiKey);

        ImGui.sameLine();
        if (ImGui.button("Save API Key ##save_key", 120, 24)) {
            String res = DoughBayClient.applyApiKey(apiKeyDraft.get().trim());
            setNotice(res.isBlank() ? "API Key updated successfully!" : res);
        }

        if (!statusNotice.isBlank() && System.currentTimeMillis() - statusNoticeAt < 4000) {
            ImGui.textColored(0.13f, 0.77f, 0.36f, 1.0f, statusNotice);
        }

        ImGui.dummy(0, 10);
        ImGui.separator();

        // Native Workstation Screen Launcher
        ImGui.textColored(0.85f, 0.85f, 0.85f, 1.0f, "Full Native Tally / DoughBay Desk");
        ImGui.textWrapped("Tally includes a comprehensive native Minecraft workstation screen with dedicated tabs for Capital Ledgers, Order Books, Evasion Guard, and StaffWatch.");
        ImGui.dummy(0, 4);

        ImGui.pushStyleColor(21, ImColor.rgba(14, 165, 233, 255));
        ImGui.pushStyleColor(22, ImColor.rgba(2, 132, 199, 255));
        if (ImGui.button("LAUNCH FULL NATIVE DESK ##launch_desk", 240, 36)) {
            openNativeDesk();
        }
        ImGui.popStyleColor(2);

        ImGui.dummy(0, 10);
        ImGui.separator();

        ImGui.textColored(0.85f, 0.85f, 0.85f, 1.0f, "Network Status");
        String stat = market != null && market.status() != null ? market.status() : "Ready";
        ImGui.textUnformatted("• Feed Status: " + stat);
        ImGui.textUnformatted("• Donut Automation Enabled: " + DoughBayClient.donutAutomationEnabled());
    }

    private static void startContinuousTrading() {
        try {
            ensureTallyInitialized();

            long trade = (long) (maxPerTradeM.get() * 1_000_000L);
            long sess = (long) (maxPerSessionM.get() * 1_000_000L);
            String server = "donutsmp.net";
            Minecraft mc = Minecraft.getInstance();
            try {
                if (mc.getCurrentServer() != null && mc.getCurrentServer().ip != null && !mc.getCurrentServer().ip.isBlank()) {
                    server = mc.getCurrentServer().ip.trim();
                } else if (mc.hasSingleplayerServer() || mc.isLocalServer()) {
                    server = "singleplayer";
                }
            } catch (Throwable ignored) {}

            DoughBayClient.setDonutAutomation(true, trade, sess, server);

            var session = DoughBayClient.automationSessionController();
            if (session != null) {
                var snap = session.snapshot();
                if (snap.recoveredSession() && snap.unresolvedExposure()) {
                    session.forceReset(mc);
                    setNotice("Stale recovery cleared & scanning started!");
                } else if (snap.state() == AutomationSessionController.State.PAUSED) {
                    var res = session.resumeFromPlayer();
                    if (res != null && !res.ok()) {
                        session.forceReset(mc);
                        setNotice("Stale lock cleared & resumed!");
                    } else {
                        setNotice("Session resumed!");
                    }
                } else {
                    var policy = DoughBayClient.continuousPolicy();
                    if (policy != null) {
                        var res = session.start(policy, AutomationSessionController.RunMode.CONTINUOUS);
                        if (res != null && !res.ok()) {
                            if (res.detail() != null && res.detail().toLowerCase(Locale.ROOT).contains("recovered")) {
                                session.forceReset(mc);
                                session.start(policy, AutomationSessionController.RunMode.CONTINUOUS);
                                setNotice("Recovered session reset & trading started!");
                            } else {
                                setNotice(res.detail());
                            }
                        } else {
                            setNotice("Autopilot continuous trading engaged!");
                        }
                    } else {
                        setNotice("Continuous policy unavailable: check limits");
                    }
                }
            }
        } catch (Throwable t) {
            setNotice("Failed to start: " + t.getMessage());
        }
    }
}
