package net.spectre.client.module.impl.misc.noinvleak;

import java.nio.IntBuffer;
import java.util.Arrays;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;

@Environment(EnvType.CLIENT)
final class OverlayWindow {
   private int[] backing = new int[256 * 256];
   private IntBuffer bits = IntBuffer.wrap(this.backing);
   private int capacityWidth = 256;
   private int capacityHeight = 256;
   private int posX;
   private int posY;
   private boolean visible;

   OverlayWindow(long glfwWindow) {
   }

   IntBuffer pixels(int width, int height) {
      if (width > this.capacityWidth || height > this.capacityHeight) {
         int nextWidth = Math.max(width, this.capacityWidth * 2);
         int nextHeight = Math.max(height, this.capacityHeight * 2);
         this.capacityWidth = nextWidth;
         this.capacityHeight = nextHeight;
         this.backing = new int[nextWidth * nextHeight];
         this.bits = IntBuffer.wrap(this.backing);
      } else {
         Arrays.fill(this.backing, 0, this.capacityWidth * height, 0);
         this.bits.clear();
      }
      return this.bits;
   }

   int stride() {
      return this.capacityWidth;
   }

   void present(int screenX, int screenY, int width, int height) {
      this.posX = screenX;
      this.posY = screenY;
      this.visible = true;
   }

   void move(int screenX, int screenY) {
      this.posX = screenX;
      this.posY = screenY;
   }

   void hide() {
      this.visible = false;
   }

   void destroy() {
      this.visible = false;
   }
}
