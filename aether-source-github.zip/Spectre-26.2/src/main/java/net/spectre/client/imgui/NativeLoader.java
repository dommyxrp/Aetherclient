package net.spectre.client.imgui;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Util;

public final class NativeLoader {
   private static boolean loaded = false;

   private NativeLoader() {}

   public static synchronized void ensureLoaded() {
      if (loaded) return;
      try {
         Util.OS os = Util.getPlatform();
         String nativeLibName;
         if (os == Util.OS.WINDOWS) {
            nativeLibName = "imgui-java64.dll";
         } else if (os == Util.OS.OSX) {
            nativeLibName = "libimgui-java64.dylib";
         } else {
            nativeLibName = "libimgui-java64.so";
         }

         Path gameDir;
         try {
            Minecraft mc = Minecraft.getInstance();
            gameDir = (mc != null && mc.gameDirectory != null) ? mc.gameDirectory.toPath() : Path.of(".");
         } catch (Throwable t) {
            gameDir = Path.of(".");
         }
         Path targetDir = gameDir.resolve(".cache").resolve("aether");
         Files.createDirectories(targetDir);

         Path nativeTarget = targetDir.resolve(nativeLibName);
         extractResource("/assets/spectre/natives/" + nativeLibName, nativeTarget);
         if (Files.exists(nativeTarget)) {
            System.load(nativeTarget.toAbsolutePath().toString());
         }

         loaded = true;
      } catch (Throwable t) {
         t.printStackTrace();
         loaded = true;
      }
   }

   private static void extractResource(String resourcePath, Path target) {
      try (InputStream in = NativeLoader.class.getResourceAsStream(resourcePath)) {
         if (in != null) {
            Files.copy(in, target, StandardCopyOption.REPLACE_EXISTING);
         }
      } catch (Throwable ignored) {}
   }
}
