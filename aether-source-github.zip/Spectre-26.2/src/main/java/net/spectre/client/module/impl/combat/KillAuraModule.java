package net.spectre.client.module.impl.combat;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.boat.AbstractBoat;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.event.EventHandler;
import net.spectre.client.event.Stage;
import net.spectre.client.event.impl.Render3DEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.CombatMacroLock;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.impl.combat.melee.MeleeAttacks;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ColorSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;
import net.spectre.client.util.pvp.Rotation;
import net.spectre.client.util.pvp.RotationUtils;
import net.spectre.client.util.pvp.ServerRotation;
import net.spectre.client.util.pvp.TargetingUtils;

@Environment(EnvType.CLIENT)
public final class KillAuraModule extends ClientModule {
   private final NumberSetting range = this.addSetting("range", new NumberSetting("Reach Range", 3.8F, 3.0F, 6.0F).step(0.1F));
   private final NumberSetting wallRange = this.addSetting("wall-range", new NumberSetting("Wall Range", 3.0F, 0.0F, 6.0F).step(0.1F));
   private final BooleanSetting throughWalls = this.addSetting("through-walls", new BooleanSetting("Through Walls", false));
   private final NumberSetting fov = this.addSetting("fov", new NumberSetting("FOV Angle", 360.0F, 30.0F, 360.0F).step(5.0F));
   private final ModeSetting priority = this.addSetting("priority", new ModeSetting("Priority", "Distance", "Distance", "Lowest Health", "FOV", "Armor"));
   private final ModeSetting rotationMode = this.addSetting("rotations", new ModeSetting("Rotations", "Silent", "Silent", "Client Lock", "Smooth Client", "None"));
   private final NumberSetting rotationSpeed = this.addSetting("rotation-speed", new NumberSetting("Rotation Speed", 60.0F, 10.0F, 100.0F).step(5.0F));
   private final ModeSetting cooldownMode = this.addSetting("cooldown", new ModeSetting("Cooldown", "Full 100%", "Full 100%", "Threshold", "Fast Spam"));
   private final NumberSetting cooldownThreshold = this.addSetting("cooldown-threshold", new NumberSetting("Threshold", 0.95F, 0.5F, 1.0F).step(0.01F));
   private final ModeSetting autoCrit = this.addSetting("auto-crit", new ModeSetting("Auto Crit", "Smart Fall", "Off", "Smart Fall", "Packet", "Jump"));
   private final BooleanSetting sprintReset = this.addSetting("sprint-reset", new BooleanSetting("Sprint Reset (W-Tap)", true));
   private final BooleanSetting autoBlock = this.addSetting("auto-block", new BooleanSetting("Auto Shield Block", true));
   private final BooleanSetting weaponsOnly = this.addSetting("weapons-only", new BooleanSetting("Weapons Only", true));
   private final BooleanSetting swords = this.addSetting("swords", new BooleanSetting("Swords", true));
   private final BooleanSetting axes = this.addSetting("axes", new BooleanSetting("Axes", true));
   private final BooleanSetting maces = this.addSetting("maces", new BooleanSetting("Maces", true));
   private final BooleanSetting players = this.addSetting("players", new BooleanSetting("Players", true));
   private final BooleanSetting hostiles = this.addSetting("hostiles", new BooleanSetting("Hostiles", false));
   private final BooleanSetting passives = this.addSetting("passives", new BooleanSetting("Passives", false));
   private final BooleanSetting skipFriends = this.addSetting("skip-friends", new BooleanSetting("Skip Friends", true));
   private final BooleanSetting targetEsp = this.addSetting("target-esp", new BooleanSetting("Target ESP", true));
   private final ColorSetting targetColor = this.addSetting("target-color", new ColorSetting("ESP Color", 0xFFFF2A55));

   private LivingEntity currentTarget;
   private int critWait;
   private boolean droppedSprintKey;
   private boolean unblockedForHit;

   public KillAuraModule() {
      super("kill-aura", "Kill Aura", "Advanced sword combat aura with customizable reach, rotations, crit-sync, and target sorting.", ModuleCategory.COMBAT);
      this.cooldownThreshold.visibleWhen(() -> this.cooldownMode.is("Threshold"));
      this.rotationSpeed.visibleWhen(() -> this.rotationMode.is("Smooth Client"));
      this.wallRange.visibleWhen(this.throughWalls::get);
   }

   @Override
   protected void onEnable() {
      this.currentTarget = null;
      this.critWait = 0;
      this.unblockedForHit = false;
      this.on(TickEvent.TYPE, Stage.POST, this::restoreSprintKey);
   }

   @Override
   protected void onDisable() {
      this.restoreSprintKey(null);
      this.currentTarget = null;
      this.critWait = 0;
      this.unblockedForHit = false;
   }

   public LivingEntity getTarget() {
      return this.currentTarget;
   }

   @EventHandler
   public void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player == null || mc.level == null) {
         this.currentTarget = null;
         return;
      }

      if (!MeleeAttacks.canAct(mc) || player.isDeadOrDying() || player.isHandsBusy()) {
         this.currentTarget = null;
         return;
      }

      if (this.weaponsOnly.get() && !this.isHoldingWeapon(player)) {
         this.currentTarget = null;
         return;
      }

      if (CombatMacroLock.heldByOther(this) || MeleeAttacks.attackedThisTick(player)) {
         return;
      }

      if (rowing(player)) {
         this.currentTarget = null;
         return;
      }

      boolean riding = player.getVehicle() != null;
      float reach = riding ? 6.0F : this.range.get();
      LivingEntity target = this.selectTarget(mc, player, reach);
      this.currentTarget = target;

      if (target == null) {
         this.critWait = 0;
         return;
      }

      Vec3 eye = player.getEyePosition();
      AABB box = target.getBoundingBox();
      Vec3 aimPoint = TargetingUtils.closestPoint(eye, box);

      // Handle Rotations
      Rotation aimRot = RotationUtils.fromTo(eye, aimPoint);
      this.applyRotation(mc, player, aimRot, riding);

      // Cooldown Check
      if (!this.isCharged(player)) {
         this.critWait = 0;
         return;
      }

      // Line of sight / reach check
      boolean lineClear = MeleeAttacks.lineIsClear(player, eye, aimPoint);
      double dist = eye.distanceTo(aimPoint);
      if (!lineClear) {
         if (!this.throughWalls.get() || dist > this.wallRange.get()) {
            return;
         }
      } else if (dist > reach) {
         return;
      }

      // Auto Crit Check
      if (!this.handleAutoCrit(mc, player, riding)) {
         return;
      }

      // Auto Shield Unblock
      boolean wasShieldBlocking = this.autoBlock.get() && player.isUsingItem() && player.getUseItem().is(Items.SHIELD);
      if (wasShieldBlocking) {
         mc.gameMode.releaseUsingItem(player);
         this.unblockedForHit = true;
      }

      // Pre-orient server rotation for anti-cheats (GrimAC / DonutSMP / HugoSMP)
      if ("Silent".equals(this.rotationMode.get()) && !riding) {
         ClientPacketListener conn = mc.getConnection();
         if (conn != null) {
            conn.send(new ServerboundMovePlayerPacket.Rot(aimRot.yaw(), aimRot.pitch(), player.onGround(), false));
         }
      }

      // Attack
      EntityHitResult hitResult = new EntityHitResult(target, aimPoint);
      boolean attacked;
      if (riding) {
         mc.gameMode.attack(player, target);
         player.swing(InteractionHand.MAIN_HAND);
         MeleeAttacks.noteAttack(player);
         attacked = true;
      } else {
         attacked = MeleeAttacks.attack(mc, hitResult, reach);
      }

      if (attacked) {
         this.critWait = 0;

         // Sprint Reset for maximum combo knockback
         if (this.sprintReset.get()) {
            this.triggerSprintReset(mc, player);
         }

         // Re-block shield if needed
         if (this.unblockedForHit && mc.options.keyUse.isDown()) {
            mc.gameMode.useItem(player, InteractionHand.OFF_HAND);
            this.unblockedForHit = false;
         }
      }
   }

   private boolean isCharged(LocalPlayer player) {
      if (this.cooldownMode.is("Fast Spam")) {
         return true;
      }
      float strength = player.getAttackStrengthScale(0.5F);
      if (this.cooldownMode.is("Full 100%")) {
         return strength >= 0.98F;
      }
      return strength >= this.cooldownThreshold.get();
   }

   private boolean handleAutoCrit(Minecraft mc, LocalPlayer player, boolean riding) {
      if (riding) return true;
      String mode = this.autoCrit.get();
      if ("Off".equals(mode)) return true;

      if ("Packet".equals(mode)) {
         if (player.onGround()) {
            ClientPacketListener conn = mc.getConnection();
            if (conn != null) {
               Vec3 p = player.position();
               conn.send(new ServerboundMovePlayerPacket.Pos(p.x, p.y + 0.0625, p.z, false, false));
               conn.send(new ServerboundMovePlayerPacket.Pos(p.x, p.y + 0.00001, p.z, false, false));
            }
         }
         return true;
      }

      if ("Jump".equals(mode)) {
         if (player.onGround()) {
            player.jumpFromGround();
            return false;
         }
         return falling(player);
      }

      if ("Smart Fall".equals(mode)) {
         if (player.getAbilities().flying || player.isFallFlying() || player.isInWater() || player.onClimbable()) {
            return true;
         }
         if (!player.onGround()) {
            // In air: wait until falling
            return falling(player) || this.critWait++ >= 10;
         } else if (player.input.keyPresses.jump()) {
            // Player is jumping from ground: wait for fall
            return false;
         }
         return true;
      }

      return true;
   }

   private void applyRotation(Minecraft mc, LocalPlayer player, Rotation target, boolean riding) {
      if (riding) return;
      String mode = this.rotationMode.get();
      if ("Silent".equals(mode)) {
         if (ServerRotation.yawFree(player)) {
            ServerRotation.request(target);
         }
      } else if ("Client Lock".equals(mode)) {
         player.setYRot(target.yaw());
         player.setXRot(target.pitch());
      } else if ("Smooth Client".equals(mode)) {
         float curYaw = player.getYRot();
         float curPitch = player.getXRot();
         float diffYaw = Mth.wrapDegrees(target.yaw() - curYaw);
         float diffPitch = target.pitch() - curPitch;
         float factor = Math.min(1.0F, (this.rotationSpeed.get() * 0.05F));
         player.setYRot(curYaw + diffYaw * factor);
         player.setXRot(Mth.clamp(curPitch + diffPitch * factor, -90.0F, 90.0F));
      }
   }

   private void triggerSprintReset(Minecraft mc, LocalPlayer player) {
      if (player.isSprinting()) {
         ClientPacketListener conn = mc.getConnection();
         if (conn != null) {
            conn.send(new ServerboundPlayerCommandPacket(player, Action.STOP_SPRINTING));
            player.setSprinting(false);
            this.droppedSprintKey = true;
         }
      }
   }

   private void restoreSprintKey(TickEvent event) {
      if (this.droppedSprintKey) {
         Minecraft mc = Minecraft.getInstance();
         if (mc.player != null) {
            ClientPacketListener conn = mc.getConnection();
            boolean movingForward = mc.options.keyUp.isDown() || mc.player.input.keyPresses.forward();
            if (conn != null && (movingForward || mc.options.keySprint.isDown())) {
               conn.send(new ServerboundPlayerCommandPacket(mc.player, Action.START_SPRINTING));
               mc.player.setSprinting(true);
            }
         }
         this.droppedSprintKey = false;
      }
   }

   private boolean isHoldingWeapon(LocalPlayer player) {
      ItemStack main = player.getMainHandItem();
      if (main.isEmpty()) return false;
      if (this.swords.get() && main.is(ItemTags.SWORDS)) return true;
      if (this.axes.get() && main.is(ItemTags.AXES)) return true;
      if (this.maces.get() && main.is(Items.MACE)) return true;
      return false;
   }

   private LivingEntity selectTarget(Minecraft mc, LocalPlayer player, float reach) {
      Vec3 eye = player.getEyePosition();
      Rotation currentRot = RotationUtils.entityRotation(player);
      double maxAngle = this.fov.get() * 0.5;

      List<LivingEntity> candidates = new ArrayList<>();
      for (Entity entity : mc.level.entitiesForRendering()) {
         if (entity instanceof LivingEntity living && this.wanted(living)) {
            Vec3 closest = TargetingUtils.closestPoint(eye, living.getBoundingBox());
            double dist = eye.distanceTo(closest);
            if (dist > reach) continue;

            if (this.fov.get() < 360.0F) {
               Rotation toTarget = RotationUtils.fromTo(eye, closest);
               double angle = RotationUtils.angleTo(currentRot, toTarget);
               if (angle > maxAngle) continue;
            }

            if (!MeleeAttacks.lineIsClear(player, eye, closest)) {
               if (!this.throughWalls.get() || dist > this.wallRange.get()) continue;
            }

            candidates.add(living);
         }
      }

      if (candidates.isEmpty()) return null;

      String p = this.priority.get();
      if ("Lowest Health".equals(p)) {
         candidates.sort(Comparator.comparingDouble(LivingEntity::getHealth));
      } else if ("FOV".equals(p)) {
         candidates.sort(Comparator.comparingDouble(l -> {
            Vec3 c = TargetingUtils.closestPoint(eye, l.getBoundingBox());
            return RotationUtils.angleTo(currentRot, RotationUtils.fromTo(eye, c));
         }));
      } else if ("Armor".equals(p)) {
         candidates.sort(Comparator.comparingInt(LivingEntity::getArmorValue));
      } else {
         // Distance
         candidates.sort(Comparator.comparingDouble(l -> eye.distanceTo(TargetingUtils.closestPoint(eye, l.getBoundingBox()))));
      }

      return candidates.get(0);
   }

   private boolean wanted(LivingEntity living) {
      LocalPlayer player = Minecraft.getInstance().player;
      if (player == null || living == player || !living.isAlive() || living.isDeadOrDying()) {
         return false;
      }
      if (living instanceof Player targetPlayer) {
         if (targetPlayer.isSpectator() || targetPlayer.isCreative()) return false;
         if (this.skipFriends.get() && MeleeAttacks.isFriend(targetPlayer)) return false;
         return this.players.get();
      }
      if (living instanceof Enemy) {
         return this.hostiles.get();
      }
      return this.passives.get();
   }

   private static boolean falling(LocalPlayer player) {
      return player.fallDistance > 0.0
         && !player.onGround()
         && !player.onClimbable()
         && !player.isInWater()
         && !player.isMobilityRestricted()
         && !player.isPassenger()
         && !player.getAbilities().flying
         && !player.isFallFlying();
   }

   private static boolean rowing(LocalPlayer player) {
      return player.getVehicle() instanceof AbstractBoat boat && (boat.getPaddleState(0) || boat.getPaddleState(1));
   }

   @EventHandler
   public void onRender3D(Render3DEvent event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null || mc.level == null) return;
      if (!this.targetEsp.get() || this.currentTarget == null || !this.currentTarget.isAlive()) return;

      AABB box = this.currentTarget.getBoundingBox();
      int color = this.targetColor.argb();
      int fill = ARGB.multiplyAlpha(color, 0.22F);
      GizmoStyle style = GizmoStyle.strokeAndFill(color, 2.0F, fill);
      Gizmos.cuboid(box, style).setAlwaysOnTop();

      // Render activation circle around target feet
      Vec3 center = new Vec3((box.minX + box.maxX) * 0.5, box.minY, (box.minZ + box.maxZ) * 0.5);
      drawCircle(center, 0.8, color);
   }

   private static void drawCircle(Vec3 center, double radius, int color) {
      Vec3 prev = null;
      int segs = 32;
      for (int i = 0; i <= segs; i++) {
         double angle = (Math.PI * 2) * i / segs;
         Vec3 p = center.add(Math.cos(angle) * radius, 0.05, Math.sin(angle) * radius);
         if (prev != null) {
            Gizmos.line(prev, p, ARGB.multiplyAlpha(color, 0.6F), 1.5F).setAlwaysOnTop();
         }
         prev = p;
      }
   }
}
