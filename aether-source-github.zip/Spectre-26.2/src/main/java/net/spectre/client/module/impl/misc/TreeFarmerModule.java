package net.spectre.client.module.impl.misc;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Queue;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundDisguisedChatPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.impl.PacketReceiveNettyEvent;
import net.spectre.client.event.impl.Render3DEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;
import net.spectre.client.module.setting.StringSetting;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class TreeFarmerModule extends ClientModule {
   public static volatile TreeFarmerModule active;

   private final StringSetting rtpCommand = this.addSetting("rtp-cmd", new StringSetting("RTP Command", "/rtp"));
   private final StringSetting sellCommand = this.addSetting("sell-cmd", new StringSetting("Sell Command", "/sell"));
   private final BooleanSetting autoSell = this.addSetting("auto-sell", new BooleanSetting("Auto Sell", true));
   private final ModeSetting sellMethod = this.addSetting(
      "sell-method", new ModeSetting("Sell Method", "GUI (/sell)", "GUI (/sell)", "Command Direct")
   );
   private final ModeSetting sellMode = this.addSetting(
      "sell-mode", new ModeSetting("Sell Trigger", "Before RTP", "Before RTP", "Inventory Full", "Every 5 Trees", "Always")
   );
   private final BooleanSetting sellSaplings = this.addSetting("sell-saplings", new BooleanSetting("Sell Saplings & Sticks", false));
   private final BooleanSetting rtpOnStart = this.addSetting("rtp-on-start", new BooleanSetting("RTP On Start", true));
   private final BooleanSetting autoConfirmChat = this.addSetting("auto-confirm-chat", new BooleanSetting("Auto Click Chat [HERE]", true));
   private final BooleanSetting autoRtpGui = this.addSetting("auto-rtp-gui", new BooleanSetting("Auto Click RTP GUI", true));
   private final NumberSetting rtpDelay = this.addSetting("rtp-delay", new NumberSetting("RTP Delay (s)", 3.5F, 1.0F, 15.0F).step(0.5F));
   private final NumberSetting rtpCooldown = this.addSetting("rtp-cooldown", new NumberSetting("RTP Cooldown (s)", 0.0F, 0.0F, 60.0F).step(1.0F));
   private final NumberSetting treesPerRtp = this.addSetting("trees-per-rtp", new NumberSetting("Trees Per RTP", 0.0F, 0.0F, 50.0F).step(1.0F));
   private final NumberSetting scanRadius = this.addSetting("scan-radius", new NumberSetting("Scan Radius", 64.0F, 16.0F, 160.0F).step(16.0F));
   private final NumberSetting ignoreSpawnRadius = this.addSetting("ignore-spawn", new NumberSetting("Ignore Spawn Radius", 256.0F, 0.0F, 1000.0F).step(32.0F));
   private final NumberSetting reachDistance = this.addSetting("reach", new NumberSetting("Reach Distance", 4.2F, 2.5F, 5.0F).step(0.1F));
   private final NumberSetting mineTimeout = this.addSetting("mine-timeout", new NumberSetting("Break Timeout (s)", 20.0F, 5.0F, 60.0F).step(1.0F));
   private final BooleanSetting autoTool = this.addSetting("auto-tool", new BooleanSetting("Auto Best Axe", true));
   private final BooleanSetting buildUp = this.addSetting("build-up", new BooleanSetting("Build Up For Tall Trees", true));
   private final NumberSetting maxPillarHeight = this.addSetting("max-pillar", new NumberSetting("Max Pillar Height", 6.0F, 2.0F, 12.0F).step(1.0F));
   private final BooleanSetting breakPillar = this.addSetting("break-pillar", new BooleanSetting("Break Pillar When Done", true));
   private final BooleanSetting autoWalk = this.addSetting("auto-walk", new BooleanSetting("Auto Walk", true));
   private final BooleanSetting autoJump = this.addSetting("auto-jump", new BooleanSetting("Auto Jump & Step", true));
   private final BooleanSetting smoothAim = this.addSetting("smooth-aim", new BooleanSetting("Humanized Aim", true));
   private final NumberSetting aimSpeed = this.addSetting("aim-speed", new NumberSetting("Aim Speed", 16.0F, 4.0F, 40.0F).step(1.0F));
   private final BooleanSetting breakLeaves = this.addSetting("break-leaves", new BooleanSetting("Break Obstructing Leaves", true));
   private final BooleanSetting collectDrops = this.addSetting("collect-drops", new BooleanSetting("Collect Drops", true));
   private final BooleanSetting swingHand = this.addSetting("swing-hand", new BooleanSetting("Swing Hand", true));
   private final BooleanSetting renderEsp = this.addSetting("render-esp", new BooleanSetting("Render ESP", true));

   private final ActionSetting clearBlacklist = this.addSetting("clear-blacklist", new ActionSetting("Clear Blacklist", () -> {
      this.blacklisted.clear();
      ModuleChat.send(this, "Cleared tree blacklist.");
   }));

   public static final class TreeCluster {
      public final List<BlockPos> logs = new ArrayList<>();
      public BlockPos basePos;

      public void addLog(BlockPos pos) {
         this.logs.add(pos);
         if (this.basePos == null || pos.getY() < this.basePos.getY()) {
            this.basePos = pos;
         }
      }

      public void finish() {
         this.logs.sort(Comparator.comparingInt(BlockPos::getY));
      }

      public BlockPos getLowestRemaining(ClientLevel level, Set<BlockPos> blacklisted) {
         for (BlockPos pos : this.logs) {
            if (!blacklisted.contains(pos) && level.getBlockState(pos).is(BlockTags.LOGS)) {
               return pos;
            }
         }
         return null;
      }

      public boolean hasRemainingLogs(ClientLevel level, Set<BlockPos> blacklisted) {
         return this.getLowestRemaining(level, blacklisted) != null;
      }
   }

   private enum State {
      IDLE,
      SEND_RTP,
      WAITING_RTP,
      SCANNING,
      NAVIGATING,
      MINING,
      PILLARING_UP,
      BREAKING_PILLAR,
      COLLECTING,
      HANDLING_SELL_GUI,
      COOLDOWN_WAIT
   }

   private State state = State.IDLE;
   private State resumeAfterSell = State.IDLE;
   private int stateTicks = 0;
   private int mineTicks = 0;
   private int stuckTicks = 0;
   private int targetLockedTicks = 0;
   private int logsMinedTotal = 0;
   private int treesFarmedTotal = 0;
   private int treesFarmedSinceRtp = 0;
   private int sellsCompletedTotal = 0;
   private int sellTimeoutTicks = 0;
   private int sellSyncTicks = 0;
   private int waitingTeleportTicks = 0;
   private double closestDist = Double.MAX_VALUE;
   private Vec3 preTeleportPos = null;

   // Pillaring / Build-up state
   private final Set<BlockPos> placedPillars = new HashSet<>();
   private double pillarStartY = 0.0;
   private boolean isPillaringJump = false;
   private int pillarTicks = 0;

   private final List<TreeCluster> foundTrees = new ArrayList<>();
   private TreeCluster currentTree = null;
   private BlockPos currentLog = null;
   private Direction targetFace = null;
   private final Set<BlockPos> blacklisted = new HashSet<>();
   private boolean isHoldingAttack = false;

   public TreeFarmerModule() {
      super("tree-farmer", "Tree Farmer", "Automates finding trees via /rtp, walking to them, chopping them with optimal axe, and selling with /sell.", ModuleCategory.DONUT);
      this.usesNotifications();
      this.autoJump.visibleWhen(this.autoWalk::get);
      this.sellCommand.visibleWhen(this.autoSell::get);
      this.sellMethod.visibleWhen(this.autoSell::get);
      this.sellMode.visibleWhen(this.autoSell::get);
      this.sellSaplings.visibleWhen(this.autoSell::get);
      this.maxPillarHeight.visibleWhen(this.buildUp::get);
      this.breakPillar.visibleWhen(this.buildUp::get);
   }

   @Override
   protected void onEnable() {
      active = this;
      Minecraft mc = Minecraft.getInstance();
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);
      if (mc.gameMode != null && mc.gameMode.isDestroying()) {
         mc.gameMode.stopDestroyBlock();
      }

      this.state = this.rtpOnStart.get() ? State.SEND_RTP : State.SCANNING;
      this.resumeAfterSell = State.IDLE;
      this.stateTicks = 0;
      this.mineTicks = 0;
      this.stuckTicks = 0;
      this.targetLockedTicks = 0;
      this.logsMinedTotal = 0;
      this.treesFarmedTotal = 0;
      this.treesFarmedSinceRtp = 0;
      this.sellsCompletedTotal = 0;
      this.sellTimeoutTicks = 0;
      this.sellSyncTicks = 0;
      this.waitingTeleportTicks = 0;
      this.preTeleportPos = null;
      this.placedPillars.clear();
      this.isPillaringJump = false;
      this.pillarTicks = 0;
      this.foundTrees.clear();
      this.currentTree = null;
      this.currentLog = null;
      this.targetFace = null;
      this.blacklisted.clear();
      this.isHoldingAttack = false;

      if (mc.player != null) {
         this.ensureAxeInHand(mc.player);
      }

      this.on(TickEvent.TYPE, this::onTick);
      this.on(Render3DEvent.TYPE, this::onRender3D);
      this.on(PacketReceiveNettyEvent.TYPE, this::onPacketReceive);
      ModuleChat.send(this, ModuleChat.body().good("Tree Farmer activated").text(". Starting automation loop..."));
   }

   @Override
   protected void onDisable() {
      active = null;
      Minecraft mc = Minecraft.getInstance();
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);
      if (mc.gameMode != null && mc.gameMode.isDestroying()) {
         mc.gameMode.stopDestroyBlock();
      }
      this.state = State.IDLE;
      this.placedPillars.clear();
      this.isPillaringJump = false;
      this.foundTrees.clear();
      this.currentTree = null;
      this.currentLog = null;
      this.targetFace = null;
      this.blacklisted.clear();
      this.isHoldingAttack = false;
      ModuleChat.send(this, ModuleChat.body().warn("Tree Farmer disabled").text(". Farmed ").value(this.treesFarmedTotal).text(" trees (").value(this.logsMinedTotal).text(" logs, ").value(this.sellsCompletedTotal).text(" sells)."));
   }

   private void onPacketReceive(PacketReceiveNettyEvent event) {
      if (!this.autoConfirmChat.get()) return;
      if (this.state != State.WAITING_RTP && this.state != State.SEND_RTP) return;

      if (event.packet instanceof ClientboundSystemChatPacket chat && chat.content() != null) {
         this.handleChatComponent(chat.content());
      } else if (event.packet instanceof ClientboundDisguisedChatPacket disguised && disguised.message() != null) {
         this.handleChatComponent(disguised.message());
      } else if (event.packet instanceof ClientboundPlayerChatPacket playerChat && playerChat.unsignedContent() != null) {
         this.handleChatComponent(playerChat.unsignedContent());
      }
   }

   private void handleChatComponent(Component component) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null || mc.getConnection() == null) return;

      String fullText = component.getString().toLowerCase(Locale.ROOT);
      component.visit((style, text) -> {
         ClickEvent click = style.getClickEvent();
         if (click instanceof ClickEvent.RunCommand runCmd) {
            String cmd = runCmd.command();
            String lowerCmd = cmd.toLowerCase(Locale.ROOT);
            if (lowerCmd.contains("rtp") || lowerCmd.contains("wild") || lowerCmd.contains("confirm") || fullText.contains("rtp") || fullText.contains("here")) {
               mc.execute(() -> {
                  if (mc.getConnection() != null) {
                     ModuleChat.send(this, ModuleChat.body().good("Auto-confirmed RTP prompt: ").value(cmd));
                     if (cmd.startsWith("/")) {
                        mc.getConnection().sendCommand(cmd.substring(1));
                     } else {
                        mc.getConnection().sendChat(cmd);
                     }
                     this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
                     this.waitingTeleportTicks = 0;
                  }
               });
               return Optional.of(true);
            }
         } else if (click instanceof ClickEvent.SuggestCommand suggestCmd) {
            String cmd = suggestCmd.command();
            String lowerCmd = cmd.toLowerCase(Locale.ROOT);
            if (lowerCmd.contains("rtp") || lowerCmd.contains("wild") || lowerCmd.contains("confirm") || fullText.contains("rtp") || fullText.contains("here")) {
               mc.execute(() -> {
                  if (mc.getConnection() != null) {
                     ModuleChat.send(this, ModuleChat.body().good("Auto-confirmed RTP prompt: ").value(cmd));
                     if (cmd.startsWith("/")) {
                        mc.getConnection().sendCommand(cmd.substring(1));
                     } else {
                        mc.getConnection().sendChat(cmd);
                     }
                     this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
                     this.waitingTeleportTicks = 0;
                  }
               });
               return Optional.of(true);
            }
         }
         return Optional.empty();
      }, Style.EMPTY);
   }

   private void checkRtpGui(Minecraft mc, LocalPlayer player) {
      if (!this.autoRtpGui.get()) return;
      if (mc.gui.screen() instanceof AbstractContainerScreen<?> containerScreen && player.containerMenu != null) {
         String title = containerScreen.getTitle().getString().toLowerCase(Locale.ROOT);
         if (title.contains("rtp") || title.contains("teleport") || title.contains("wild") || title.contains("dimension") || title.contains("world") || title.contains("random")) {
            int bestSlot = -1;
            for (int i = 0; i < player.containerMenu.slots.size() - 36; i++) {
               ItemStack stack = player.containerMenu.getSlot(i).getItem();
               if (!stack.isEmpty()) {
                  String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
                  if (name.contains("overworld") || name.contains("wild") || name.contains("rtp") || name.contains("random")) {
                     bestSlot = i;
                     break;
                  } else if (bestSlot == -1) {
                     bestSlot = i;
                  }
               }
            }
            if (bestSlot != -1) {
               int slotToClick = bestSlot;
               mc.gameMode.handleContainerInput(player.containerMenu.containerId, slotToClick, 0, ContainerInput.PICKUP, player);
               player.closeContainer();
               ModuleChat.send(this, ModuleChat.body().good("Auto-selected RTP menu slot ").value(slotToClick));
               this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
               this.waitingTeleportTicks = 0;
            }
         }
      }
   }

   public void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      ClientLevel level = mc.level;
      MultiPlayerGameMode gameMode = mc.gameMode;

      if (player == null || level == null || gameMode == null) {
         this.releaseAttack(mc);
         this.releaseMoveKeys(mc);
         return;
      }

      mc.missTime = 0;

      switch (this.state) {
         case SEND_RTP -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            String cmd = this.rtpCommand.get().trim();
            if (!cmd.isEmpty() && mc.getConnection() != null) {
               if (cmd.startsWith("/")) {
                  mc.getConnection().sendCommand(cmd.substring(1));
               } else {
                  mc.getConnection().sendChat(cmd);
               }
            }
            ModuleChat.actionBar(this, ModuleChat.body().text("Sent ").value(cmd).text(", teleporting to wilderness..."));
            this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
            this.waitingTeleportTicks = 0;
            this.preTeleportPos = player.position();
            this.currentTree = null;
            this.currentLog = null;
            this.foundTrees.clear();
            this.placedPillars.clear();
            this.treesFarmedSinceRtp = 0;
            this.state = State.WAITING_RTP;
         }

         case WAITING_RTP -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            this.checkRtpGui(mc, player);

            this.stateTicks--;
            if (this.stateTicks <= 0) {
               Vec3 currentPos = player.position();
               double distMovedSq = this.preTeleportPos != null ? currentPos.distanceToSqr(this.preTeleportPos) : 999.0;

               if (distMovedSq > 64.0) {
                  if (player.onGround() || player.isInWater() || player.fallDistance < 2.0F) {
                     this.state = State.SCANNING;
                  }
               } else {
                  this.waitingTeleportTicks++;
                  if (this.waitingTeleportTicks % 40 == 0) {
                     ModuleChat.actionBar(this, ModuleChat.body().warn("Waiting for RTP teleport...").text(" Click ").value("[HERE]").text(" if prompted"));
                  }
                  if (this.waitingTeleportTicks > 120) {
                     ModuleChat.send(this, ModuleChat.body().warn("Teleport timed out. Retrying RTP..."));
                     this.state = State.SEND_RTP;
                  }
               }
            }
         }

         case SCANNING -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            int radius = Math.round(this.scanRadius.get());
            int spawnIgnore = Math.round(this.ignoreSpawnRadius.get());
            int playerChunkX = player.chunkPosition().x();
            int playerChunkZ = player.chunkPosition().z();
            int chunkRadius = (radius + 15) >> 4;
            double maxDistSq = (double)radius * (double)radius;
            Vec3 playerPos = player.position();
            List<BlockPos> rawLogs = new ArrayList<>();

            for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
               for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                  LevelChunk chunk = level.getChunkSource().getChunkNow(playerChunkX + dx, playerChunkZ + dz);
                  if (chunk == null) continue;
                  LevelChunkSection[] sections = chunk.getSections();
                  int minSectionY = chunk.getMinSectionY();
                  for (int i = 0; i < sections.length; i++) {
                     LevelChunkSection section = sections[i];
                     if (section == null || section.hasOnlyAir()) continue;
                     if (!section.maybeHas(s -> s.is(BlockTags.LOGS))) continue;
                     int baseY = (minSectionY + i) << 4;
                     for (int y = 0; y < 16; y++) {
                        for (int z = 0; z < 16; z++) {
                           for (int x = 0; x < 16; x++) {
                              if (section.getBlockState(x, y, z).is(BlockTags.LOGS)) {
                                 BlockPos pos = new BlockPos(((playerChunkX + dx) << 4) + x, baseY + y, ((playerChunkZ + dz) << 4) + z);

                                 if (spawnIgnore > 0 && Math.abs(pos.getX()) <= spawnIgnore && Math.abs(pos.getZ()) <= spawnIgnore) {
                                    continue;
                                 }

                                 if (!this.blacklisted.contains(pos) && pos.distToCenterSqr(playerPos) <= maxDistSq) {
                                    rawLogs.add(pos);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }

            List<TreeCluster> clusters = clusterLogs(rawLogs);
            clusters.removeIf(tree -> !tree.hasRemainingLogs(level, this.blacklisted));

            if (clusters.isEmpty()) {
               ModuleChat.actionBar(this, ModuleChat.body().warn("No trees found in radius").text(". Selling & initiating RTP..."));
               this.triggerSellAndThen(State.COOLDOWN_WAIT);
            } else {
               // Prioritize trees on the same ground level (penalizing steep vertical differences)
               clusters.sort(Comparator.comparingDouble(t -> {
                  double dx = t.basePos.getX() - player.getX();
                  double dy = t.basePos.getY() - player.getY();
                  double dz = t.basePos.getZ() - player.getZ();
                  return dx * dx + (dy * dy * 3.5) + dz * dz;
               }));
               this.foundTrees.clear();
               this.foundTrees.addAll(clusters);
               this.currentTree = this.foundTrees.get(0);
               this.currentLog = this.currentTree.getLowestRemaining(level, this.blacklisted);
               this.targetFace = this.currentLog != null ? getExposedFace(level, player, this.currentLog) : Direction.UP;
               this.stuckTicks = 0;
               this.closestDist = Double.MAX_VALUE;
               this.ensureAxeInHand(player);
               ModuleChat.actionBar(this, ModuleChat.body().good("Found " + clusters.size() + " tree(s)").text("! Navigating..."));
               this.state = State.NAVIGATING;
            }
         }

         case NAVIGATING -> {
            if (this.currentTree == null || !this.currentTree.hasRemainingLogs(level, this.blacklisted)) {
               this.nextTreeOrFinish(player);
               return;
            }

            this.currentLog = this.currentTree.getLowestRemaining(level, this.blacklisted);
            if (this.currentLog == null) {
               this.nextTreeOrFinish(player);
               return;
            }

            this.ensureAxeInHand(player);

            Vec3 eyeVec = player.getEyePosition();
            Vec3 targetCenter = Vec3.atCenterOf(this.currentLog);
            double distSq = eyeVec.distanceToSqr(targetCenter);
            float reach = this.reachDistance.get();

            if (distSq <= (double)reach * (double)reach) {
               this.releaseMoveKeys(mc);
               this.mineTicks = 0;
               this.targetLockedTicks = 0;
               this.state = State.MINING;
               return;
            }

            // Only pillar up if tree base/lower logs are already broken and remaining log is genuinely unreachable from ground
            double distXZ = Math.hypot(player.getX() - targetCenter.x, player.getZ() - targetCenter.z);
            if (distXZ < 1.6 && this.currentLog.getY() > player.getY() + 3.8 && this.buildUp.get() && this.placedPillars.size() < (int)this.maxPillarHeight.get() && this.findPillarBlock(player) != -1) {
               this.releaseMoveKeys(mc);
               this.state = State.PILLARING_UP;
               this.isPillaringJump = false;
               this.pillarTicks = 0;
               return;
            }

            if (this.autoWalk.get()) {
               Vec3 walkTarget = this.currentTree.basePos != null ? Vec3.atCenterOf(this.currentTree.basePos) : targetCenter;
               this.walkTowards(player, this.currentLog, walkTarget, eyeVec);
            } else {
               this.releaseMoveKeys(mc);
            }
         }

         case MINING -> {
            if (this.currentTree == null || this.currentLog == null) {
               this.releaseAttack(mc);
               this.nextTreeOrFinish(player);
               return;
            }

            BlockState blockState = level.getBlockState(this.currentLog);
            if (blockState.isAir() || !blockState.is(BlockTags.LOGS)) {
               this.releaseAttack(mc);
               if (gameMode.isDestroying()) {
                  gameMode.stopDestroyBlock();
               }
               this.logsMinedTotal++;

               BlockPos nextInTree = this.currentTree.getLowestRemaining(level, this.blacklisted);
               if (nextInTree != null) {
                  Vec3 eye = player.getEyePosition();
                  double nextDistSq = eye.distanceToSqr(Vec3.atCenterOf(nextInTree));
                  float reach = this.reachDistance.get();
                  if (nextDistSq <= (double)(reach + 0.3F) * (double)(reach + 0.3F)) {
                     this.currentLog = nextInTree;
                     this.targetFace = getExposedFace(level, player, this.currentLog);
                     this.mineTicks = 0;
                     this.targetLockedTicks = 0;
                     ModuleChat.actionBar(this, ModuleChat.body().good("Chopped log!").text(" Total Logs: ").value(this.logsMinedTotal));
                     return;
                  } else if (this.buildUp.get() && nextInTree.getY() > player.getY() + 3.8 && this.placedPillars.size() < (int)this.maxPillarHeight.get() && this.findPillarBlock(player) != -1) {
                     // Log is higher up in tree - pillar up!
                     this.state = State.PILLARING_UP;
                     this.isPillaringJump = false;
                     this.pillarTicks = 0;
                     return;
                  }
               }

               if (this.collectDrops.get()) {
                  this.state = State.COLLECTING;
                  this.stateTicks = 35;
               } else {
                  this.onLogChopped(player);
               }
               return;
            }

            Vec3 eye = player.getEyePosition();
            Vec3 center = Vec3.atCenterOf(this.currentLog);
            float reach = this.reachDistance.get();
            if (eye.distanceToSqr(center) > (double)(reach + 0.9F) * (double)(reach + 0.9F)) {
               this.releaseAttack(mc);
               double distXZ = Math.hypot(player.getX() - center.x, player.getZ() - center.z);
               if (distXZ < 1.6 && this.currentLog.getY() > player.getY() + 3.8 && this.buildUp.get() && this.placedPillars.size() < (int)this.maxPillarHeight.get() && this.findPillarBlock(player) != -1) {
                  this.state = State.PILLARING_UP;
                  this.isPillaringJump = false;
                  this.pillarTicks = 0;
               } else {
                  this.state = State.NAVIGATING;
               }
               return;
            }

            this.mineTicks++;
            int maxMineTicks = Math.round(this.mineTimeout.get() * 20.0F);
            if (this.mineTicks > maxMineTicks) {
               this.releaseAttack(mc);
               if (gameMode.isDestroying()) {
                  gameMode.stopDestroyBlock();
               }
               ModuleChat.send(this, ModuleChat.body().warn("Log at ").value(this.currentLog.toShortString()).text(" took too long (claimed?). Blacklisting."));
               this.blacklisted.add(this.currentLog);
               this.nextTreeOrFinish(player);
               return;
            }

            if (this.targetFace == null) {
               this.targetFace = getExposedFace(level, player, this.currentLog);
               if (this.targetFace == null) this.targetFace = Direction.UP;
            }

            boolean onTarget = this.aimAt(player, this.currentLog, this.targetFace);
            if (onTarget) {
               this.targetLockedTicks++;
               if (this.targetLockedTicks >= 2) {
                  if (this.autoTool.get()) {
                     this.ensureAxeInHand(player);
                  }
                  this.pressAttack(mc);
               }
            }
         }

         case PILLARING_UP -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);

            int pillarSlot = this.findPillarBlock(player);
            if (pillarSlot == -1) {
               ModuleChat.actionBar(this, ModuleChat.body().warn("No building blocks to pillar up. Moving to next tree..."));
               if (!this.placedPillars.isEmpty() && this.breakPillar.get()) {
                  this.state = State.BREAKING_PILLAR;
               } else {
                  this.nextTreeOrFinish(player);
               }
               return;
            }

            player.getInventory().setSelectedSlot(pillarSlot);
            player.setXRot(88.0F); // Look directly down

            if (!this.isPillaringJump) {
               this.pillarStartY = player.getY();
               mc.options.keyJump.setDown(true);
               this.isPillaringJump = true;
               this.pillarTicks = 0;
            } else {
               this.pillarTicks++;
               double jumped = player.getY() - this.pillarStartY;
               if (jumped >= 1.15 || (this.pillarTicks > 7 && jumped > 0.8)) {
                  mc.options.keyJump.setDown(false);
                  BlockPos under = BlockPos.containing(player.getX(), this.pillarStartY, player.getZ());
                  BlockHitResult hit = new BlockHitResult(Vec3.atCenterOf(under).add(0, 0.5, 0), Direction.UP, under, false);
                  mc.gameMode.useItemOn(player, InteractionHand.MAIN_HAND, hit);
                  player.swing(InteractionHand.MAIN_HAND);
                  this.placedPillars.add(under.above());
                  this.isPillaringJump = false;
                  this.stateTicks = 4; // pause brief moment to land
                  this.state = State.MINING;
               } else if (this.pillarTicks > 25) { // timeout safety
                  mc.options.keyJump.setDown(false);
                  this.isPillaringJump = false;
                  this.state = State.MINING;
               }
            }
         }

         case BREAKING_PILLAR -> {
            this.releaseMoveKeys(mc);
            if (this.placedPillars.isEmpty()) {
               this.nextTreeOrFinish(player);
               return;
            }

            BlockPos under = BlockPos.containing(player.getX(), player.getY() - 0.2, player.getZ());
            BlockState underState = level.getBlockState(under);
            if (underState.isAir() || !this.placedPillars.contains(under)) {
               this.placedPillars.remove(under);
               if (player.onGround() && !this.hasPillarDirectlyUnder(player)) {
                  this.placedPillars.clear();
                  this.nextTreeOrFinish(player);
               }
               return;
            }

            // Aim straight down and break the pillar block beneath feet
            player.setXRot(88.0F);
            this.equipBestToolFor(player, underState);
            this.pressAttack(mc);

            this.mineTicks++;
            if (this.mineTicks > 60) { // Safety break timeout
               this.releaseAttack(mc);
               this.placedPillars.remove(under);
               this.nextTreeOrFinish(player);
            }
         }

         case COLLECTING -> {
            this.releaseAttack(mc);
            ItemEntity drop = this.findNearestWoodDrop(player, level, 8.0);
            if (drop != null) {
               Vec3 dropPos = drop.position();
               double distSq = player.distanceToSqr(dropPos);
               if (distSq > 0.35) {
                  this.walkTowards(player, drop.blockPosition(), dropPos, player.getEyePosition());
               } else {
                  this.releaseMoveKeys(mc);
               }
               this.stateTicks--;
               if (this.stateTicks <= 0) {
                  this.releaseMoveKeys(mc);
                  this.onLogChopped(player);
               }
            } else {
               this.releaseMoveKeys(mc);
               this.onLogChopped(player);
            }
         }

         case HANDLING_SELL_GUI -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            this.sellTimeoutTicks--;

            if (mc.gui.screen() instanceof AbstractContainerScreen<?> containerScreen && player.containerMenu != null) {
               int totalSlots = player.containerMenu.slots.size();
               int containerSize = totalSlots - 36;
               if (containerSize > 0) {
                  // Find next wood stack in player inventory (slots containerSize .. totalSlots - 1)
                  int woodSlot = -1;
                  for (int i = containerSize; i < totalSlots; i++) {
                     ItemStack stack = player.containerMenu.getSlot(i).getItem();
                     if (this.isSellableWood(stack)) {
                        woodSlot = i;
                        break;
                     }
                  }

                  if (woodSlot != -1) {
                     ItemStack woodStack = player.containerMenu.getSlot(woodSlot).getItem();
                     // 1. Try quick move (shift-click)
                     gameMode.handleContainerInput(player.containerMenu.containerId, woodSlot, 0, ContainerInput.QUICK_MOVE, player);

                     // 2. If shift-click didn't transfer it (custom GUI restrictions), drag & drop into container sell slot
                     ItemStack after = player.containerMenu.getSlot(woodSlot).getItem();
                     if (this.isSellableWood(after)) {
                        int targetSellSlot = findAvailableSellSlot(player.containerMenu, containerSize, after);
                        if (targetSellSlot != -1) {
                           gameMode.handleContainerInput(player.containerMenu.containerId, woodSlot, 0, ContainerInput.PICKUP, player);
                           gameMode.handleContainerInput(player.containerMenu.containerId, targetSellSlot, 0, ContainerInput.PICKUP, player);
                           if (!player.containerMenu.getCarried().isEmpty()) {
                              int secondSlot = findAvailableSellSlot(player.containerMenu, containerSize, player.containerMenu.getCarried());
                              if (secondSlot != -1) {
                                 gameMode.handleContainerInput(player.containerMenu.containerId, secondSlot, 0, ContainerInput.PICKUP, player);
                              }
                           }
                        }
                     }
                     return; // Wait next tick to move next wood stack cleanly
                  } else {
                     // All wood in player inventory has been placed into the sell container!
                     this.sellSyncTicks++;
                     if (this.sellSyncTicks >= 4) { // brief pause for server packets to register
                        player.closeContainer();
                        mc.gui.setScreen(null);
                        this.sellsCompletedTotal++;
                        ModuleChat.actionBar(this, ModuleChat.body().good("Wood placed in /sell slot & confirmed!").text(" Sells: ").value(this.sellsCompletedTotal));
                        int cd = Math.round(this.rtpCooldown.get() * 20.0F);
                        this.stateTicks = Math.max(cd, 15);
                        this.state = this.resumeAfterSell != State.IDLE ? this.resumeAfterSell : State.SCANNING;
                        this.resumeAfterSell = State.IDLE;
                        return;
                     }
                  }
               }
            }

            if (this.sellTimeoutTicks <= 0) {
               if (mc.gui.screen() != null && player.containerMenu != null) {
                  player.closeContainer();
                  mc.gui.setScreen(null);
               }
               ModuleChat.actionBar(this, ModuleChat.body().warn("Sell GUI finished or timed out. Resuming..."));
               int cd = Math.round(this.rtpCooldown.get() * 20.0F);
               this.stateTicks = Math.max(cd, 15);
               this.state = this.resumeAfterSell != State.IDLE ? this.resumeAfterSell : State.SCANNING;
               this.resumeAfterSell = State.IDLE;
            }
         }

         case COOLDOWN_WAIT -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            int cd = Math.round(this.rtpCooldown.get() * 20.0F);
            this.stateTicks = Math.max(cd, 20);
            this.state = State.SEND_RTP;
         }

         case IDLE -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
         }
      }
   }

   private boolean hasPillarDirectlyUnder(LocalPlayer player) {
      BlockPos under = BlockPos.containing(player.getX(), player.getY() - 0.2, player.getZ());
      return this.placedPillars.contains(under);
   }

   private void onLogChopped(LocalPlayer player) {
      ClientLevel level = (ClientLevel)player.level();
      if (this.currentTree != null && this.currentTree.hasRemainingLogs(level, this.blacklisted)) {
         this.currentLog = this.currentTree.getLowestRemaining(level, this.blacklisted);
         this.targetFace = this.currentLog != null ? getExposedFace(level, player, this.currentLog) : Direction.UP;
         this.mineTicks = 0;
         this.targetLockedTicks = 0;

         // Check if next log in tree is high above player and out of ground reach
         if (this.buildUp.get() && this.currentLog != null && this.currentLog.getY() > player.getY() + 3.8 && this.placedPillars.size() < (int)this.maxPillarHeight.get() && this.findPillarBlock(player) != -1) {
            this.state = State.PILLARING_UP;
            this.isPillaringJump = false;
            this.pillarTicks = 0;
         } else {
            this.state = State.NAVIGATING;
         }
      } else {
         this.treesFarmedTotal++;
         this.treesFarmedSinceRtp++;
         ModuleChat.actionBar(this, ModuleChat.body().good("Completed tree!").text(" Farmed: ").value(this.treesFarmedTotal).text(" | Logs: ").value(this.logsMinedTotal));

         if (!this.placedPillars.isEmpty() && this.breakPillar.get()) {
            this.state = State.BREAKING_PILLAR;
            this.mineTicks = 0;
         } else if (this.shouldSellNow(player)) {
            this.triggerSellAndThen(State.NAVIGATING);
            this.nextTreeOrFinish(player);
         } else {
            this.nextTreeOrFinish(player);
         }
      }
   }

   private boolean shouldSellNow(LocalPlayer player) {
      if (!this.autoSell.get()) return false;
      if (this.countSellableWood(player) == 0) return false;
      String mode = this.sellMode.get();
      if ("Always".equals(mode)) return true;
      if ("Every 5 Trees".equals(mode) && this.treesFarmedTotal % 5 == 0) return true;
      if ("Inventory Full".equals(mode) && this.isInventoryFull(player)) return true;
      return false;
   }

   private boolean isInventoryFull(LocalPlayer player) {
      Inventory inv = player.getInventory();
      int free = 0;
      for (int i = 0; i < 36; i++) {
         if (inv.getItem(i).isEmpty()) {
            free++;
         }
      }
      return free <= 1;
   }

   private boolean isSellableWood(ItemStack stack) {
      if (stack.isEmpty()) return false;
      // Strictly protect tools, weapons, armor, totems
      if (stack.is(ItemTags.AXES) || stack.is(ItemTags.PICKAXES) || stack.is(ItemTags.SWORDS) ||
          stack.is(ItemTags.SHOVELS) || stack.is(ItemTags.HOES) || stack.is(ItemTags.ARMOR_ENCHANTABLE) ||
          stack.getItem() == Items.TOTEM_OF_UNDYING) {
         return false;
      }
      if (stack.is(ItemTags.LOGS) || stack.is(ItemTags.PLANKS)) {
         return true;
      }
      if (this.sellSaplings.get()) {
         return stack.is(ItemTags.SAPLINGS) || stack.is(ItemTags.LEAVES) || stack.getItem() == Items.STICK;
      }
      return false;
   }

   private int countSellableWood(LocalPlayer player) {
      if (player == null) return 0;
      Inventory inv = player.getInventory();
      int count = 0;
      for (int i = 0; i < 36; i++) {
         ItemStack stack = inv.getItem(i);
         if (this.isSellableWood(stack)) {
            count += stack.getCount();
         }
      }
      return count;
   }

   private int findPillarBlock(LocalPlayer player) {
      Inventory inv = player.getInventory();
      // 1. Check hotbar first (0-8)
      for (int i = 0; i < 9; i++) {
         ItemStack stack = inv.getItem(i);
         if (isPillarBlock(stack)) {
            return i;
         }
      }
      // 2. Check main inventory (9-35) and swap to hotbar
      for (int i = 9; i < 36; i++) {
         ItemStack stack = inv.getItem(i);
         if (isPillarBlock(stack)) {
            Minecraft mc = Minecraft.getInstance();
            int hotbarSlot = inv.getSelectedSlot();
            if (hotbarSlot < 0 || hotbarSlot > 8) hotbarSlot = 0;
            if (mc.gameMode != null) {
               mc.gameMode.handleContainerInput(player.inventoryMenu.containerId, i, hotbarSlot, ContainerInput.SWAP, player);
               ItemStack from = inv.getItem(i);
               ItemStack to = inv.getItem(hotbarSlot);
               inv.setItem(hotbarSlot, from);
               inv.setItem(i, to);
               return hotbarSlot;
            }
         }
      }
      return -1;
   }

   private static boolean isPillarBlock(ItemStack stack) {
      if (stack.isEmpty()) return false;
      Item item = stack.getItem();
      if (item == Items.DIRT || item == Items.COARSE_DIRT || item == Items.COBBLESTONE ||
          item == Items.COBBLED_DEEPSLATE || item == Items.NETHERRACK || item == Items.STONE ||
          item == Items.ANDESITE || item == Items.DIORITE || item == Items.GRANITE ||
          item == Items.SCAFFOLDING || stack.is(ItemTags.PLANKS)) {
         return true;
      }
      return false;
   }

   private static int findAvailableSellSlot(AbstractContainerMenu menu, int containerSize, ItemStack woodToPlace) {
      // 1. Look for existing stack of same wood with room
      for (int i = 0; i < containerSize; i++) {
         ItemStack stack = menu.getSlot(i).getItem();
         if (!stack.isEmpty() && isSellableWoodStatic(stack) && ItemStack.isSameItemSameComponents(stack, woodToPlace)) {
            if (stack.getCount() < stack.getMaxStackSize()) {
               return i;
            }
         }
      }
      // 2. Look for empty slot that isn't a blocked border
      for (int i = 0; i < containerSize; i++) {
         ItemStack stack = menu.getSlot(i).getItem();
         if (stack.isEmpty()) {
            return i;
         }
      }
      // 3. Look for designated sell slot (labeled "Sell", "Drop", "Drag")
      for (int i = 0; i < containerSize; i++) {
         ItemStack stack = menu.getSlot(i).getItem();
         if (!stack.isEmpty()) {
            String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
            if (name.contains("sell") || name.contains("drop") || name.contains("drag") || name.contains("put")) {
               return i;
            }
         }
      }
      return -1;
   }

   private static boolean isSellableWoodStatic(ItemStack stack) {
      if (stack.isEmpty()) return false;
      if (stack.is(ItemTags.AXES) || stack.is(ItemTags.PICKAXES) || stack.is(ItemTags.SWORDS)) return false;
      return stack.is(ItemTags.LOGS) || stack.is(ItemTags.PLANKS);
   }

   private void triggerSellAndThen(State nextState) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (!this.autoSell.get() || this.countSellableWood(player) == 0) {
         this.state = nextState;
         return;
      }

      this.resumeAfterSell = nextState;
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);

      String cmd = this.sellCommand.get().trim();
      if ("Command Direct".equals(this.sellMethod.get())) {
         if (!cmd.isEmpty() && mc.getConnection() != null) {
            if (cmd.startsWith("/")) {
               mc.getConnection().sendCommand(cmd.substring(1));
            } else {
               mc.getConnection().sendChat(cmd);
            }
            ModuleChat.actionBar(this, ModuleChat.body().good("Sent sell command!").text(" (").value(cmd).text(")"));
         }
         this.stateTicks = 15;
         this.state = this.resumeAfterSell != State.IDLE ? this.resumeAfterSell : State.SCANNING;
         this.resumeAfterSell = State.IDLE;
         return;
      }

      // GUI (/sell) mode
      if (!cmd.isEmpty() && mc.getConnection() != null) {
         if (cmd.startsWith("/")) {
            mc.getConnection().sendCommand(cmd.substring(1));
         } else {
            mc.getConnection().sendChat(cmd);
         }
         ModuleChat.actionBar(this, ModuleChat.body().text("Opening ").value(cmd).text(" menu to drag wood..."));
      }

      this.sellTimeoutTicks = 60; // 3 seconds timeout
      this.sellSyncTicks = 0;
      this.state = State.HANDLING_SELL_GUI;
   }

   private void nextTreeOrFinish(LocalPlayer player) {
      if (this.currentTree != null) {
         this.foundTrees.remove(this.currentTree);
         this.currentTree = null;
         this.currentLog = null;
         this.targetFace = null;
      }
      this.releaseAttack(Minecraft.getInstance());
      this.releaseMoveKeys(Minecraft.getInstance());
      this.targetLockedTicks = 0;
      this.mineTicks = 0;
      this.stuckTicks = 0;
      this.closestDist = Double.MAX_VALUE;

      int maxPerRtp = Math.round(this.treesPerRtp.get());
      if (maxPerRtp > 0 && this.treesFarmedSinceRtp >= maxPerRtp) {
         ModuleChat.send(this, ModuleChat.body().good("Reached ").value(maxPerRtp).text(" trees limit for this area. Selling & RTPing..."));
         this.triggerSellAndThen(State.COOLDOWN_WAIT);
         return;
      }

      ClientLevel level = (ClientLevel)player.level();
      this.foundTrees.removeIf(t -> !t.hasRemainingLogs(level, this.blacklisted));

      if (!this.foundTrees.isEmpty()) {
         this.foundTrees.sort(Comparator.comparingDouble(t -> {
            double dx = t.basePos.getX() - player.getX();
            double dy = t.basePos.getY() - player.getY();
            double dz = t.basePos.getZ() - player.getZ();
            return dx * dx + (dy * dy * 3.5) + dz * dz;
         }));
         this.currentTree = this.foundTrees.get(0);
         this.currentLog = this.currentTree.getLowestRemaining(level, this.blacklisted);
         this.targetFace = this.currentLog != null ? getExposedFace(level, player, this.currentLog) : Direction.UP;
         this.state = State.NAVIGATING;
      } else {
         ModuleChat.actionBar(this, ModuleChat.body().warn("All trees cleared in area").text(". Selling & initiating RTP..."));
         this.triggerSellAndThen(State.COOLDOWN_WAIT);
      }
   }

   private void walkTowards(LocalPlayer player, BlockPos targetPos, Vec3 targetCenter, Vec3 eyeVec) {
      Minecraft mc = Minecraft.getInstance();
      double px = player.getX();
      double pz = player.getZ();
      double dx = targetCenter.x - px;
      double dz = targetCenter.z - pz;
      float targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));

      if (this.smoothAim.get()) {
         float currentYaw = player.getYRot();
         float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
         if (Math.abs(diffYaw) > 0.5F) {
            float maxStep = Math.max(0.6F, this.aimSpeed.get() * 0.22F);
            float stepYaw = Mth.clamp(diffYaw * 0.25F, -maxStep, maxStep);
            float quantYaw = quantizeToMouseGcd(mc, stepYaw);
            player.setYRot(currentYaw + quantYaw);
         }
         double dy = targetCenter.y - eyeVec.y;
         double distXZ = Math.hypot(dx, dz);
         float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, distXZ));
         float currentPitch = player.getXRot();
         float diffPitch = Mth.wrapDegrees(targetPitch - currentPitch);
         if (Math.abs(diffPitch) > 0.5F) {
            float stepPitch = Mth.clamp(diffPitch * 0.2F, -2.5F, 2.5F);
            player.setXRot(Mth.clamp(currentPitch + quantizeToMouseGcd(mc, stepPitch), -90.0F, 90.0F));
         }
      }

      float yawOffset = Math.abs(Mth.wrapDegrees(targetYaw - player.getYRot()));
      mc.options.keyUp.setDown(yawOffset < 45.0F);

      // Smart Ledge & Obstacle Step Detection ahead
      double rad = Math.toRadians(player.getYRot());
      double fx = -Math.sin(rad);
      double fz = Math.cos(rad);
      ClientLevel level = (ClientLevel)player.level();

      // Break obstructing leaves/vines right in the path
      if (this.breakLeaves.get()) {
         BlockPos footFront = BlockPos.containing(player.getX() + fx * 0.6, player.getY() + 0.1, player.getZ() + fz * 0.6);
         BlockPos headFront = footFront.above();
         BlockState footState = level.getBlockState(footFront);
         BlockState headState = level.getBlockState(headFront);
         if (footState.is(BlockTags.LEAVES) || footState.is(Blocks.VINE)) {
            player.setXRot(25.0F);
            this.pressAttack(mc);
         } else if (headState.is(BlockTags.LEAVES) || headState.is(Blocks.VINE)) {
            player.setXRot(-15.0F);
            this.pressAttack(mc);
         }
      }

      // Auto Jump ONLY on real walls/steps or water/lava - never on flat ground!
      if (this.autoJump.get()) {
         boolean inLiquid = player.isInWater() || player.isInLava();
         boolean collidingWall = player.horizontalCollision && player.onGround();

         // Check 0.55 blocks ahead at mid-body height (Y + 0.5)
         BlockPos stepPos = BlockPos.containing(player.getX() + fx * 0.55, player.getY() + 0.5, player.getZ() + fz * 0.55);
         BlockPos stepHeadPos = stepPos.above();
         boolean isOneBlockStep = player.onGround()
            && !level.getBlockState(stepPos).getCollisionShape(level, stepPos).isEmpty()
            && level.getBlockState(stepHeadPos).getCollisionShape(level, stepHeadPos).isEmpty();

         if (inLiquid || collidingWall || isOneBlockStep) {
            mc.options.keyJump.setDown(true);
         } else {
            boolean physical = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyJump);
            mc.options.keyJump.setDown(physical);
         }
      }

      // Stuck handling & terrain unstuck maneuvers
      double currentDist = player.distanceToSqr(targetCenter);
      double moveSpeed = player.getDeltaMovement().horizontalDistance();
      if (currentDist < this.closestDist - 0.05) {
         this.closestDist = currentDist;
         this.stuckTicks = 0;
         mc.options.keyLeft.setDown(false);
         mc.options.keyRight.setDown(false);
      } else {
         if (moveSpeed < 0.03 && (player.horizontalCollision || Math.abs(currentDist - this.closestDist) < 0.02)) {
            this.stuckTicks++;
         } else {
            this.stuckTicks = Math.max(0, this.stuckTicks - 1);
         }

         if (this.stuckTicks > 20) {
            mc.options.keyJump.setDown(true);
            if (this.stuckTicks % 24 < 12) {
               mc.options.keyLeft.setDown(true);
               mc.options.keyRight.setDown(false);
            } else {
               mc.options.keyLeft.setDown(false);
               mc.options.keyRight.setDown(true);
            }
         }

         if (this.stuckTicks > 100) {
            mc.options.keyLeft.setDown(false);
            mc.options.keyRight.setDown(false);
            this.blacklisted.add(targetPos);
            this.nextTreeOrFinish(player);
         }
      }
   }

   public void onRender3D(Render3DEvent event) {
      if (!this.renderEsp.get()) return;
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player == null || mc.level == null) return;

      Vec3 eye = player.getEyePosition();

      // Render surrounding trees in green
      for (TreeCluster tree : this.foundTrees) {
         if (tree == this.currentTree) continue;
         if (tree.basePos != null) {
            AABB baseBox = new AABB(tree.basePos);
            Gizmos.cuboid(baseBox, GizmoStyle.strokeAndFill(0xCC22CC44, 1.2F, 0x2222CC44));
         }
      }

      // Render active tree logs in cyan/mint
      if (this.currentTree != null) {
         for (BlockPos log : this.currentTree.logs) {
            if (log.equals(this.currentLog)) continue;
            if (mc.level.getBlockState(log).is(BlockTags.LOGS)) {
               AABB box = new AABB(log);
               Gizmos.cuboid(box, GizmoStyle.strokeAndFill(0xCC00FFAA, 1.5F, 0x3300FFAA));
            }
         }
      }

      // Render target log in bright emerald with tracer
      if (this.currentLog != null) {
         AABB targetBox = new AABB(this.currentLog);
         Gizmos.cuboid(targetBox, GizmoStyle.strokeAndFill(0xFF00FF66, 2.5F, 0x5500FF66));
         Gizmos.line(eye, Vec3.atCenterOf(this.currentLog), 0xFF00FF66, 1.8F);
      }

      // Render temporary pillar blocks in amber/gold
      for (BlockPos pillar : this.placedPillars) {
         AABB box = new AABB(pillar);
         Gizmos.cuboid(box, GizmoStyle.strokeAndFill(0xFFFFB500, 1.8F, 0x44FFB500));
      }
   }

   public static boolean isAxe(ItemStack stack) {
      if (stack == null || stack.isEmpty()) return false;
      if (stack.is(ItemTags.AXES)) return true;
      String name = stack.getItem().getDescriptionId().toLowerCase(Locale.ROOT);
      if (name.contains("axe") && !name.contains("pickaxe")) return true;
      return stack.getDestroySpeed(Blocks.OAK_LOG.defaultBlockState()) > 1.5F;
   }

   private void ensureAxeInHand(LocalPlayer player) {
      if (!this.autoTool.get() || player == null) return;
      Inventory inv = player.getInventory();
      int selected = inv.getSelectedSlot();
      ItemStack held = inv.getItem(selected);
      BlockState logState = Blocks.OAK_LOG.defaultBlockState();

      // If already holding a functional axe with durability, no need to swap
      if (isAxe(held) && !held.nextDamageWillBreak()) {
         return;
      }

      int bestHotbarSlot = -1;
      float bestHotbarSpeed = 1.0F;

      for (int i = 0; i < 9; i++) {
         ItemStack stack = inv.getItem(i);
         if (!isAxe(stack) || stack.nextDamageWillBreak()) continue;
         float speed = stack.getDestroySpeed(logState);
         if (speed > bestHotbarSpeed) {
            bestHotbarSpeed = speed;
            bestHotbarSlot = i;
         }
      }

      if (bestHotbarSlot != -1) {
         inv.setSelectedSlot(bestHotbarSlot);
         if (player.connection != null) {
            player.connection.send(new ServerboundSetCarriedItemPacket(bestHotbarSlot));
         }
         return;
      }

      // No functional axe in hotbar, search main inventory (9-35)
      int bestInvSlot = -1;
      float bestInvSpeed = 1.0F;
      for (int i = 9; i < 36; i++) {
         ItemStack stack = inv.getItem(i);
         if (!isAxe(stack) || stack.nextDamageWillBreak()) continue;
         float speed = stack.getDestroySpeed(logState);
         if (speed > bestInvSpeed) {
            bestInvSpeed = speed;
            bestInvSlot = i;
         }
      }

      if (bestInvSlot != -1) {
         Minecraft mc = Minecraft.getInstance();
         int hotbarTarget = selected >= 0 && selected < 9 ? selected : 0;
         if (mc.gameMode != null) {
            mc.gameMode.handleContainerInput(player.inventoryMenu.containerId, bestInvSlot, hotbarTarget, ContainerInput.SWAP, player);
         }
         ItemStack invStack = inv.getItem(bestInvSlot);
         ItemStack hotbarStack = inv.getItem(hotbarTarget);
         inv.setItem(hotbarTarget, invStack);
         inv.setItem(bestInvSlot, hotbarStack);
         inv.setSelectedSlot(hotbarTarget);
         if (player.connection != null) {
            player.connection.send(new ServerboundSetCarriedItemPacket(hotbarTarget));
         }
         ModuleChat.actionBar(this, ModuleChat.body().good("Equipped axe from inventory!"));
      }
   }

   private void equipBestAxe(LocalPlayer player, BlockState state, BlockPos pos) {
      if (this.isHoldingAttack) return;
      this.ensureAxeInHand(player);
   }

   private ItemEntity findNearestWoodDrop(LocalPlayer player, ClientLevel level, double radius) {
      if (player == null || level == null) return null;
      ItemEntity best = null;
      double bestDistSq = radius * radius;
      for (Entity entity : level.entitiesForRendering()) {
         if (entity instanceof ItemEntity item && !item.isRemoved() && !item.getItem().isEmpty()) {
            if (this.isCollectableDrop(item.getItem())) {
               double distSq = player.distanceToSqr(item);
               if (distSq < bestDistSq) {
                  best = item;
                  bestDistSq = distSq;
               }
            }
         }
      }
      return best;
   }

   private boolean isCollectableDrop(ItemStack stack) {
      if (stack == null || stack.isEmpty()) return false;
      if (this.isSellableWood(stack)) return true;
      if (stack.is(ItemTags.LOGS) || stack.is(ItemTags.PLANKS)) return true;
      if (this.sellSaplings.get()) {
         return stack.is(ItemTags.SAPLINGS) || stack.is(ItemTags.LEAVES) || stack.getItem() == Items.STICK || stack.getItem() == Items.APPLE;
      }
      return false;
   }

   private void equipBestToolFor(LocalPlayer player, BlockState state) {
      if (this.isHoldingAttack) return;
      Inventory inv = player.getInventory();
      int currentSlot = inv.getSelectedSlot();
      int bestSlot = currentSlot;
      float bestSpeed = state.getDestroySpeed(player.level(), player.blockPosition());

      for (int i = 0; i < 9; i++) {
         ItemStack stack = inv.getItem(i);
         if (stack.isEmpty() || stack.nextDamageWillBreak()) continue;
         float speed = stack.getDestroySpeed(state);
         if (speed > bestSpeed) {
            bestSpeed = speed;
            bestSlot = i;
         }
      }

      if (bestSlot != currentSlot) {
         inv.setSelectedSlot(bestSlot);
         if (player.connection != null) {
            player.connection.send(new ServerboundSetCarriedItemPacket(bestSlot));
         }
      }
   }

   private boolean aimAt(LocalPlayer player, BlockPos pos, Direction face) {
      if (!this.smoothAim.get()) {
         Vec3 center = Vec3.atCenterOf(pos);
         Minecraft.getInstance().hitResult = new BlockHitResult(center, face, pos, false);
         return true;
      }

      Vec3 faceCenter = Vec3.atCenterOf(pos).add(
         (double)face.getStepX() * 0.40,
         (double)face.getStepY() * 0.40,
         (double)face.getStepZ() * 0.40
      );
      Vec3 eye = player.getEyePosition();
      Vec3 delta = faceCenter.subtract(eye);
      double distXZ = Math.hypot(delta.x, delta.z);
      float targetYaw = (float)Math.toDegrees(Math.atan2(-delta.x, delta.z));
      float targetPitch = (float)-Math.toDegrees(Math.atan2(delta.y, distXZ));

      Minecraft mc = Minecraft.getInstance();
      float currentYaw = player.getYRot();
      float currentPitch = player.getXRot();
      float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
      float diffPitch = Mth.wrapDegrees(targetPitch - currentPitch);
      float totalDiff = (float)Math.hypot(diffYaw, diffPitch);

      if (totalDiff > 0.35F) {
         float t = Mth.clamp(totalDiff / 16.0F, 0.08F, 1.0F);
         float ease = (float)(1.0 - Math.pow(1.0 - t, 2.2));
         float maxStep = Math.max(0.35F, this.aimSpeed.get() * 0.20F * ease);

         float stepYaw = Mth.clamp(diffYaw * 0.35F, -maxStep, maxStep);
         float stepPitch = Mth.clamp(diffPitch * 0.35F, -maxStep, maxStep);

         float quantYaw = quantizeToMouseGcd(mc, stepYaw);
         float quantPitch = quantizeToMouseGcd(mc, stepPitch);

         player.setYRot(currentYaw + quantYaw);
         player.setXRot(Mth.clamp(currentPitch + quantPitch, -90.0F, 90.0F));
      }

      ClientLevel level = (ClientLevel)player.level();
      Vec3 look = player.getViewVector(1.0F);
      Vec3 reachEnd = eye.add(look.scale(Math.max(4.5, (double)this.reachDistance.get())));
      BlockHitResult hit = level.clip(new ClipContext(eye, reachEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
      boolean rayHit = (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos));

      if (!rayHit && this.breakLeaves.get() && hit.getType() == HitResult.Type.BLOCK) {
         BlockState hitState = level.getBlockState(hit.getBlockPos());
         if (hitState.is(BlockTags.LEAVES)) {
            // Obstructing leaf hit directly in front of the log - break leaf first
            this.targetFace = hit.getDirection();
            Minecraft.getInstance().hitResult = hit;
            return totalDiff < 2.5F;
         }
      }

      if (rayHit) {
         this.targetFace = hit.getDirection();
         Minecraft.getInstance().hitResult = hit;
         return totalDiff < 2.5F;
      }

      return false;
   }

   private float quantizeToMouseGcd(Minecraft mc, float value) {
      float sensitivity = mc.options.sensitivity().get().floatValue();
      float f = sensitivity * 0.6F + 0.2F;
      float gcd = f * f * f * 8.0F * 0.15F;
      if (gcd <= 0.0001F) return value;
      return Math.round(value / gcd) * gcd;
   }

   private static Direction getExposedFace(ClientLevel level, LocalPlayer player, BlockPos pos) {
      Vec3 eye = player.getEyePosition();
      Direction bestFace = null;
      double bestDist = Double.MAX_VALUE;

      for (Direction face : Direction.values()) {
         BlockPos neighbor = pos.relative(face);
         BlockState neighborState = level.getBlockState(neighbor);
         if (!neighborState.isSolidRender()) {
            Vec3 faceCenter = Vec3.atCenterOf(pos).add(
               (double)face.getStepX() * 0.40,
               (double)face.getStepY() * 0.40,
               (double)face.getStepZ() * 0.40
            );

            BlockHitResult clip = level.clip(new ClipContext(eye, faceCenter, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (clip.getType() == HitResult.Type.MISS || clip.getBlockPos().equals(pos)) {
               double dist = eye.distanceToSqr(faceCenter);
               if (dist < bestDist) {
                  bestDist = dist;
                  bestFace = face;
               }
            }
         }
      }

      if (bestFace == null) {
         for (Direction face : Direction.values()) {
            if (!level.getBlockState(pos.relative(face)).isSolidRender()) {
               return face;
            }
         }
      }

      return bestFace != null ? bestFace : Direction.UP;
   }

   private static List<TreeCluster> clusterLogs(List<BlockPos> logs) {
      List<TreeCluster> clusters = new ArrayList<>();
      Set<BlockPos> unvisited = new HashSet<>(logs);

      for (BlockPos log : logs) {
         if (!unvisited.remove(log)) continue;
         TreeCluster cluster = new TreeCluster();
         cluster.addLog(log);

         Queue<BlockPos> queue = new ArrayDeque<>();
         queue.add(log);

         while (!queue.isEmpty() && cluster.logs.size() < 150) {
            BlockPos curr = queue.poll();
            for (int dx = -2; dx <= 2; dx++) {
               for (int dy = -1; dy <= 3; dy++) {
                  for (int dz = -2; dz <= 2; dz++) {
                     if (dx == 0 && dy == 0 && dz == 0) continue;
                     BlockPos neighbor = curr.offset(dx, dy, dz);
                     if (unvisited.remove(neighbor)) {
                        cluster.addLog(neighbor);
                        queue.add(neighbor);
                     }
                  }
               }
            }
         }
         cluster.finish();
         clusters.add(cluster);
      }
      return clusters;
   }

   private void pressAttack(Minecraft mc) {
      mc.missTime = 0;
      KeyMapping key = mc.options.keyAttack;
      if (!this.isHoldingAttack) {
         if (!key.isUnbound()) {
            Key bound = KeyMappingHelper.getBoundKeyOf(key);
            KeyMapping.click(bound);
            KeyMapping.set(bound, true);
         }
         key.setDown(true);
         this.isHoldingAttack = true;
      } else {
         key.setDown(true);
      }
      if (this.swingHand.get() && mc.player != null) {
         mc.player.swing(InteractionHand.MAIN_HAND);
      }
   }

   private void releaseAttack(Minecraft mc) {
      this.isHoldingAttack = false;
      KeyMapping key = mc.options.keyAttack;
      if (!key.isUnbound()) {
         Key bound = KeyMappingHelper.getBoundKeyOf(key);
         KeyMapping.set(bound, false);
      }
      boolean physical = mc.gui.screen() == null && physicallyDown(mc, key);
      key.setDown(physical);
   }

   private void releaseMoveKeys(Minecraft mc) {
      if (mc.options != null) {
         boolean physicalUp = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyUp);
         boolean physicalJump = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyJump);
         mc.options.keyUp.setDown(physicalUp);
         mc.options.keyJump.setDown(physicalJump);
         mc.options.keyLeft.setDown(false);
         mc.options.keyRight.setDown(false);
      }
   }

   private static boolean physicallyDown(Minecraft mc, KeyMapping mapping) {
      if (mapping.isUnbound()) {
         return false;
      } else {
         Key key = KeyMappingHelper.getBoundKeyOf(mapping);
         int value = key.getValue();
         if (value < 0) {
            return false;
         } else {
            return switch (key.getType()) {
               case MOUSE -> GLFW.glfwGetMouseButton(mc.getWindow().handle(), value) == 1;
               case KEYSYM -> InputConstants.isKeyDown(mc.getWindow(), value);
               default -> mapping.isDown();
            };
         }
      }
   }
}
