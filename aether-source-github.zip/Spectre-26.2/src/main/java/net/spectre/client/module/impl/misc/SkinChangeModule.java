package net.spectre.client.module.impl.misc;

import com.mojang.authlib.GameProfile;
import java.io.IOException;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.StringSetting;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.core.ClientAsset.Texture;
import net.minecraft.world.entity.player.PlayerModelType;
import net.minecraft.world.entity.player.PlayerSkin;

@Environment(EnvType.CLIENT)
public final class SkinChangeModule extends ClientModule {
   private final StringSetting selfPlayerSetting = this.addSetting("self-player", new StringSetting("Self Player", ""));
   private final StringSetting othersPlayerSetting = this.addSetting("others-player", new StringSetting("Others Player", ""));
   private volatile SkinChangeModule.CustomSkin selfSkin;
   private volatile SkinChangeModule.CustomSkin othersSkin;
   private String loadedSelfName = "";
   private String loadedOthersName = "";
   private boolean selfLoading;
   private boolean othersLoading;
   private final SkinChangeModule.SwapCache selfSwaps = new SkinChangeModule.SwapCache();
   private final SkinChangeModule.SwapCache othersSwaps = new SkinChangeModule.SwapCache();

   public SkinChangeModule() {
      super("skin-change", "Skin Change", "Wear any player's skin client-side.", ModuleCategory.MISC);
   }

   @Override
   protected void onEnable() {
      this.reloadIfChanged();
      this.on(TickEvent.TYPE, e -> this.reloadIfChanged());
   }

   @Override
   protected void onDisable() {
      this.selfSkin = null;
      this.othersSkin = null;
      this.loadedSelfName = "";
      this.loadedOthersName = "";
      this.selfSwaps.clear();
      this.othersSwaps.clear();
   }

   private void reloadIfChanged() {
      String selfName = this.selfPlayerSetting.get().trim();
      String othersName = this.othersPlayerSetting.get().trim();
      if (!selfName.equals(this.loadedSelfName)) {
         this.selfSkin = null;
         if (selfName.isEmpty()) {
            this.loadedSelfName = "";
         } else if (!this.selfLoading) {
            this.loadedSelfName = selfName;
            this.selfLoading = true;
            this.resolveSkin(selfName, true);
         }
      }

      if (!othersName.equals(this.loadedOthersName)) {
         this.othersSkin = null;
         if (othersName.isEmpty()) {
            this.loadedOthersName = "";
         } else if (!this.othersLoading) {
            this.loadedOthersName = othersName;
            this.othersLoading = true;
            this.resolveSkin(othersName, false);
         }
      }
   }

   private void resolveSkin(String targetName, boolean isSelf) {
      Minecraft mc = Minecraft.getInstance();
      CompletableFuture.runAsync(
         () -> {
            try {
               var profileOpt = mc.services().profileResolver().fetchByName(targetName);
               if (profileOpt.isEmpty()) {
                  mc.execute(() -> this.finishLoad(targetName, isSelf, null));
                  return;
               }

               GameProfile profile = profileOpt.get();
               mc.getSkinManager().get(profile).whenCompleteAsync(
                  (optSkin, error) -> {
                     if (error != null || optSkin == null || optSkin.isEmpty()) {
                        this.finishLoad(targetName, isSelf, null);
                     } else {
                        PlayerSkin skin = optSkin.get();
                        this.finishLoad(targetName, isSelf, new SkinChangeModule.CustomSkin(skin.body(), skin.model()));
                     }
                  }, mc
               );
            } catch (Exception var10) {
               mc.execute(() -> this.finishLoad(targetName, isSelf, null));
            }
         }
      );
   }

   private void finishLoad(String targetName, boolean isSelf, SkinChangeModule.CustomSkin loaded) {
      if (isSelf) {
         this.selfLoading = false;
      } else {
         this.othersLoading = false;
      }

      if (this.isEnabled()) {
         String current = (isSelf ? this.selfPlayerSetting : this.othersPlayerSetting).get().trim();
         if (loaded != null && targetName.equals(current) && targetName.equals(isSelf ? this.loadedSelfName : this.loadedOthersName)) {
            if (isSelf) {
               this.selfSkin = loaded;
            } else {
               this.othersSkin = loaded;
            }
         }

         this.reloadIfChanged();
      }
   }

   public PlayerSkin skinFor(int entityId, PlayerSkin original) {
      Minecraft mc = Minecraft.getInstance();
      return this.skinFor(mc.player != null && entityId == mc.player.getId(), original);
   }

   public PlayerSkin skinFor(UUID profileId, PlayerSkin original) {
      Minecraft mc = Minecraft.getInstance();
      return this.skinFor(mc.player != null && mc.player.getUUID().equals(profileId), original);
   }

   private PlayerSkin skinFor(boolean isSelf, PlayerSkin original) {
      SkinChangeModule.CustomSkin custom = isSelf ? this.selfSkin : this.othersSkin;
      return custom == null ? original : (isSelf ? this.selfSwaps : this.othersSwaps).swap(original, custom);
   }

   @Environment(EnvType.CLIENT)
   private record CustomSkin(Texture body, PlayerModelType model) {
   }

   @Environment(EnvType.CLIENT)
   private static final class SwapCache {
      private static final int MAX = 256;
      private final Map<PlayerSkin, PlayerSkin> swapped = new IdentityHashMap<>();
      private SkinChangeModule.CustomSkin wearing;

      PlayerSkin swap(PlayerSkin original, SkinChangeModule.CustomSkin custom) {
         if (custom != this.wearing || this.swapped.size() >= 256) {
            this.swapped.clear();
            this.wearing = custom;
         }

         PlayerSkin skin = this.swapped.get(original);
         if (skin == null) {
            skin = new PlayerSkin(custom.body(), original.cape(), original.elytra(), custom.model(), original.secure());
            this.swapped.put(original, skin);
         }

         return skin;
      }

      void clear() {
         this.swapped.clear();
         this.wearing = null;
      }
   }
}
