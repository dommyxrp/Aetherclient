package net.spectre.client.gui;

import java.util.*;
import java.util.function.ToIntFunction;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.item.*;
import net.spectre.client.config.ThemeStore;
import net.spectre.client.util.SuspectObjects;
import net.spectre.client.util.SuspectObjects.Category;

/** Screen-projected look card; readable size does not shrink with world distance. */
public final class SuspectPanel {
    public static void draw(GuiGraphicsExtractor g,SuspectObjects.Focus focus,ToIntFunction<Category> colors,boolean limited){
        var mc=Minecraft.getInstance();var theme=ThemeStore.get();var font=mc.font;
        var counts=new EnumMap<Category,Map<SuspectObjects.Icon,Integer>>(Category.class);
        for(var marker:focus.nearby())marker.icons().forEach((item,n)->counts.computeIfAbsent(marker.category(),k->new HashMap<>()).merge(item,n,Integer::sum));
        record Slot(SuspectObjects.Icon icon,int count,Category category){}
        var slots=new ArrayList<Slot>();
        counts.forEach((category,items)->items.entrySet().stream().sorted(Comparator.comparing(e->e.getKey().label())).forEach(e->slots.add(new Slot(e.getKey(),e.getValue(),category))));
        int width = 224, columns = 8, shown = Math.min(24, slots.size()), rows = (shown + columns - 1) / columns;
        var detailLines = focus.target().detail().split("\n");
        int extraDetail = (detailLines.length - 1) * 10;
        int legendRows = (counts.size() + 1) / 2;
        int height = 54 + extraDetail + rows * 27 + legendRows * 12 + 18;
        float baseScale = Math.min(Math.max(1, 2F / mc.getWindow().getGuiScale()) * theme.uiScale.get(), Math.min(g.guiWidth() / 280F, g.guiHeight() / (height + 50F)));
        float scale = baseScale * 0.76F;
        var box = focus.target().bounds();
        var anchor = WorldLabel.project(mc, new net.minecraft.world.phys.Vec3(box.getCenter().x, box.maxY + .35, box.getCenter().z), g.guiWidth(), g.guiHeight());
        if (anchor == null) anchor = WorldLabel.project(mc, box.getCenter(), g.guiWidth(), g.guiHeight());
        if (anchor == null) {
            var camera = mc.gameRenderer.mainCamera();
            var direction = camera.forwardVector();
            var hit = box.clip(camera.position(), camera.position().add(direction.x() * 512, direction.y() * 512, direction.z() * 512));
            if (hit.isPresent()) anchor = WorldLabel.project(mc, hit.get(), g.guiWidth(), g.guiHeight());
        }
        if (anchor == null) return;
        float x, y;
        if (anchor[0] + 16 + width * scale < g.guiWidth() - 8) {
            x = anchor[0] + 16;
            y = anchor[1] - height * scale * .35F;
        } else if (anchor[0] - 16 - width * scale > 8) {
            x = anchor[0] - 16 - width * scale;
            y = anchor[1] - height * scale * .35F;
        } else {
            x = anchor[0] - width * scale * .5F;
            y = anchor[1] - height * scale - 10;
            if (y < 36) y = anchor[1] + 10;
        }
        x = Math.clamp(x, 8, g.guiWidth() - width * scale - 8);
        y = Math.clamp(y, 36, g.guiHeight() - height * scale - 8);
        int ax = Math.round(anchor[0]), ay = Math.round(anchor[1]);
        int edgeX = Math.round(Math.clamp(anchor[0], x, x + width * scale));
        int edgeY = Math.round(Math.clamp(anchor[1], y, y + height * scale));
        int pointerCol = 0x8872E6EF;
        g.fill(Math.min(ax, edgeX), ay, Math.max(ax, edgeX) + 1, ay + 1, pointerCol);
        g.fill(edgeX, Math.min(ay, edgeY), edgeX + 1, Math.max(ay, edgeY) + 1, pointerCol);
        g.fill(ax - 1, ay - 1, ax + 2, ay + 2, 0xFF72E6EF);

        var pose = g.pose();
        pose.pushMatrix();
        pose.translate(x, y);
        pose.scale(scale, scale);

        int radius = Math.min(4, Math.round(theme.rounding.get() * 0.4F));
        // Soft drop shadow
        rounded(g, 0, 2, width, height + 2, 0x40000000, radius);
        // Slate hairline border (not loud neon cyan!)
        rounded(g, 0, 0, width, height, 0x33445A6E, radius);
        // Matte dark slate background
        rounded(g, 1, 1, width - 1, height - 1, 0xEE0B0F15, Math.max(0, radius - 1));

        // Refined accent bar
        g.fill(10, 10, 12, 19, 0xFF72E6EF);
        g.text(font, "AETHER / DISCOVERIES", 16, 11, 0xFFCBD5E1, false);

        String distance = String.format(Locale.ROOT, "%.0fm", focus.distance());
        g.text(font, distance, width - 10 - font.width(distance), 11, 0xFF72E6EF, false);

        String label = font.plainSubstrByWidth(focus.target().label(), width - 20);
        g.text(font, label, 10, 24, colors.applyAsInt(focus.target().category()), false);

        for (int i = 0; i < detailLines.length; i++) {
            g.text(font, font.plainSubstrByWidth(detailLines[i], width - 20), 10, 35 + i * 10, 0xFF94A3B8, false);
        }

        var signals = new HashSet<String>();
        for (var m : focus.nearby()) signals.add(m.category() == Category.GROWTH ? m.label() : m.category().label);
        g.text(font, signals.size() + " clue types nearby", 10, 46 + extraDetail, 0xFF64748B, false);

        // Compact item slot grid
        for (int i = 0; i < shown; i++) {
            var slot = slots.get(i);
            int sx = 10 + (i % columns) * 26;
            int sy = 58 + extraDetail + (i / columns) * 27;

            // Slot background & border
            rounded(g, sx, sy, sx + 24, sy + 24, 0x301E293B, 2);
            rounded(g, sx, sy, sx + 24, sy + 24, 0x1E475569, 2);
            // Subtle category indicator at bottom
            g.fill(sx + 2, sy + 21, sx + 22, sy + 23, colors.applyAsInt(slot.category));

            if (slot.icon.texture() != null) {
                g.blit(slot.icon.texture(), sx + 4, sy + 2, sx + 20, sy + 18, 0, 1, 0, 1);
            } else {
                g.item(new ItemStack(slot.icon.item()), sx + 4, sy + 2);
            }
            String count = String.valueOf(slot.count);
            g.text(font, count, sx + 22 - font.width(count), sy + 13, 0xFFFFFFFF, true);
        }

        // Compact legend
        int ly = 60 + extraDetail + rows * 27, n = 0;
        for (var entry : counts.entrySet()) {
            int lx = 10 + (n % 2) * 106, yy = ly + (n / 2) * 12;
            n++;
            g.fill(lx, yy + 3, lx + 4, yy + 7, colors.applyAsInt(entry.getKey()));
            int count = entry.getValue().values().stream().mapToInt(Integer::intValue).sum();
            String text = count + " " + entry.getKey().label;
            g.text(font, font.plainSubstrByWidth(text, 98), lx + 7, yy, 0xFF94A3B8, false);
        }

        String footer = slots.size() > shown ? "+" + (slots.size() - shown) + " more item types" : limited ? "Detail limit reached" : "Loaded objects / not proof of a base";
        g.text(font, footer, 10, height - 12, 0xFF475569, false);
        pose.popMatrix();
    }
    private static void rounded(GuiGraphicsExtractor g,int x,int y,int right,int bottom,int color,int radius){
        for(int dy=0;dy<radius;dy++){
            int inset=(int)Math.ceil(radius-Math.sqrt(radius*radius-Math.pow(radius-dy-.5,2)));
            g.fill(x+inset,y+dy,right-inset,y+dy+1,color);g.fill(x+inset,bottom-dy-1,right-inset,bottom-dy,color);
        }g.fill(x,y+radius,right,bottom-radius,color);
    }
}
