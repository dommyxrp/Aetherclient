package net.spectre.client.module.impl.misc;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.event.impl.Render3DEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class ChunkMinerModule extends ClientModule {
   public static volatile ChunkMinerModule active;

   private final ModeSetting heightMode = this.addSetting("height-mode", new ModeSetting("Height Mode", "Downwards", "Downwards", "Full Height", "Custom", "Upwards"));
   private final NumberSetting minY = this.addSetting("min-y", new NumberSetting("Floor (Min Y)", -60.0F, -64.0F, 320.0F).step(1.0F));
   private final NumberSetting maxY = this.addSetting("max-y", new NumberSetting("Ceiling (Max Y)", 320.0F, -64.0F, 320.0F).step(1.0F));
   private final ActionSetting setFloorToFeet = this.addSetting("set-floor-feet", new ActionSetting("Set Floor to Feet", () -> {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         this.minY.set((float)Math.floor(mc.player.getY()));
      }
   }));
   private final ActionSetting setCeilingToFeet = this.addSetting("set-ceiling-head", new ActionSetting("Set Ceiling to Head", () -> {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         float feet = (float)Math.floor(mc.player.getY());
         this.maxY.set(feet + 1.0F);
         this.startFeetY = Math.round(feet);
      }
   }));
   private final ActionSetting snapChunk = this.addSetting("snap-chunk", new ActionSetting("Snap Area to My Chunk", this::snapToPlayerChunk));
   private final NumberSetting range = this.addSetting("range", new NumberSetting("Reach Distance", 4.2F, 2.0F, 5.0F).step(0.1F));
   private final BooleanSetting aimCamera = this.addSetting("aim-camera", new BooleanSetting("Aim Camera", true));
   private final NumberSetting aimSpeed = this.addSetting("aim-speed", new NumberSetting("Human Smoothness", 16.0F, 4.0F, 40.0F).step(1.0F));
   private final BooleanSetting autoWalk = this.addSetting("auto-walk", new BooleanSetting("Auto Walk", true));
   private final BooleanSetting autoJump = this.addSetting("auto-jump", new BooleanSetting("Auto Jump Steps", true));
   private final NumberSetting delay = this.addSetting("delay", new NumberSetting("Break Delay (Ticks)", 1.0F, 0.0F, 10.0F).step(1.0F));
   private final BooleanSetting autoTool = this.addSetting("auto-tool", new BooleanSetting("Auto Tool", true));
   private final BooleanSetting skipBedrock = this.addSetting("skip-bedrock", new BooleanSetting("Skip Bedrock", true));
   private final BooleanSetting avoidLiquids = this.addSetting("avoid-liquids", new BooleanSetting("Avoid Fluids", true));
   private final BooleanSetting swingHand = this.addSetting("swing-hand", new BooleanSetting("Swing Hand", true));
   private final BooleanSetting renderEsp = this.addSetting("render-esp", new BooleanSetting("Render Boundaries", true));

   // Fixed 1-chunk coordinates (permanently locked, never changes when player moves)
   private int lockedChunkX = 0;
   private int lockedChunkZ = 0;
   private int startFeetY = Integer.MAX_VALUE;

   private BlockPos currentTarget = null;
   private Direction targetFace = null;
   private BlockPos lastTarget = null;
   private boolean isHoldingAttack = false;
   private int targetLockedTicks = 0;
   private int cooldownTicks = 0;

   // Auto walk state
   private int stuckTicks = 0;
   private double closestDist = Double.MAX_VALUE;
   private BlockPos stuckBlock = null;
   private int stuckCooldown = 0;

   public ChunkMinerModule() {
      super("chunk-miner", "Chunk Miner", "Systematically strip-mines out a fixed 1-chunk area level-by-level downwards with humanized smooth mouse movement.", ModuleCategory.MISC);
      this.autoJump.visibleWhen(this.autoWalk::get);
   }

   public static boolean isMiningActive() {
      ChunkMinerModule mod = active;
      return mod != null && mod.isEnabled();
   }

   public void snapToPlayerChunk() {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         this.lockedChunkX = mc.player.chunkPosition().x();
         this.lockedChunkZ = mc.player.chunkPosition().z();
         this.startFeetY = (int)Math.floor(mc.player.getY());
      }
   }

   @Override
   protected void onEnable() {
      active = this;
      this.snapToPlayerChunk();
      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null) {
         this.startFeetY = (int)Math.floor(mc.player.getY());
      }
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);
      if (mc.gameMode != null && mc.gameMode.isDestroying()) {
         mc.gameMode.stopDestroyBlock();
      }
      mc.missTime = 0;
      this.currentTarget = null;
      this.targetFace = null;
      this.lastTarget = null;
      this.isHoldingAttack = false;
      this.targetLockedTicks = 0;
      this.cooldownTicks = 0;
      this.stuckTicks = 0;
      this.closestDist = Double.MAX_VALUE;
      this.stuckBlock = null;
      this.stuckCooldown = 0;
      this.on(TickEvent.TYPE, this::onTick);
      this.on(Render3DEvent.TYPE, this::onRender3D);
   }

   @Override
   protected void onDisable() {
      active = null;
      Minecraft mc = Minecraft.getInstance();
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);
      if (mc.gameMode != null && mc.gameMode.isDestroying()) {
         mc.gameMode.stopDestroyBlock();
      }
      mc.missTime = 0;
      this.currentTarget = null;
      this.targetFace = null;
      this.lastTarget = null;
      this.isHoldingAttack = false;
      this.targetLockedTicks = 0;
      this.cooldownTicks = 0;
      this.stuckTicks = 0;
      this.closestDist = Double.MAX_VALUE;
      this.stuckBlock = null;
      this.stuckCooldown = 0;
   }

   private void pressAttack(Minecraft mc) {
      mc.missTime = 0;
      KeyMapping key = mc.options.keyAttack;
      if (!this.isHoldingAttack) {
         if (!key.isUnbound()) {
            Key bound = KeyMappingHelper.getBoundKeyOf(key);
            KeyMapping.click(bound);
            KeyMapping.set(bound, true);
         }
         key.setDown(true);
         this.isHoldingAttack = true;
      } else {
         key.setDown(true);
      }
   }

   private void releaseAttack(Minecraft mc) {
      this.isHoldingAttack = false;
      KeyMapping key = mc.options.keyAttack;
      if (!key.isUnbound()) {
         Key bound = KeyMappingHelper.getBoundKeyOf(key);
         KeyMapping.set(bound, false);
      }
      boolean physical = mc.gui.screen() == null && physicallyDown(mc, key);
      key.setDown(physical);
   }

   private void releaseMoveKeys(Minecraft mc) {
      if (mc.options != null) {
         boolean physicalUp = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyUp);
         boolean physicalJump = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyJump);
         mc.options.keyUp.setDown(physicalUp);
         mc.options.keyJump.setDown(physicalJump);
      }
   }

   private static boolean physicallyDown(Minecraft mc, KeyMapping mapping) {
      if (mapping.isUnbound()) {
         return false;
      } else {
         Key key = KeyMappingHelper.getBoundKeyOf(mapping);
         int value = key.getValue();
         if (value < 0) {
            return false;
         } else {
            return switch (key.getType()) {
               case MOUSE -> GLFW.glfwGetMouseButton(mc.getWindow().handle(), value) == 1;
               case KEYSYM -> InputConstants.isKeyDown(mc.getWindow(), value);
               default -> mapping.isDown();
            };
         }
      }
   }

   public void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      ClientLevel level = mc.level;
      MultiPlayerGameMode gameMode = mc.gameMode;
      if (player == null || level == null || gameMode == null || mc.gui.screen() != null) {
         this.releaseAttack(mc);
         this.releaseMoveKeys(mc);
         this.currentTarget = null;
         this.targetFace = null;
         this.targetLockedTicks = 0;
         this.cooldownTicks = 0;
         this.stuckTicks = 0;
         return;
      }

      mc.missTime = 0;

      if (this.stuckCooldown > 0) {
         this.stuckCooldown--;
         if (this.stuckCooldown == 0) {
            this.stuckBlock = null;
         }
      }

      // Fixed 1-chunk boundaries: strictly 16x16 blocks that NEVER change as player moves
      int cx = this.lockedChunkX;
      int cz = this.lockedChunkZ;
      int minX = cx << 4;
      int maxX = minX + 15;
      int minZ = cz << 4;
      int maxZ = minZ + 15;

      int[] heights = this.resolveHeightRange(player);
      int bottomY = heights[0];
      int topY = heights[1];

      float reach = Math.max(3.8F, this.range.get());
      double reachSq = (double)reach * (double)reach;
      Vec3 eyeVec = player.getEyePosition();

      // Step 1: Inter-block cooldown
      if (this.cooldownTicks > 0) {
         this.cooldownTicks--;
         this.releaseAttack(mc);
         this.releaseMoveKeys(mc);
         this.targetLockedTicks = 0;

         if (this.currentTarget == null) {
            this.currentTarget = this.findCandidate(level, player, eyeVec, reach, reachSq, minX, maxX, minZ, maxZ, bottomY, topY);
            if (this.currentTarget != null) {
               this.targetFace = getExposedFace(level, player, this.currentTarget);
            }
         }
         if (this.currentTarget != null && this.targetFace != null) {
            this.aimAt(player, this.currentTarget, this.targetFace);
         }
         return;
      }

      // Step 2: Validate existing target
      if (this.currentTarget != null) {
         BlockState state = level.getBlockState(this.currentTarget);
         if (state.isAir()) {
            // Block successfully broken!
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            this.lastTarget = this.currentTarget;
            this.currentTarget = null;
            this.targetFace = null;
            this.targetLockedTicks = 0;
            this.stuckTicks = 0;
            this.cooldownTicks = Math.max(1, Math.round(this.delay.get()));
            return;
         }

         BlockPos pos = this.currentTarget;
         boolean inBounds = pos.getX() >= minX && pos.getX() <= maxX
            && pos.getZ() >= minZ && pos.getZ() <= maxZ
            && pos.getY() >= bottomY && pos.getY() <= topY + 1;

         boolean validBlock = this.isMineable(level, pos);

         if (!inBounds || !validBlock) {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            if (gameMode.isDestroying()) {
               gameMode.stopDestroyBlock();
            }
            this.currentTarget = null;
            this.targetFace = null;
            this.targetLockedTicks = 0;
            this.stuckTicks = 0;
         }
      }

      // Step 3: Find new target if we don't have one
      if (this.currentTarget == null) {
         this.releaseAttack(mc);
         this.releaseMoveKeys(mc);
         this.targetLockedTicks = 0;
         this.stuckTicks = 0;
         this.currentTarget = this.findCandidate(level, player, eyeVec, reach, reachSq, minX, maxX, minZ, maxZ, bottomY, topY);
         if (this.currentTarget != null) {
            this.targetFace = getExposedFace(level, player, this.currentTarget);
         }
      }

      // Step 4: Execute mining or walking
      if (this.currentTarget != null) {
         BlockState state = level.getBlockState(this.currentTarget);
         if (state.isAir()) {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            this.lastTarget = this.currentTarget;
            this.currentTarget = null;
            this.targetFace = null;
            this.targetLockedTicks = 0;
            this.stuckTicks = 0;
            this.cooldownTicks = Math.max(1, Math.round(this.delay.get()));
            return;
         }

         if (this.targetFace == null) {
            this.targetFace = getExposedFace(level, player, this.currentTarget);
         }
         if (this.targetFace == null) {
            this.targetFace = Direction.UP;
         }

         Vec3 faceCenter = Vec3.atCenterOf(this.currentTarget).add(
            (double)this.targetFace.getStepX() * 0.40,
            (double)this.targetFace.getStepY() * 0.40,
            (double)this.targetFace.getStepZ() * 0.40
         );
         double distSq = eyeVec.distanceToSqr(faceCenter);
         boolean inReach = distSq <= reachSq;

         if (inReach) {
            // Target is within reach: STOP walking and focus on breaking the block
            this.releaseMoveKeys(mc);
            this.stuckTicks = 0;

            boolean onTarget = this.aimAt(player, this.currentTarget, this.targetFace);
            if (onTarget) {
               this.targetLockedTicks++;
               // Humanized delay: wait 3 ticks (150ms) of steady lock on block face before swinging
               if (this.targetLockedTicks >= 3) {
                  if (this.autoTool.get() && !this.isHoldingAttack) {
                     this.equipBestTool(player, state, this.currentTarget);
                  }
                  this.pressAttack(mc);
               }
            } else {
               this.targetLockedTicks = 0;
               this.releaseAttack(mc);
            }
         } else {
            // Target is out of reach: walk towards the block
            this.targetLockedTicks = 0;
            this.releaseAttack(mc);

            if (this.autoWalk.get()) {
               if (player.horizontalCollision) {
                  BlockPos obstacle = this.findObstacleInFront(level, player, minX, maxX, minZ, maxZ);
                  if (obstacle != null) {
                     this.currentTarget = obstacle;
                     this.targetFace = getExposedFace(level, player, obstacle);
                     this.releaseMoveKeys(mc);
                     this.stuckTicks = 0;
                     return;
                  }
               }

               this.walkTowards(player, this.currentTarget, Vec3.atCenterOf(this.currentTarget), eyeVec);
            } else {
               this.releaseMoveKeys(mc);
            }
         }
      } else {
         this.targetLockedTicks = 0;
         this.stuckTicks = 0;
         this.releaseAttack(mc);
         this.releaseMoveKeys(mc);
      }
   }

   private void walkTowards(LocalPlayer player, BlockPos pos, Vec3 targetCenter, Vec3 eyeVec) {
      Minecraft mc = Minecraft.getInstance();
      double px = player.getX();
      double pz = player.getZ();
      double dx = targetCenter.x - px;
      double dz = targetCenter.z - pz;
      float targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));

      if (this.aimCamera.get()) {
         float currentYaw = player.getYRot();
         float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
         if (Math.abs(diffYaw) > 0.5F) {
            // Smooth natural turn rate while walking
            float maxStep = Math.max(0.6F, this.aimSpeed.get() * 0.22F);
            float stepYaw = Mth.clamp(diffYaw * 0.25F, -maxStep, maxStep);
            float quantYaw = quantizeToMouseGcd(mc, stepYaw);
            player.setYRot(currentYaw + quantYaw);
         }
         float currentPitch = player.getXRot();
         float diffPitch = Mth.wrapDegrees(14.0F - currentPitch);
         if (Math.abs(diffPitch) > 0.5F) {
            float stepPitch = Mth.clamp(diffPitch * 0.2F, -2.5F, 2.5F);
            player.setXRot(Mth.clamp(currentPitch + quantizeToMouseGcd(mc, stepPitch), -90.0F, 90.0F));
         }
      }

      // Only walk forward when facing within 35 degrees of destination
      float yawOffset = Math.abs(Mth.wrapDegrees(targetYaw - player.getYRot()));
      if (yawOffset < 35.0F) {
         mc.options.keyUp.setDown(true);
      } else {
         mc.options.keyUp.setDown(false);
      }

      // Auto jump when encountering a 1-block step or water
      if (this.autoJump.get()) {
         if (player.horizontalCollision && player.onGround()) {
            Direction facing = player.getDirection();
            BlockPos stepPos = player.blockPosition().relative(facing);
            BlockPos headPos = stepPos.above();
            BlockState headState = player.level().getBlockState(headPos);
            if (!headState.isSolidRender()) {
               mc.options.keyJump.setDown(true);
            } else {
               mc.options.keyJump.setDown(false);
            }
         } else if (player.isInWater()) {
            mc.options.keyJump.setDown(true);
         } else {
            boolean physical = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyJump);
            mc.options.keyJump.setDown(physical);
         }
      }

      // Stuck detection
      double currentDist = player.distanceToSqr(targetCenter);
      if (currentDist < this.closestDist - 0.25) {
         this.closestDist = currentDist;
         this.stuckTicks = 0;
      } else {
         this.stuckTicks++;
         if (this.stuckTicks > 30) {
            if (player.horizontalCollision) {
               int minX = this.lockedChunkX << 4;
               int maxX = minX + 15;
               int minZ = this.lockedChunkZ << 4;
               int maxZ = minZ + 15;
               BlockPos obstacle = this.findObstacleInFront((ClientLevel)player.level(), player, minX, maxX, minZ, maxZ);
               if (obstacle != null) {
                  this.currentTarget = obstacle;
                  this.targetFace = getExposedFace((ClientLevel)player.level(), player, obstacle);
                  this.releaseMoveKeys(mc);
                  this.stuckTicks = 0;
                  return;
               }
            }

            this.stuckBlock = pos;
            this.stuckCooldown = 40;
            this.currentTarget = null;
            this.targetFace = null;
            this.stuckTicks = 0;
            this.closestDist = Double.MAX_VALUE;
            this.releaseMoveKeys(mc);
         }
      }
   }

   private BlockPos findCandidate(ClientLevel level, LocalPlayer player, Vec3 eyeVec, float reach, double reachSq,
                                  int minX, int maxX, int minZ, int maxZ, int bottomY, int topY) {
      // 0. Only check obstacle if actively colliding horizontally with a wall
      if (player.horizontalCollision) {
         BlockPos obstacle = this.findObstacleInFront(level, player, minX, maxX, minZ, maxZ);
         if (obstacle != null) {
            return obstacle;
         }
      }

      // Find the single active level in the chunk (highest remaining layer with unmined blocks)
      int activeY = this.getActiveLevel(level, minX, maxX, minZ, maxZ, bottomY, topY);
      if (activeY < bottomY) {
         return null; // Entire chunk is completely excavated down to bottomY!
      }

      // 1. Strip mine priority: On activeY, mine all reachable blocks around player (nearest first)
      BlockPos reachable = this.findReachableOnActiveLevel(level, player, eyeVec, reachSq, activeY, minX, maxX, minZ, maxZ);
      if (reachable != null) {
         return reachable;
      }

      // 2. If no block on activeY is within reach, walk along the flat floor to the closest block on activeY
      if (this.autoWalk.get()) {
         return this.findClosestOnActiveLevel(level, player, eyeVec, activeY, minX, maxX, minZ, maxZ);
      }

      return null;
   }

   private int getActiveLevel(ClientLevel level, int minX, int maxX, int minZ, int maxZ, int bottomY, int topY) {
      for (int y = topY; y >= bottomY; y--) {
         for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
               BlockPos pos = new BlockPos(x, y, z);
               if (pos.equals(this.stuckBlock) && this.stuckCooldown > 0) continue;
               if (this.isMineable(level, pos)) {
                  return y; // Active level! Must be completely cleared before dropping down!
               }
            }
         }
      }
      return -1;
   }

   private BlockPos findReachableOnActiveLevel(ClientLevel level, LocalPlayer player, Vec3 eyeVec, double reachSq,
                                               int activeY, int minX, int maxX, int minZ, int maxZ) {
      BlockPos playerFeet = player.blockPosition();
      BlockPos underFeet = playerFeet.below();

      int eyeX = (int)Math.floor(eyeVec.x);
      int eyeZ = (int)Math.floor(eyeVec.z);
      int r = 5;

      int startX = Math.max(minX, eyeX - r);
      int endX = Math.min(maxX, eyeX + r);
      int startZ = Math.max(minZ, eyeZ - r);
      int endZ = Math.min(maxZ, eyeZ + r);

      BlockPos bestPos = null;
      double bestScore = Double.NEGATIVE_INFINITY;
      BlockPos feetFallback = null;

      for (int x = startX; x <= endX; x++) {
         for (int z = startZ; z <= endZ; z++) {
            BlockPos candidate = new BlockPos(x, activeY, z);
            if (candidate.equals(this.stuckBlock) && this.stuckCooldown > 0) continue;
            if (!this.isMineable(level, candidate)) continue;

            Direction exposed = getExposedFace(level, player, candidate);
            if (exposed == null) continue;

            Vec3 faceCenter = Vec3.atCenterOf(candidate).add(
               (double)exposed.getStepX() * 0.40,
               (double)exposed.getStepY() * 0.40,
               (double)exposed.getStepZ() * 0.40
            );
            double distEye = eyeVec.distanceToSqr(faceCenter);
            if (distEye > reachSq) continue;

            // If standing directly on or inside candidate, delay until other reachable blocks are cleared
            if (candidate.equals(underFeet) || candidate.equals(playerFeet)) {
               feetFallback = candidate;
               continue;
            }

            // Nearest first with adjacent-block continuity bonus
            double distLast = (this.lastTarget != null) ? this.lastTarget.distSqr(candidate) : 0.0;
            double score = 1000.0 - (distEye * 8.0) - (distLast * 3.0);

            if (score > bestScore) {
               bestScore = score;
               bestPos = candidate;
            }
         }
      }

      if (bestPos != null) {
         return bestPos;
      }

      // If feet block is the only reachable block on this level:
      // Only break it if there are NO other blocks remaining on activeY anywhere in the 16x16 chunk!
      if (feetFallback != null) {
         if (!this.hasOtherBlocksOnLevel(level, activeY, minX, maxX, minZ, maxZ, feetFallback)) {
            return feetFallback; // Last block on this level! Breaking it drops player to the next level!
         }
      }

      return null;
   }

   private boolean hasOtherBlocksOnLevel(ClientLevel level, int activeY, int minX, int maxX, int minZ, int maxZ, BlockPos exclude) {
      for (int x = minX; x <= maxX; x++) {
         for (int z = minZ; z <= maxZ; z++) {
            BlockPos pos = new BlockPos(x, activeY, z);
            if (pos.equals(exclude)) continue;
            if (this.isMineable(level, pos)) {
               return true;
            }
         }
      }
      return false;
   }

   private BlockPos findClosestOnActiveLevel(ClientLevel level, LocalPlayer player, Vec3 eyeVec,
                                             int activeY, int minX, int maxX, int minZ, int maxZ) {
      BlockPos bestCandidate = null;
      double bestDistSq = Double.MAX_VALUE;

      for (int x = minX; x <= maxX; x++) {
         for (int z = minZ; z <= maxZ; z++) {
            BlockPos candidate = new BlockPos(x, activeY, z);
            if (candidate.equals(this.stuckBlock) && this.stuckCooldown > 0) continue;
            if (!this.isMineable(level, candidate)) continue;

            double distSq = eyeVec.distanceToSqr(Vec3.atCenterOf(candidate));
            if (distSq < bestDistSq) {
               bestDistSq = distSq;
               bestCandidate = candidate;
            }
         }
      }

      return bestCandidate;
   }

   private BlockPos findObstacleInFront(ClientLevel level, LocalPlayer player, int minX, int maxX, int minZ, int maxZ) {
      Direction facing = player.getDirection();
      BlockPos feet = player.blockPosition();
      BlockPos frontFeet = feet.relative(facing);
      BlockPos frontBody = frontFeet.above();

      for (BlockPos candidate : new BlockPos[]{frontBody, frontFeet}) {
         if (candidate.getX() >= minX && candidate.getX() <= maxX && candidate.getZ() >= minZ && candidate.getZ() <= maxZ) {
            if (this.isMineable(level, candidate)) {
               Direction face = getExposedFace(level, player, candidate);
               if (face != null) {
                  return candidate;
               }
            }
         }
      }

      return null;
   }

   private boolean isMineable(ClientLevel level, BlockPos pos) {
      BlockState state = level.getBlockState(pos);
      if (state.isAir() || !state.getFluidState().isEmpty()) {
         return false;
      }
      if (this.skipBedrock.get() && (state.getDestroySpeed(level, pos) < 0 || state.is(Blocks.BEDROCK))) {
         return false;
      }
      if (this.avoidLiquids.get()) {
         BlockState above = level.getBlockState(pos.above());
         if (!above.getFluidState().isEmpty()) {
            return false;
         }
      }
      return true;
   }

   public void onRender3D(Render3DEvent event) {
      if (!this.renderEsp.get()) return;
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player == null || mc.level == null) return;

      int cx = this.lockedChunkX;
      int cz = this.lockedChunkZ;

      double x0 = cx << 4;
      double x1 = x0 + 16.0;
      double z0 = cz << 4;
      double z1 = z0 + 16.0;

      int[] heights = this.resolveHeightRange(player);
      double y0 = heights[0];
      double y1 = heights[1] + 1.0;

      AABB chunkBox = new AABB(x0, y0, z0, x1, y1, z1);
      Gizmos.cuboid(chunkBox, GizmoStyle.stroke(0x6672E6EF, 1.5F));

      BlockPos target = this.currentTarget;
      if (target != null) {
         AABB targetBox = new AABB(target);
         Gizmos.cuboid(targetBox, GizmoStyle.strokeAndFill(0xFF72E6EF, 2.0F, 0x3372E6EF));

         double distSq = player.getEyePosition().distanceToSqr(Vec3.atCenterOf(target));
         float reach = Math.max(3.8F, this.range.get());
         if (distSq > (double)reach * (double)reach) {
            Gizmos.line(player.getEyePosition(), Vec3.atCenterOf(target), 0xFF72E6EF, 1.5F);
         }
      }
   }

   private int[] resolveHeightRange(LocalPlayer player) {
      int bottomY = Math.round(this.minY.get());
      int topY = Math.round(this.maxY.get());

      if (this.heightMode.is("Downwards")) {
         int ceiling = Math.min(this.startFeetY + 1, topY);
         topY = Math.max(bottomY, ceiling);
      } else if (this.heightMode.is("Upwards")) {
         int feetY = (int)Math.floor(player.getY());
         bottomY = Math.max(bottomY, feetY);
         topY = Math.max(bottomY, topY);
      } else if (this.heightMode.is("Full Height")) {
         bottomY = Math.round(this.minY.get());
         topY = Math.round(this.maxY.get());
      } else {
         int min = Math.min(bottomY, topY);
         int max = Math.max(bottomY, topY);
         bottomY = min;
         topY = max;
      }

      return new int[]{bottomY, topY};
   }

   private boolean aimAt(LocalPlayer player, BlockPos pos, Direction face) {
      if (!this.aimCamera.get()) {
         Vec3 center = Vec3.atCenterOf(pos);
         Minecraft.getInstance().hitResult = new BlockHitResult(center, face, pos, false);
         return true;
      }

      Vec3 faceCenter = Vec3.atCenterOf(pos).add(
         (double)face.getStepX() * 0.40,
         (double)face.getStepY() * 0.40,
         (double)face.getStepZ() * 0.40
      );
      Vec3 eye = player.getEyePosition();
      Vec3 delta = faceCenter.subtract(eye);
      double distXZ = Math.hypot(delta.x, delta.z);
      float targetYaw = (float)Math.toDegrees(Math.atan2(-delta.x, delta.z));
      float targetPitch = (float)-Math.toDegrees(Math.atan2(delta.y, distXZ));

      Minecraft mc = Minecraft.getInstance();
      float currentYaw = player.getYRot();
      float currentPitch = player.getXRot();
      float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
      float diffPitch = Mth.wrapDegrees(targetPitch - currentPitch);
      float totalDiff = (float)Math.hypot(diffYaw, diffPitch);

      // Deadzone: if aligned within 0.35 degrees, lock steady with zero jitter
      if (totalDiff > 0.35F) {
         // Human smooth mouse movement curve: gentle deceleration as crosshair nears block face
         float t = Mth.clamp(totalDiff / 16.0F, 0.08F, 1.0F);
         float ease = (float)(1.0 - Math.pow(1.0 - t, 2.2));
         float maxStep = Math.max(0.35F, this.aimSpeed.get() * 0.20F * ease);

         float stepYaw = Mth.clamp(diffYaw * 0.35F, -maxStep, maxStep);
         float stepPitch = Mth.clamp(diffPitch * 0.35F, -maxStep, maxStep);

         float quantYaw = quantizeToMouseGcd(mc, stepYaw);
         float quantPitch = quantizeToMouseGcd(mc, stepPitch);

         player.setYRot(currentYaw + quantYaw);
         player.setXRot(Mth.clamp(currentPitch + quantPitch, -90.0F, 90.0F));
      }

      // Check if crosshair is actually on the target block
      ClientLevel level = (ClientLevel)player.level();
      Vec3 look = player.getViewVector(1.0F);
      Vec3 reachEnd = eye.add(look.scale(Math.max(4.5, (double)this.range.get())));
      BlockHitResult hit = level.clip(new ClipContext(eye, reachEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
      boolean rayHit = (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos));

      if (rayHit) {
         this.targetFace = hit.getDirection();
         Minecraft.getInstance().hitResult = hit;
         return totalDiff < 2.0F; // Only ready to break when crosshair has smoothly arrived within 2 degrees
      }

      return false;
   }

   private float quantizeToMouseGcd(Minecraft mc, float value) {
      float sensitivity = mc.options.sensitivity().get().floatValue();
      float f = sensitivity * 0.6F + 0.2F;
      float gcd = f * f * f * 8.0F * 0.15F;
      if (gcd <= 0.0001F) return value;
      return Math.round(value / gcd) * gcd;
   }

   private static Direction getExposedFace(ClientLevel level, LocalPlayer player, BlockPos pos) {
      Vec3 eye = player.getEyePosition();
      Direction bestFace = null;
      double bestDist = Double.MAX_VALUE;

      for (Direction face : Direction.values()) {
         BlockPos neighbor = pos.relative(face);
         BlockState neighborState = level.getBlockState(neighbor);
         if (!neighborState.isSolidRender()) {
            Vec3 faceCenter = Vec3.atCenterOf(pos).add(
               (double)face.getStepX() * 0.40,
               (double)face.getStepY() * 0.40,
               (double)face.getStepZ() * 0.40
            );

            BlockHitResult clip = level.clip(new ClipContext(eye, faceCenter, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (clip.getType() == HitResult.Type.MISS || clip.getBlockPos().equals(pos)) {
               double dist = eye.distanceToSqr(faceCenter);
               if (dist < bestDist) {
                  bestDist = dist;
                  bestFace = face;
               }
            }
         }
      }

      if (bestFace == null) {
         for (Direction face : Direction.values()) {
            if (!level.getBlockState(pos.relative(face)).isSolidRender()) {
               return face;
            }
         }
      }

      return bestFace;
   }

   private void equipBestTool(LocalPlayer player, BlockState state, BlockPos pos) {
      if (this.isHoldingAttack) return;
      Inventory inv = player.getInventory();
      int currentSlot = inv.getSelectedSlot();
      int bestSlot = currentSlot;
      float bestProgress = state.getDestroyProgress(player, player.level(), pos);

      for (int i = 0; i < 9; i++) {
         if (i == currentSlot) continue;
         ItemStack stack = inv.getItem(i);
         if (stack.isEmpty()) continue;
         inv.setSelectedSlot(i);
         float progress = state.getDestroyProgress(player, player.level(), pos);
         if (progress > bestProgress) {
            bestProgress = progress;
            bestSlot = i;
         }
      }

      inv.setSelectedSlot(bestSlot);
      if (bestSlot != currentSlot && player.connection != null) {
         player.connection.send(new ServerboundSetCarriedItemPacket(bestSlot));
      }
   }
}
