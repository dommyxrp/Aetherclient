package net.spectre.client.gui;

import imgui.ImDrawList;
import imgui.flag.ImDrawListFlags;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleRegistry;

/** Native procedural ghost: articulated limbs, deforming hem and animated prop entrances. */
public final class WorkspaceMascot {
    private static GhostRig rig = new GhostRig();
    private static GhostRig brandRig = new GhostRig();
    private static GhostRig splashRig = new GhostRig();
    private WorkspaceMascot() { }
    private static MascotFocus focus=new MascotFocus();
    public static void noteToggle(ClientModule module){focus.toggled(module.id(),module.isEnabled(),module.enabledByDefault());}
    public static void noteAction(String id){focus.action(id,System.nanoTime()/1_000_000L);}
    public static String activeModule(){
        java.util.List<String> enabled=new java.util.ArrayList<>(),eligible=new java.util.ArrayList<>(),working=new java.util.ArrayList<>();
        for(ClientModule module:ModuleRegistry.all()){
            if(module.isEnabled()){enabled.add(module.id());if(!module.enabledByDefault())eligible.add(module.id());}
            if(module.mascotTaskActive())working.add(module.id());
        }
        return focus.update(enabled,eligible,working,System.nanoTime()/1_000_000L);
    }
    static void drawHudEmblem(ImDrawList dl,float cx,float cy,float size,float alpha){
        drawAetherCrystal(dl, cx, cy, size * 0.48f, alpha, -1.0f, false);
    }
    static void draw(ImDrawList dl, float x, float y, float size, MascotAnimation.Mood ignored) {
        drawAetherCrystal(dl, x + size * 0.5f, y + size * 0.5f, size * 0.45f, 1.0f, -1.0f, false);
    }
    /** The Aether Celestial Prism in its neutral pose for branding. */
    public static void drawBrand(ImDrawList dl,float cx,float cy,float size,float alpha) {
        drawAetherCrystal(dl, cx, cy, size * 0.48f, alpha, -1.0f, false);
    }
    public static void drawSplash(ImDrawList dl,float cx,float cy,float size,float alpha,float progress) {
        drawAetherCrystal(dl, cx, cy, size * 0.48f, alpha, progress, true);
    }

    public static void drawAetherCrystal(ImDrawList dl, float cx, float cy, float radius, float alpha, float progress, boolean isSplash) {
        if (alpha <= 0.001f || radius <= 1.0f) return;
        boolean still = GuiPalette.animationSpeed() <= 0;
        float t = still ? 0.0f : (float)(System.nanoTime() / 1_000_000L) / 1000.0f;
        float bob = still ? 0.0f : (float)Math.sin(t * 2.2) * (radius * 0.06f);
        float coreY = cy + bob;
        
        // 1. Celestial Core Aura Glow
        SpectreDraw.glow(dl, cx, coreY, radius * 0.95f, 0x0072e6ef, 0.35f * alpha);
        SpectreDraw.glow(dl, cx, coreY, radius * 0.5f, 0x003888ff, 0.45f * alpha);

        // 2. Gyroscopic Orbital Celestial Rings
        float ringRadius = radius * 1.15f;
        drawOrbitalRing(dl, cx, coreY, ringRadius, ringRadius * 0.35f, 0.38f, t * 0.5f, 0x6672e6ef, alpha, progress, isSplash);
        drawOrbitalRing(dl, cx, coreY, ringRadius * 0.92f, ringRadius * 0.28f, -0.55f, -t * 0.4f, 0x443888ff, alpha, -1.0f, false);

        // 3. 3D Rotating Isometric Octahedron Crystal Facets
        float rot = still ? 0.6f : t * 0.85f;
        float eqR = radius * 0.62f;
        float topY = coreY - radius * 0.92f;
        float botY = coreY + radius * 0.92f;
        
        float[] vx = new float[4];
        float[] vy = new float[4];
        for (int i = 0; i < 4; i++) {
            double angle = rot + i * (Math.PI / 2.0);
            vx[i] = cx + (float)Math.cos(angle) * eqR;
            vy[i] = coreY + (float)Math.sin(angle) * (eqR * 0.26f);
        }

        for (int i = 0; i < 4; i++) {
            int next = (i + 1) % 4;
            float cross = (vx[next] - vx[i]) * (topY - vy[i]) - (vy[next] - vy[i]) * (cx - vx[i]);
            if (cross < 0) {
                float light = 0.5f + 0.5f * (float)Math.sin(rot + i * (Math.PI / 2.0) + 0.8f);
                int upperColor = SpectreDraw.mix(0xdd2588c8, 0xee72e6ef, light);
                int lowerColor = SpectreDraw.mix(0xcc144275, 0xdd3888ff, light);

                dl.addTriangleFilled(cx, topY, vx[i], vy[i], vx[next], vy[next], SpectreDraw.col(upperColor, alpha));
                dl.addTriangleFilled(cx, botY, vx[next], vy[next], vx[i], vy[i], SpectreDraw.col(lowerColor, alpha));

                dl.addLine(cx, topY, vx[i], vy[i], SpectreDraw.col(0xffffffff, 0.85f * alpha), 1.4f);
                dl.addLine(cx, topY, vx[next], vy[next], SpectreDraw.col(0xffffffff, 0.85f * alpha), 1.4f);
                dl.addLine(vx[i], vy[i], vx[next], vy[next], SpectreDraw.col(0xff72e6ef, 0.7f * alpha), 1.2f);
                dl.addLine(cx, botY, vx[i], vy[i], SpectreDraw.col(0xff52a5f5, 0.65f * alpha), 1.2f);
                dl.addLine(cx, botY, vx[next], vy[next], SpectreDraw.col(0xff52a5f5, 0.65f * alpha), 1.2f);
            }
        }

        // 4. Inner Glowing Radiant Core
        float coreR = radius * 0.26f;
        float pulse = 0.85f + 0.15f * (float)Math.sin(t * 3.5);
        dl.addTriangleFilled(cx, coreY - coreR * pulse, cx - coreR * 0.6f * pulse, coreY, cx + coreR * 0.6f * pulse, coreY, SpectreDraw.col(0xffffffff, 0.9f * alpha));
        dl.addTriangleFilled(cx, coreY + coreR * pulse, cx - coreR * 0.6f * pulse, coreY, cx + coreR * 0.6f * pulse, coreY, SpectreDraw.col(0xff72e6ef, 0.85f * alpha));

        // 5. Apex Crown Star Sparkles
        float starA = (0.7f + 0.3f * (float)Math.sin(t * 4.0)) * alpha;
        dl.addCircleFilled(cx, topY, Math.max(1.5f, radius * 0.045f), SpectreDraw.col(0xffffffff, starA), 12);
        dl.addCircleFilled(cx, botY, Math.max(1.0f, radius * 0.03f), SpectreDraw.col(0xff72e6ef, starA * 0.8f), 10);
    }

    private static void drawOrbitalRing(ImDrawList dl, float cx, float cy, float rx, float ry, float tilt, float phase, int color, float alpha, float progress, boolean isSplash) {
        int steps = 48;
        float cosT = (float)Math.cos(tilt);
        float sinT = (float)Math.sin(tilt);
        int maxStep = (isSplash && progress >= 0) ? Math.max(2, (int)(steps * Math.min(1.0f, progress))) : steps;
        
        for (int i = 0; i < maxStep; i++) {
            double a1 = phase + i * (Math.PI * 2.0 / steps);
            double a2 = phase + (i + 1) * (Math.PI * 2.0 / steps);
            float px1 = (float)Math.cos(a1) * rx;
            float py1 = (float)Math.sin(a1) * ry;
            float px2 = (float)Math.cos(a2) * rx;
            float py2 = (float)Math.sin(a2) * ry;

            float x1 = cx + px1 * cosT - py1 * sinT;
            float y1 = cy + px1 * sinT + py1 * cosT;
            float x2 = cx + px2 * cosT - py2 * sinT;
            float y2 = cy + px2 * sinT + py2 * cosT;

            float segA = (0.35f + 0.45f * (float)Math.sin(a1)) * alpha;
            int ringCol = isSplash ? SpectreDraw.col(0xff72e6ef, segA) : SpectreDraw.col(color, segA);
            dl.addLine(x1, y1, x2, y2, ringCol, isSplash ? 2.0f : 1.2f);
        }

        double nodeAngle = phase * 2.0;
        float nx = cx + (float)Math.cos(nodeAngle) * rx * cosT - (float)Math.sin(nodeAngle) * ry * sinT;
        float ny = cy + (float)Math.cos(nodeAngle) * rx * sinT + (float)Math.sin(nodeAngle) * ry * cosT;
        dl.addCircleFilled(nx, ny, 2.5f, SpectreDraw.col(0xffffffff, 0.9f * alpha), 8);
    }
    private static void drawRig(ImDrawList dl,float x,float y,float size,float alpha,GhostRig character,String module) {
        character.draw(canvas(dl,x,y,size,alpha),module,System.nanoTime()/1_000_000L,GuiPalette.animationSpeed()<=0);
    }
    private static GhostRig.Canvas canvas(ImDrawList dl,float x,float y,float size,float alpha) {
        float scale=size/256F;
        return new GhostRig.Canvas() {
            public void polygon(float[] xy,int argb) {
                int color=SpectreWidgets.c(SpectreDraw.col(argb,alpha));
                int[] triangles=GhostMesh.triangles(xy);
                // Fringes on every triangle expose internal edges in the cloth.
                int flags=dl.getFlags();
                dl.setFlags(flags & ~ImDrawListFlags.AntiAliasedFill);
                try { for(int i=0;i<triangles.length;i+=3){int a=triangles[i]*2,b=triangles[i+1]*2,c=triangles[i+2]*2;
                    dl.addTriangleFilled(x+xy[a]*scale,y+xy[a+1]*scale,x+xy[b]*scale,y+xy[b+1]*scale,x+xy[c]*scale,y+xy[c+1]*scale,color);
                }} finally { dl.setFlags(flags); }
            }
            public void line(float[] xy,int argb,float width) {
                int color=SpectreWidgets.c(SpectreDraw.col(argb,alpha));
                for(int i=0;i<xy.length;i+=2){
                    float px=x+xy[i]*scale,py=y+xy[i+1]*scale;
                    dl.addCircleFilled(px,py,width*scale/2,color,12);
                    if(i+2<xy.length)dl.addLine(px,py,x+xy[i+2]*scale,y+xy[i+3]*scale,color,width*scale);
                }
            }
        };
    }
    public static void dispose() { rig=new GhostRig();brandRig=new GhostRig();splashRig=new GhostRig();focus=new MascotFocus(); }
}
