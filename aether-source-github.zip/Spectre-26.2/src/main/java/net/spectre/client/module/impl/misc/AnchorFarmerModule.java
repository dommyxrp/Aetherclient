package net.spectre.client.module.impl.misc;

import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.platform.InputConstants.Key;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.network.chat.ClickEvent;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.network.protocol.game.ClientboundDisguisedChatPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.level.chunk.LevelChunkSection;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.impl.PacketReceiveNettyEvent;
import net.spectre.client.event.impl.Render3DEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.NumberSetting;
import net.spectre.client.module.setting.StringSetting;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class AnchorFarmerModule extends ClientModule {
   public static volatile AnchorFarmerModule active;

   private final StringSetting rtpCommand = this.addSetting("rtp-cmd", new StringSetting("RTP Command", "/rtp"));
   private final StringSetting sellCommand = this.addSetting("sell-cmd", new StringSetting("Sell Command", "/sell all"));
   private final BooleanSetting autoSell = this.addSetting("auto-sell", new BooleanSetting("Auto Sell", true));
   private final BooleanSetting autoConfirmChat = this.addSetting("auto-confirm-chat", new BooleanSetting("Auto Click Chat [HERE]", true));
   private final BooleanSetting autoRtpGui = this.addSetting("auto-rtp-gui", new BooleanSetting("Auto Click RTP GUI", true));
   private final NumberSetting rtpDelay = this.addSetting("rtp-delay", new NumberSetting("RTP Delay (s)", 3.5F, 1.0F, 15.0F).step(0.5F));
   private final NumberSetting rtpCooldown = this.addSetting("rtp-cooldown", new NumberSetting("RTP Cooldown (s)", 0.0F, 0.0F, 60.0F).step(1.0F));
   private final NumberSetting scanRadius = this.addSetting("scan-radius", new NumberSetting("Scan Radius", 64.0F, 16.0F, 160.0F).step(16.0F));
   private final NumberSetting ignoreSpawnRadius = this.addSetting("ignore-spawn", new NumberSetting("Ignore Spawn Radius", 256.0F, 0.0F, 1000.0F).step(32.0F));
   private final NumberSetting reachDistance = this.addSetting("reach", new NumberSetting("Reach Distance", 4.2F, 2.5F, 5.0F).step(0.1F));
   private final NumberSetting mineTimeout = this.addSetting("mine-timeout", new NumberSetting("Break Timeout (s)", 25.0F, 5.0F, 60.0F).step(1.0F));
   private final BooleanSetting autoTool = this.addSetting("auto-tool", new BooleanSetting("Auto Best Pickaxe", true));
   private final BooleanSetting autoWalk = this.addSetting("auto-walk", new BooleanSetting("Auto Walk", true));
   private final BooleanSetting autoJump = this.addSetting("auto-jump", new BooleanSetting("Auto Jump", true));
   private final BooleanSetting smoothAim = this.addSetting("smooth-aim", new BooleanSetting("Humanized Aim", true));
   private final NumberSetting aimSpeed = this.addSetting("aim-speed", new NumberSetting("Aim Speed", 16.0F, 4.0F, 40.0F).step(1.0F));
   private final BooleanSetting collectItems = this.addSetting("collect-items", new BooleanSetting("Collect Drops", true));
   private final BooleanSetting swingHand = this.addSetting("swing-hand", new BooleanSetting("Swing Hand", true));
   private final BooleanSetting renderEsp = this.addSetting("render-esp", new BooleanSetting("Render ESP", true));

   private final ActionSetting clearBlacklist = this.addSetting("clear-blacklist", new ActionSetting("Clear Blacklist", () -> {
      this.blacklisted.clear();
      ModuleChat.send(this, "Cleared anchor blacklist.");
   }));

   private enum State {
      IDLE,
      SEND_RTP,
      WAITING_RTP,
      SCANNING,
      NAVIGATING,
      MINING,
      COLLECTING,
      SELLING,
      COOLDOWN_WAIT
   }

   private State state = State.IDLE;
   private int stateTicks = 0;
   private int mineTicks = 0;
   private int stuckTicks = 0;
   private int targetLockedTicks = 0;
   private int anchorsMinedTotal = 0;
   private int waitingTeleportTicks = 0;
   private double closestDist = Double.MAX_VALUE;
   private Vec3 preTeleportPos = null;

   private BlockPos currentTarget = null;
   private Direction targetFace = null;
   private final List<BlockPos> foundAnchors = new ArrayList<>();
   private final Set<BlockPos> blacklisted = new HashSet<>();
   private boolean isHoldingAttack = false;

   public AnchorFarmerModule() {
      super("anchor-farmer", "Anchor Farmer", "Automates finding respawn anchors via /rtp, walking to them, mining them with optimal pickaxe, and selling them with /sell.", ModuleCategory.DONUT);
      this.usesNotifications();
      this.autoJump.visibleWhen(this.autoWalk::get);
      this.sellCommand.visibleWhen(this.autoSell::get);
   }

   @Override
   protected void onEnable() {
      active = this;
      Minecraft mc = Minecraft.getInstance();
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);
      if (mc.gameMode != null && mc.gameMode.isDestroying()) {
         mc.gameMode.stopDestroyBlock();
      }
      this.state = State.SEND_RTP;
      this.stateTicks = 0;
      this.mineTicks = 0;
      this.stuckTicks = 0;
      this.targetLockedTicks = 0;
      this.anchorsMinedTotal = 0;
      this.waitingTeleportTicks = 0;
      this.preTeleportPos = null;
      this.currentTarget = null;
      this.targetFace = null;
      this.foundAnchors.clear();
      this.blacklisted.clear();
      this.isHoldingAttack = false;

      this.on(TickEvent.TYPE, this::onTick);
      this.on(Render3DEvent.TYPE, this::onRender3D);
      this.on(PacketReceiveNettyEvent.TYPE, this::onPacketReceive);
      ModuleChat.send(this, ModuleChat.body().good("Anchor Farmer activated").text(". Initiating RTP loop..."));
   }

   @Override
   protected void onDisable() {
      active = null;
      Minecraft mc = Minecraft.getInstance();
      this.releaseAttack(mc);
      this.releaseMoveKeys(mc);
      if (mc.gameMode != null && mc.gameMode.isDestroying()) {
         mc.gameMode.stopDestroyBlock();
      }
      this.state = State.IDLE;
      this.currentTarget = null;
      this.targetFace = null;
      this.foundAnchors.clear();
      this.blacklisted.clear();
      this.isHoldingAttack = false;
      ModuleChat.send(this, ModuleChat.body().warn("Anchor Farmer disabled").text(". Total anchors mined: ").value(this.anchorsMinedTotal));
   }

   private void onPacketReceive(PacketReceiveNettyEvent event) {
      if (!this.autoConfirmChat.get()) return;
      if (this.state != State.WAITING_RTP && this.state != State.SEND_RTP) return;

      if (event.packet instanceof ClientboundSystemChatPacket chat && chat.content() != null) {
         this.handleChatComponent(chat.content());
      } else if (event.packet instanceof ClientboundDisguisedChatPacket disguised && disguised.message() != null) {
         this.handleChatComponent(disguised.message());
      } else if (event.packet instanceof ClientboundPlayerChatPacket playerChat && playerChat.unsignedContent() != null) {
         this.handleChatComponent(playerChat.unsignedContent());
      }
   }

   private void handleChatComponent(Component component) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null || mc.getConnection() == null) return;

      String fullText = component.getString().toLowerCase(Locale.ROOT);
      component.visit((style, text) -> {
         ClickEvent click = style.getClickEvent();
         if (click instanceof ClickEvent.RunCommand runCmd) {
            String cmd = runCmd.command();
            String lowerCmd = cmd.toLowerCase(Locale.ROOT);
            if (lowerCmd.contains("rtp") || lowerCmd.contains("wild") || lowerCmd.contains("confirm") || fullText.contains("rtp") || fullText.contains("here")) {
               mc.execute(() -> {
                  if (mc.getConnection() != null) {
                     ModuleChat.send(this, ModuleChat.body().good("Auto-confirmed RTP prompt: ").value(cmd));
                     if (cmd.startsWith("/")) {
                        mc.getConnection().sendCommand(cmd.substring(1));
                     } else {
                        mc.getConnection().sendChat(cmd);
                     }
                     this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
                     this.waitingTeleportTicks = 0;
                  }
               });
               return Optional.of(true);
            }
         } else if (click instanceof ClickEvent.SuggestCommand suggestCmd) {
            String cmd = suggestCmd.command();
            String lowerCmd = cmd.toLowerCase(Locale.ROOT);
            if (lowerCmd.contains("rtp") || lowerCmd.contains("wild") || lowerCmd.contains("confirm") || fullText.contains("rtp") || fullText.contains("here")) {
               mc.execute(() -> {
                  if (mc.getConnection() != null) {
                     ModuleChat.send(this, ModuleChat.body().good("Auto-confirmed RTP prompt: ").value(cmd));
                     if (cmd.startsWith("/")) {
                        mc.getConnection().sendCommand(cmd.substring(1));
                     } else {
                        mc.getConnection().sendChat(cmd);
                     }
                     this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
                     this.waitingTeleportTicks = 0;
                  }
               });
               return Optional.of(true);
            }
         }
         return Optional.empty();
      }, Style.EMPTY);
   }

   private void checkRtpGui(Minecraft mc, LocalPlayer player) {
      if (!this.autoRtpGui.get()) return;
      if (mc.gui.screen() instanceof AbstractContainerScreen<?> containerScreen && player.containerMenu != null) {
         String title = containerScreen.getTitle().getString().toLowerCase(Locale.ROOT);
         if (title.contains("rtp") || title.contains("teleport") || title.contains("wild") || title.contains("dimension") || title.contains("world") || title.contains("random")) {
            int bestSlot = -1;
            for (int i = 0; i < player.containerMenu.slots.size() - 36; i++) {
               ItemStack stack = player.containerMenu.getSlot(i).getItem();
               if (!stack.isEmpty()) {
                  String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
                  if (name.contains("overworld") || name.contains("wild") || name.contains("rtp") || name.contains("random")) {
                     bestSlot = i;
                     break;
                  } else if (bestSlot == -1) {
                     bestSlot = i;
                  }
               }
            }
            if (bestSlot != -1) {
               int slotToClick = bestSlot;
               mc.gameMode.handleContainerInput(player.containerMenu.containerId, slotToClick, 0, ContainerInput.PICKUP, player);
               player.closeContainer();
               ModuleChat.send(this, ModuleChat.body().good("Auto-selected RTP menu slot ").value(slotToClick));
               this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
               this.waitingTeleportTicks = 0;
            }
         }
      }
   }

   public void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      ClientLevel level = mc.level;
      MultiPlayerGameMode gameMode = mc.gameMode;

      if (player == null || level == null || gameMode == null) {
         this.releaseAttack(mc);
         this.releaseMoveKeys(mc);
         return;
      }

      mc.missTime = 0;

      switch (this.state) {
         case SEND_RTP -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            String cmd = this.rtpCommand.get().trim();
            if (!cmd.isEmpty() && mc.getConnection() != null) {
               if (cmd.startsWith("/")) {
                  mc.getConnection().sendCommand(cmd.substring(1));
               } else {
                  mc.getConnection().sendChat(cmd);
               }
            }
            ModuleChat.actionBar(this, ModuleChat.body().text("Sent ").value(cmd).text(", waiting for chunks..."));
            this.stateTicks = Math.round(this.rtpDelay.get() * 20.0F);
            this.waitingTeleportTicks = 0;
            this.preTeleportPos = player.position();
            this.currentTarget = null;
            this.foundAnchors.clear();
            this.state = State.WAITING_RTP;
         }

         case WAITING_RTP -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            this.checkRtpGui(mc, player);

            this.stateTicks--;
            if (this.stateTicks <= 0) {
               Vec3 currentPos = player.position();
               double distMovedSq = this.preTeleportPos != null ? currentPos.distanceToSqr(this.preTeleportPos) : 999.0;

               if (distMovedSq > 64.0) {
                  if (player.onGround() || player.isInWater() || player.fallDistance < 2.0F) {
                     this.state = State.SCANNING;
                  }
               } else {
                  this.waitingTeleportTicks++;
                  if (this.waitingTeleportTicks % 40 == 0) {
                     ModuleChat.actionBar(this, ModuleChat.body().warn("Waiting for RTP teleport...").text(" Click ").value("[HERE]").text(" if prompted"));
                  }
                  if (this.waitingTeleportTicks > 120) {
                     ModuleChat.send(this, ModuleChat.body().warn("Teleport timed out (position unchanged). Re-sending RTP..."));
                     this.state = State.SEND_RTP;
                  }
               }
            }
         }

         case SCANNING -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            int radius = Math.round(this.scanRadius.get());
            int spawnIgnore = Math.round(this.ignoreSpawnRadius.get());
            int playerChunkX = player.chunkPosition().x();
            int playerChunkZ = player.chunkPosition().z();
            int chunkRadius = (radius + 15) >> 4;
            double maxDistSq = (double)radius * (double)radius;
            Vec3 playerPos = player.position();
            List<BlockPos> list = new ArrayList<>();

            for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
               for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                  LevelChunk chunk = level.getChunkSource().getChunkNow(playerChunkX + dx, playerChunkZ + dz);
                  if (chunk == null) continue;
                  LevelChunkSection[] sections = chunk.getSections();
                  int minSectionY = chunk.getMinSectionY();
                  for (int i = 0; i < sections.length; i++) {
                     LevelChunkSection section = sections[i];
                     if (section == null || section.hasOnlyAir()) continue;
                     if (!section.maybeHas(s -> s.is(Blocks.RESPAWN_ANCHOR))) continue;
                     int baseY = (minSectionY + i) << 4;
                     for (int y = 0; y < 16; y++) {
                        for (int z = 0; z < 16; z++) {
                           for (int x = 0; x < 16; x++) {
                              if (section.getBlockState(x, y, z).is(Blocks.RESPAWN_ANCHOR)) {
                                 BlockPos pos = new BlockPos(((playerChunkX + dx) << 4) + x, baseY + y, ((playerChunkZ + dz) << 4) + z);
                                 
                                 if (spawnIgnore > 0 && Math.abs(pos.getX()) <= spawnIgnore && Math.abs(pos.getZ()) <= spawnIgnore) {
                                    continue;
                                 }

                                 if (!this.blacklisted.contains(pos) && pos.distToCenterSqr(playerPos) <= maxDistSq) {
                                    list.add(pos);
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }

            if (list.isEmpty()) {
               ModuleChat.actionBar(this, ModuleChat.body().warn("No wild anchors found").text(" in radius. Retrying RTP..."));
               int cd = Math.round(this.rtpCooldown.get() * 20.0F);
               this.stateTicks = Math.max(cd, 20);
               this.state = State.COOLDOWN_WAIT;
            } else {
               list.sort(Comparator.comparingDouble(p -> p.distToCenterSqr(player.position())));
               this.foundAnchors.clear();
               this.foundAnchors.addAll(list);
               this.currentTarget = this.foundAnchors.get(0);
               this.targetFace = getExposedFace(level, player, this.currentTarget);
               this.stuckTicks = 0;
               this.closestDist = Double.MAX_VALUE;
               ModuleChat.actionBar(this, ModuleChat.body().good("Found " + list.size() + " anchor(s)").text("! Navigating..."));
               this.state = State.NAVIGATING;
            }
         }

         case NAVIGATING -> {
            if (this.currentTarget == null || !level.getBlockState(this.currentTarget).is(Blocks.RESPAWN_ANCHOR)) {
               this.nextAnchorOrFinish(player);
               return;
            }

            Vec3 eyeVec = player.getEyePosition();
            Vec3 center = Vec3.atCenterOf(this.currentTarget);
            double distSq = eyeVec.distanceToSqr(center);
            float reach = this.reachDistance.get();

            if (distSq <= (double)reach * (double)reach) {
               this.releaseMoveKeys(mc);
               this.mineTicks = 0;
               this.targetLockedTicks = 0;
               this.state = State.MINING;
               return;
            }

            if (this.autoWalk.get()) {
               this.walkTowards(player, this.currentTarget, center, eyeVec);
            } else {
               this.releaseMoveKeys(mc);
            }
         }

         case MINING -> {
            if (this.currentTarget == null) {
               this.releaseAttack(mc);
               this.nextAnchorOrFinish(player);
               return;
            }

            BlockState blockState = level.getBlockState(this.currentTarget);
            if (blockState.isAir() || !blockState.is(Blocks.RESPAWN_ANCHOR)) {
               this.releaseAttack(mc);
               if (gameMode.isDestroying()) {
                  gameMode.stopDestroyBlock();
               }
               this.anchorsMinedTotal++;
               ModuleChat.actionBar(this, ModuleChat.body().good("Mined anchor!").text(" Total: ").value(this.anchorsMinedTotal));

               if (this.collectItems.get()) {
                  this.state = State.COLLECTING;
                  this.stateTicks = 20;
               } else {
                  this.nextAnchorOrFinish(player);
               }
               return;
            }

            Vec3 eye = player.getEyePosition();
            Vec3 center = Vec3.atCenterOf(this.currentTarget);
            float reach = this.reachDistance.get();
            if (eye.distanceToSqr(center) > (double)(reach + 0.8F) * (double)(reach + 0.8F)) {
               this.releaseAttack(mc);
               this.state = State.NAVIGATING;
               return;
            }

            this.mineTicks++;
            int maxMineTicks = Math.round(this.mineTimeout.get() * 20.0F);
            if (this.mineTicks > maxMineTicks) {
               this.releaseAttack(mc);
               if (gameMode.isDestroying()) {
                  gameMode.stopDestroyBlock();
               }
               ModuleChat.send(this, ModuleChat.body().warn("Anchor at ").value(this.currentTarget.toShortString()).text(" took too long (claimed/protected?). Blacklisting."));
               this.blacklisted.add(this.currentTarget);
               this.nextAnchorOrFinish(player);
               return;
            }

            if (this.targetFace == null) {
               this.targetFace = getExposedFace(level, player, this.currentTarget);
               if (this.targetFace == null) this.targetFace = Direction.UP;
            }

            boolean onTarget = this.aimAt(player, this.currentTarget, this.targetFace);
            if (onTarget) {
               this.targetLockedTicks++;
               if (this.targetLockedTicks >= 2) {
                  if (this.autoTool.get() && !this.isHoldingAttack) {
                     this.equipBestPickaxe(player, blockState, this.currentTarget);
                  }
                  this.pressAttack(mc);
               }
            }
         }

         case COLLECTING -> {
            this.releaseAttack(mc);
            if (this.currentTarget != null) {
               Vec3 dropCenter = Vec3.atCenterOf(this.currentTarget);
               double distSq = player.distanceToSqr(dropCenter);
               if (distSq > 0.5) {
                  this.walkTowards(player, this.currentTarget, dropCenter, player.getEyePosition());
               } else {
                  this.releaseMoveKeys(mc);
               }
            }
            this.stateTicks--;
            if (this.stateTicks <= 0) {
               this.releaseMoveKeys(mc);
               this.nextAnchorOrFinish(player);
            }
         }

         case SELLING -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            if (this.autoSell.get()) {
               String sell = this.sellCommand.get().trim();
               if (!sell.isEmpty() && mc.getConnection() != null) {
                  if (sell.startsWith("/")) {
                     mc.getConnection().sendCommand(sell.substring(1));
                  } else {
                     mc.getConnection().sendChat(sell);
                  }
                  ModuleChat.actionBar(this, ModuleChat.body().good("Sold anchors!").text(" (").value(sell).text(")"));
               }
            }
            int cd = Math.round(this.rtpCooldown.get() * 20.0F);
            this.stateTicks = Math.max(cd, 20);
            this.state = State.COOLDOWN_WAIT;
         }

         case COOLDOWN_WAIT -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
            this.stateTicks--;
            if (this.stateTicks <= 0) {
               this.state = State.SEND_RTP;
            }
         }

         case IDLE -> {
            this.releaseAttack(mc);
            this.releaseMoveKeys(mc);
         }
      }
   }

   private void nextAnchorOrFinish(LocalPlayer player) {
      if (this.currentTarget != null) {
         this.foundAnchors.remove(this.currentTarget);
         this.currentTarget = null;
         this.targetFace = null;
      }
      this.releaseAttack(Minecraft.getInstance());
      this.releaseMoveKeys(Minecraft.getInstance());
      this.targetLockedTicks = 0;
      this.mineTicks = 0;
      this.stuckTicks = 0;
      this.closestDist = Double.MAX_VALUE;

      ClientLevel level = (ClientLevel)player.level();
      this.foundAnchors.removeIf(p -> this.blacklisted.contains(p) || !level.getBlockState(p).is(Blocks.RESPAWN_ANCHOR));

      if (!this.foundAnchors.isEmpty()) {
         this.foundAnchors.sort(Comparator.comparingDouble(p -> p.distToCenterSqr(player.position())));
         this.currentTarget = this.foundAnchors.get(0);
         this.targetFace = getExposedFace(level, player, this.currentTarget);
         this.state = State.NAVIGATING;
      } else {
         this.state = State.SELLING;
      }
   }

   private void walkTowards(LocalPlayer player, BlockPos targetPos, Vec3 targetCenter, Vec3 eyeVec) {
      Minecraft mc = Minecraft.getInstance();
      double px = player.getX();
      double pz = player.getZ();
      double dx = targetCenter.x - px;
      double dz = targetCenter.z - pz;
      float targetYaw = (float)Math.toDegrees(Math.atan2(-dx, dz));

      if (this.smoothAim.get()) {
         float currentYaw = player.getYRot();
         float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
         if (Math.abs(diffYaw) > 0.5F) {
            float maxStep = Math.max(0.6F, this.aimSpeed.get() * 0.22F);
            float stepYaw = Mth.clamp(diffYaw * 0.25F, -maxStep, maxStep);
            float quantYaw = quantizeToMouseGcd(mc, stepYaw);
            player.setYRot(currentYaw + quantYaw);
         }
         double dy = targetCenter.y - eyeVec.y;
         double distXZ = Math.hypot(dx, dz);
         float targetPitch = (float)-Math.toDegrees(Math.atan2(dy, distXZ));
         float currentPitch = player.getXRot();
         float diffPitch = Mth.wrapDegrees(targetPitch - currentPitch);
         if (Math.abs(diffPitch) > 0.5F) {
            float stepPitch = Mth.clamp(diffPitch * 0.2F, -2.5F, 2.5F);
            player.setXRot(Mth.clamp(currentPitch + quantizeToMouseGcd(mc, stepPitch), -90.0F, 90.0F));
         }
      }

      float yawOffset = Math.abs(Mth.wrapDegrees(targetYaw - player.getYRot()));
      if (yawOffset < 40.0F) {
         mc.options.keyUp.setDown(true);
      } else {
         mc.options.keyUp.setDown(false);
      }

      if (this.autoJump.get()) {
         if (player.horizontalCollision && player.onGround()) {
            Direction facing = player.getDirection();
            BlockPos stepPos = player.blockPosition().relative(facing);
            BlockPos headPos = stepPos.above();
            BlockState headState = player.level().getBlockState(headPos);
            if (!headState.isSolidRender()) {
               mc.options.keyJump.setDown(true);
            } else {
               mc.options.keyJump.setDown(false);
            }
         } else if (player.isInWater()) {
            mc.options.keyJump.setDown(true);
         } else {
            boolean physical = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyJump);
            mc.options.keyJump.setDown(physical);
         }
      }

      double currentDist = player.distanceToSqr(targetCenter);
      if (currentDist < this.closestDist - 0.2) {
         this.closestDist = currentDist;
         this.stuckTicks = 0;
      } else {
         this.stuckTicks++;
         if (this.stuckTicks > 80) {
            if (player.horizontalCollision) {
               mc.options.keyJump.setDown(true);
            }
            if (this.stuckTicks > 140) {
               this.blacklisted.add(targetPos);
               this.nextAnchorOrFinish(player);
            }
         }
      }
   }

   public void onRender3D(Render3DEvent event) {
      if (!this.renderEsp.get()) return;
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player == null || mc.level == null) return;

      Vec3 eye = player.getEyePosition();

      for (BlockPos pos : this.foundAnchors) {
         if (pos.equals(this.currentTarget)) continue;
         AABB box = new AABB(pos);
         Gizmos.cuboid(box, GizmoStyle.strokeAndFill(0xCCB540FF, 1.5F, 0x22B540FF));
      }

      if (this.currentTarget != null) {
         AABB targetBox = new AABB(this.currentTarget);
         Gizmos.cuboid(targetBox, GizmoStyle.strokeAndFill(0xFF00FFCC, 2.5F, 0x4400FFCC));
         Gizmos.line(eye, Vec3.atCenterOf(this.currentTarget), 0xFF00FFCC, 1.8F);
      }
   }

   private void equipBestPickaxe(LocalPlayer player, BlockState state, BlockPos pos) {
      if (this.isHoldingAttack) return;
      Inventory inv = player.getInventory();
      int currentSlot = inv.getSelectedSlot();
      int bestSlot = currentSlot;
      float bestProgress = state.getDestroyProgress(player, player.level(), pos);

      for (int i = 0; i < 9; i++) {
         ItemStack stack = inv.getItem(i);
         if (stack.isEmpty()) continue;
         if (!stack.is(ItemTags.PICKAXES)) continue;

         inv.setSelectedSlot(i);
         float progress = state.getDestroyProgress(player, player.level(), pos);
         boolean correct = stack.isCorrectToolForDrops(state);

         if (!inv.getItem(bestSlot).is(ItemTags.PICKAXES)) {
            bestSlot = i;
            bestProgress = progress;
         } else if (correct && progress > bestProgress) {
            bestProgress = progress;
            bestSlot = i;
         } else if (!inv.getItem(bestSlot).isCorrectToolForDrops(state) && correct) {
            bestProgress = progress;
            bestSlot = i;
         }
      }

      inv.setSelectedSlot(bestSlot);
      if (bestSlot != currentSlot && player.connection != null) {
         player.connection.send(new ServerboundSetCarriedItemPacket(bestSlot));
      }
   }

   private boolean aimAt(LocalPlayer player, BlockPos pos, Direction face) {
      if (!this.smoothAim.get()) {
         Vec3 center = Vec3.atCenterOf(pos);
         Minecraft.getInstance().hitResult = new BlockHitResult(center, face, pos, false);
         return true;
      }

      Vec3 faceCenter = Vec3.atCenterOf(pos).add(
         (double)face.getStepX() * 0.40,
         (double)face.getStepY() * 0.40,
         (double)face.getStepZ() * 0.40
      );
      Vec3 eye = player.getEyePosition();
      Vec3 delta = faceCenter.subtract(eye);
      double distXZ = Math.hypot(delta.x, delta.z);
      float targetYaw = (float)Math.toDegrees(Math.atan2(-delta.x, delta.z));
      float targetPitch = (float)-Math.toDegrees(Math.atan2(delta.y, distXZ));

      Minecraft mc = Minecraft.getInstance();
      float currentYaw = player.getYRot();
      float currentPitch = player.getXRot();
      float diffYaw = Mth.wrapDegrees(targetYaw - currentYaw);
      float diffPitch = Mth.wrapDegrees(targetPitch - currentPitch);
      float totalDiff = (float)Math.hypot(diffYaw, diffPitch);

      if (totalDiff > 0.35F) {
         float t = Mth.clamp(totalDiff / 16.0F, 0.08F, 1.0F);
         float ease = (float)(1.0 - Math.pow(1.0 - t, 2.2));
         float maxStep = Math.max(0.35F, this.aimSpeed.get() * 0.20F * ease);

         float stepYaw = Mth.clamp(diffYaw * 0.35F, -maxStep, maxStep);
         float stepPitch = Mth.clamp(diffPitch * 0.35F, -maxStep, maxStep);

         float quantYaw = quantizeToMouseGcd(mc, stepYaw);
         float quantPitch = quantizeToMouseGcd(mc, stepPitch);

         player.setYRot(currentYaw + quantYaw);
         player.setXRot(Mth.clamp(currentPitch + quantPitch, -90.0F, 90.0F));
      }

      ClientLevel level = (ClientLevel)player.level();
      Vec3 look = player.getViewVector(1.0F);
      Vec3 reachEnd = eye.add(look.scale(Math.max(4.5, (double)this.reachDistance.get())));
      BlockHitResult hit = level.clip(new ClipContext(eye, reachEnd, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
      boolean rayHit = (hit.getType() == HitResult.Type.BLOCK && hit.getBlockPos().equals(pos));

      if (rayHit) {
         this.targetFace = hit.getDirection();
         Minecraft.getInstance().hitResult = hit;
         return totalDiff < 2.5F;
      }

      return false;
   }

   private float quantizeToMouseGcd(Minecraft mc, float value) {
      float sensitivity = mc.options.sensitivity().get().floatValue();
      float f = sensitivity * 0.6F + 0.2F;
      float gcd = f * f * f * 8.0F * 0.15F;
      if (gcd <= 0.0001F) return value;
      return Math.round(value / gcd) * gcd;
   }

   private static Direction getExposedFace(ClientLevel level, LocalPlayer player, BlockPos pos) {
      Vec3 eye = player.getEyePosition();
      Direction bestFace = null;
      double bestDist = Double.MAX_VALUE;

      for (Direction face : Direction.values()) {
         BlockPos neighbor = pos.relative(face);
         BlockState neighborState = level.getBlockState(neighbor);
         if (!neighborState.isSolidRender()) {
            Vec3 faceCenter = Vec3.atCenterOf(pos).add(
               (double)face.getStepX() * 0.40,
               (double)face.getStepY() * 0.40,
               (double)face.getStepZ() * 0.40
            );

            BlockHitResult clip = level.clip(new ClipContext(eye, faceCenter, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
            if (clip.getType() == HitResult.Type.MISS || clip.getBlockPos().equals(pos)) {
               double dist = eye.distanceToSqr(faceCenter);
               if (dist < bestDist) {
                  bestDist = dist;
                  bestFace = face;
               }
            }
         }
      }

      if (bestFace == null) {
         for (Direction face : Direction.values()) {
            if (!level.getBlockState(pos.relative(face)).isSolidRender()) {
               return face;
            }
         }
      }

      return bestFace != null ? bestFace : Direction.UP;
   }

   private void pressAttack(Minecraft mc) {
      mc.missTime = 0;
      KeyMapping key = mc.options.keyAttack;
      if (!this.isHoldingAttack) {
         if (!key.isUnbound()) {
            Key bound = KeyMappingHelper.getBoundKeyOf(key);
            KeyMapping.click(bound);
            KeyMapping.set(bound, true);
         }
         key.setDown(true);
         this.isHoldingAttack = true;
      } else {
         key.setDown(true);
      }
      if (this.swingHand.get() && mc.player != null) {
         mc.player.swing(InteractionHand.MAIN_HAND);
      }
   }

   private void releaseAttack(Minecraft mc) {
      this.isHoldingAttack = false;
      KeyMapping key = mc.options.keyAttack;
      if (!key.isUnbound()) {
         Key bound = KeyMappingHelper.getBoundKeyOf(key);
         KeyMapping.set(bound, false);
      }
      boolean physical = mc.gui.screen() == null && physicallyDown(mc, key);
      key.setDown(physical);
   }

   private void releaseMoveKeys(Minecraft mc) {
      if (mc.options != null) {
         boolean physicalUp = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyUp);
         boolean physicalJump = mc.gui.screen() == null && physicallyDown(mc, mc.options.keyJump);
         mc.options.keyUp.setDown(physicalUp);
         mc.options.keyJump.setDown(physicalJump);
      }
   }

   private static boolean physicallyDown(Minecraft mc, KeyMapping mapping) {
      if (mapping.isUnbound()) {
         return false;
      } else {
         Key key = KeyMappingHelper.getBoundKeyOf(mapping);
         int value = key.getValue();
         if (value < 0) {
            return false;
         } else {
            return switch (key.getType()) {
               case MOUSE -> GLFW.glfwGetMouseButton(mc.getWindow().handle(), value) == 1;
               case KEYSYM -> InputConstants.isKeyDown(mc.getWindow(), value);
               default -> mapping.isDown();
            };
         }
      }
   }
}
