package net.spectre.client.module.impl.combat;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import net.spectre.client.event.EventHandler;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public final class WTapRecodeModule extends ClientModule {
   private final ModeSetting tapMode = this.addSetting("mode", new ModeSetting("Mode", "Packet", "Packet", "W Tap", "S Tap", "Sneak Tap", "Sprint Tap"));
   private final NumberSetting duration = this.addSetting("duration", new NumberSetting("Duration (ms)", 60.0F, 20.0F, 500.0F).step(5.0F));
   private final NumberSetting delay = this.addSetting("delay", new NumberSetting("Delay (ms)", 180.0F, 0.0F, 1000.0F).step(10.0F));
   private final BooleanSetting onlyOnGround = this.addSetting("only-ground", new BooleanSetting("Only Ground", false));
   private long stopTime;
   private long nextTapTime;
   private boolean active;
   private boolean captured;
   private boolean packetResetPending;
   private boolean wasSprinting;
   private boolean oldForward;
   private boolean oldBack;
   private boolean oldSneak;
   private boolean oldSprintKey;

   public boolean isTapping() {
      return this.isEnabled() && this.active;
   }

   public WTapRecodeModule() {
      super("w-tap-recode", "W Tap / Sprint Reset", "Resets sprint immediately upon hitting an enemy to deal maximum combo knockback.", ModuleCategory.COMBAT);
   }

   @Override
   protected void onEnable() {
      this.active = false;
      this.captured = false;
      this.packetResetPending = false;
      this.wasSprinting = false;
      this.nextTapTime = 0L;
   }

   @Override
   protected void onDisable() {
      this.restoreKeys();
      this.packetResetPending = false;
      this.wasSprinting = false;
   }

   public void afterAttack() {
      Minecraft mc = Minecraft.getInstance();
      if (this.isEnabled() && mc.player != null) {
         long now = System.currentTimeMillis();
         if (!this.active && now >= this.nextTapTime) {
            if (!this.onlyOnGround.get() || mc.player.onGround()) {
               this.wasSprinting = mc.player.isSprinting();
               if ("Packet".equals(this.tapMode.get())) {
                  ClientPacketListener conn = mc.getConnection();
                  if (conn != null && this.wasSprinting) {
                     conn.send(new ServerboundPlayerCommandPacket(mc.player, Action.STOP_SPRINTING));
                     mc.player.setSprinting(false);
                     this.packetResetPending = true;
                     this.nextTapTime = now + (long) this.delay.getInt();
                  }
                  return;
               }

               this.stopTime = now + Math.max(0L, (long) this.duration.getInt());
               this.nextTapTime = now + Math.max(0L, (long) this.delay.getInt());
               this.active = true;
               this.captured = false;
            }
         }
      }
   }

   @EventHandler
   public void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null) {
         this.active = false;
         this.packetResetPending = false;
         return;
      }

      if (this.packetResetPending) {
         this.packetResetPending = false;
         ClientPacketListener conn = mc.getConnection();
         boolean movingForward = mc.options.keyUp.isDown() || mc.player.input.keyPresses.forward();
         if (conn != null && (this.wasSprinting || movingForward || mc.options.keySprint.isDown())) {
            conn.send(new ServerboundPlayerCommandPacket(mc.player, Action.START_SPRINTING));
            mc.player.setSprinting(true);
         }
      }

      if (this.active) {
         if (System.currentTimeMillis() <= this.stopTime) {
            this.applyTap(mc);
         } else {
            this.restoreKeys();
            this.active = false;
         }
      }
   }

   private void applyTap(Minecraft mc) {
      this.captureKeys(mc);
      String var2 = this.tapMode.get();
      switch (var2) {
         case "W Tap":
            mc.options.keyUp.setDown(false);
            break;
         case "S Tap":
            mc.options.keyDown.setDown(true);
            break;
         case "Sneak Tap":
            mc.options.keyShift.setDown(true);
            break;
         case "Sprint Tap":
            if (mc.player.isSprinting()) {
               ClientPacketListener conn = mc.getConnection();
               if (conn != null) {
                  conn.send(new ServerboundPlayerCommandPacket(mc.player, Action.STOP_SPRINTING));
               }
               mc.player.setSprinting(false);
            }
            break;
      }
   }

   private void captureKeys(Minecraft mc) {
      if (!this.captured) {
         this.oldForward = mc.options.keyUp.isDown();
         this.oldBack = mc.options.keyDown.isDown();
         this.oldSneak = mc.options.keyShift.isDown();
         this.oldSprintKey = mc.options.keySprint.isDown();
         this.captured = true;
      }
   }

   private void restoreKeys() {
      if (this.captured) {
         Minecraft mc = Minecraft.getInstance();
         setDown(mc.options.keyUp, this.oldForward);
         setDown(mc.options.keyDown, this.oldBack);
         setDown(mc.options.keyShift, this.oldSneak);
         setDown(mc.options.keySprint, this.oldSprintKey);
         this.captured = false;

         if (mc.player != null && (this.wasSprinting || this.oldForward)) {
            ClientPacketListener conn = mc.getConnection();
            if (conn != null) {
               conn.send(new ServerboundPlayerCommandPacket(mc.player, Action.START_SPRINTING));
            }
            mc.player.setSprinting(true);
         }
      }
   }

   private static void setDown(KeyMapping key, boolean down) {
      if (key != null) {
         key.setDown(down);
      }
   }
}
