package net.spectre.client.event.impl;

import net.spectre.client.event.CancellableEvent;
import net.spectre.client.event.CancellableEventType;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.world.entity.Entity;

@Environment(EnvType.CLIENT)
public final class PreAttackEntityEvent extends CancellableEvent {
   public static final CancellableEventType<PreAttackEntityEvent> TYPE = new CancellableEventType<>("PreAttackEntityEvent");
   public Entity target;
   private static final PreAttackEntityEvent INSTANCE = new PreAttackEntityEvent();

   private PreAttackEntityEvent() {
   }

   public static boolean dispatch(Entity target) {
      if (!TYPE.hasPreListeners()) {
         return false;
      } else {
         INSTANCE.target = target;
         INSTANCE.resetCancellation();
         TYPE.dispatch(INSTANCE);
         boolean cancelled = INSTANCE.isCancelled();
         INSTANCE.target = null;
         return cancelled;
      }
   }
}
