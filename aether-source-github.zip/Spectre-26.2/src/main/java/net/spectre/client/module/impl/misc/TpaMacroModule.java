package net.spectre.client.module.impl.misc;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.Stage;
import net.spectre.client.event.impl.PacketReceiveEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;
import net.spectre.client.module.setting.StringSetting;

@Environment(EnvType.CLIENT)
public final class TpaMacroModule extends ClientModule {
   private static final Pattern STRIP_COLOR = Pattern.compile("(?i)§[0-9A-FK-ORX]");
   private static final double TELEPORT_DISTANCE_SQ = 64.0;

   private final StringSetting targetUsername = this.addSetting(
      "target-username", new StringSetting("Target Username", "")
   );
   private final ModeSetting commandMode = this.addSetting(
      "command-mode", new ModeSetting("Command", "tpa", "tpa", "tpahere")
   );
   private final NumberSetting retryDurationSec = this.addSetting(
      "retry-duration-sec", new NumberSetting("Retry Duration (s)", 5.0F, 0.5F, 120.0F).step(0.5F)
   );
   private final NumberSetting retryJitterSec = this.addSetting(
      "retry-jitter-sec", new NumberSetting("Retry Jitter (s)", 0.0F, 0.0F, 5.0F).step(0.1F)
   );
   private final BooleanSetting stopOnTeleport = this.addSetting(
      "stop-on-teleport", new BooleanSetting("Stop On Teleport", true)
   );
   private final BooleanSetting stopOnAccept = this.addSetting(
      "stop-on-accept", new BooleanSetting("Stop On Chat Accept", true)
   );
   private final ActionSetting sendNowButton = this.addSetting(
      "send-now", new ActionSetting("Send TPA Now", this::triggerImmediateSend)
   );

   private long nextSendAtMs;
   private int targetIndex;
   private int attemptCount;
   private Vec3 lastKnownPos;

   public TpaMacroModule() {
      super(
         "tpa-macro",
         "TPA Macro",
         "Automatically sends /tpa or /tpahere requests to a target username with a customizable retry duration.",
         ModuleCategory.DONUT
      );
      this.usesNotifications();
      this.targetUsername.privateValue();
   }

   @Override
   public boolean persistEnabled() {
      return false;
   }

   @Override
   protected void onEnable() {
      Minecraft mc = Minecraft.getInstance();
      this.nextSendAtMs = 0L;
      this.targetIndex = 0;
      this.attemptCount = 0;
      this.lastKnownPos = mc.player != null ? mc.player.position() : null;

      List<String> targets = this.parseTargets();
      if (targets.isEmpty()) {
         ModuleChat.send(
            this,
            ModuleChat.body().warn("Please enter a Target Username in TPA Macro settings first.")
         );
         this.requestDisable();
         return;
      }

      this.on(TickEvent.TYPE, Stage.PRE, this::onTick);
      this.on(PacketReceiveEvent.TYPE, Stage.PRE, this::onPacketReceive);
   }

   @Override
   protected void onDisable() {
      this.nextSendAtMs = 0L;
      this.lastKnownPos = null;
   }

   private void triggerImmediateSend() {
      Minecraft mc = Minecraft.getInstance();
      if (mc.player == null || mc.getConnection() == null) {
         return;
      }
      List<String> targets = this.parseTargets();
      if (targets.isEmpty()) {
         ModuleChat.send(
            this,
            ModuleChat.body().warn("Please enter a Target Username in TPA Macro settings first.")
         );
         return;
      }
      this.sendNextTpa(mc, targets);
      this.scheduleNextRetry();
   }

   private void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      ClientPacketListener connection = mc.getConnection();
      if (mc.player == null || connection == null) {
         return;
      }

      Vec3 currentPos = mc.player.position();
      if (this.stopOnTeleport.get() && this.lastKnownPos != null) {
         if (currentPos.distanceToSqr(this.lastKnownPos) > TELEPORT_DISTANCE_SQ && this.attemptCount > 0) {
            ModuleChat.send(
               this,
               ModuleChat.body().good("Teleport detected").text(" — stopping TPA Macro.")
            );
            this.requestDisable();
            return;
         }
      }
      this.lastKnownPos = currentPos;

      List<String> targets = this.parseTargets();
      if (targets.isEmpty()) {
         ModuleChat.send(
            this,
            ModuleChat.body().warn("Target Username is empty — stopping TPA Macro.")
         );
         this.requestDisable();
         return;
      }

      long now = System.currentTimeMillis();
      if (now >= this.nextSendAtMs) {
         this.sendNextTpa(mc, targets);
         this.scheduleNextRetry();
      }
   }

   private void sendNextTpa(Minecraft mc, List<String> targets) {
      if (this.targetIndex >= targets.size()) {
         this.targetIndex = 0;
      }
      String username = targets.get(this.targetIndex++);
      String cmd = this.commandMode.is("tpahere") ? "tpahere " + username : "tpa " + username;

      if (mc.getConnection() != null) {
         mc.getConnection().sendCommand(cmd);
         this.attemptCount++;
         ModuleChat.actionBar(
            this,
            ModuleChat.body()
               .text("Sent ")
               .value("/" + cmd)
               .text(" (attempt #")
               .value(Integer.toString(this.attemptCount))
               .text(", retry in ")
               .value(String.format(Locale.ROOT, "%.1fs", this.retryDurationSec.get()))
               .text(")")
         );
      }
   }

   private void scheduleNextRetry() {
      long baseMs = Math.max(500L, Math.round(this.retryDurationSec.get() * 1000.0F));
      long jitterMaxMs = Math.round(this.retryJitterSec.get() * 1000.0F);
      long jitterMs = jitterMaxMs > 0L ? ThreadLocalRandom.current().nextLong(jitterMaxMs + 1L) : 0L;
      this.nextSendAtMs = System.currentTimeMillis() + baseMs + jitterMs;
   }

   private void onPacketReceive(PacketReceiveEvent event) {
      if (!this.stopOnAccept.get() || !(event.packet instanceof ClientboundSystemChatPacket chatPacket)) {
         return;
      }
      if (chatPacket.overlay()) {
         return;
      }
      String raw = chatPacket.content() != null ? chatPacket.content().getString() : "";
      if (raw.isEmpty()) {
         return;
      }
      String clean = STRIP_COLOR.matcher(raw).replaceAll("").trim().toLowerCase(Locale.ROOT);
      if (clean.contains("accepted your teleport request")
         || clean.contains("teleport request accepted")
         || clean.contains("teleporting to ")
         || clean.contains("teleporting you to ")) {
         Minecraft.getInstance().execute(() -> {
            if (this.isEnabled()) {
               ModuleChat.send(
                  this,
                  ModuleChat.body().good("TPA request accepted").text(" — stopping TPA Macro.")
               );
               this.requestDisable();
            }
         });
      }
   }

   private List<String> parseTargets() {
      String raw = this.targetUsername.get();
      if (raw == null || raw.isBlank()) {
         return List.of();
      }
      String[] parts = raw.split("[,|\\s]+");
      List<String> out = new ArrayList<>(parts.length);
      for (String part : parts) {
         String cleaned = part.trim();
         if (cleaned.startsWith("/")) {
            cleaned = cleaned.substring(1).trim();
         }
         if (!cleaned.isEmpty()) {
            out.add(cleaned);
         }
      }
      return out;
   }
}
