package net.spectre.client.module.impl.combat;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.EntityHitResult;
import net.spectre.client.event.EventHandler;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.impl.combat.melee.MeleeAttacks;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public final class HitboxesModule extends ClientModule {
   private final NumberSetting expand = this.addSetting("expand", new NumberSetting("Hitbox Expand", 0.25F, 0.05F, 1.0F).step(0.05F));
   private final NumberSetting reach = this.addSetting("reach", new NumberSetting("Reach", 3.8F, 3.0F, 5.0F).step(0.1F));
   private final BooleanSetting noMissCooldown = this.addSetting("no-miss-cooldown", new BooleanSetting("No Miss Cooldown", true));
   private final BooleanSetting playersOnly = this.addSetting("players-only", new BooleanSetting("Players Only", true));
   private final BooleanSetting skipFriends = this.addSetting("skip-friends", new BooleanSetting("Skip Friends", true));
   private final BooleanSetting weaponsOnly = this.addSetting("weapons-only", new BooleanSetting("Weapons Only", false));

   public HitboxesModule() {
      super("hitboxes", "Hitboxes", "Expands enemy attack hitboxes so manual sword strikes and raycasts connect consistently.", ModuleCategory.COMBAT);
   }

   public float getExpansion() {
      return this.isEnabled() ? this.expand.get() : 0.0F;
   }

   public boolean shouldExpand(Entity entity) {
      if (!this.isEnabled() || !(entity instanceof LivingEntity)) return false;
      if (this.playersOnly.get() && !(entity instanceof Player)) return false;
      if (entity instanceof Player targetPlayer) {
         if (targetPlayer.isSpectator() || targetPlayer.isCreative()) return false;
         if (this.skipFriends.get() && MeleeAttacks.isFriend(targetPlayer)) return false;
      }
      return true;
   }

   public void applyExpandedHit(Minecraft mc) {
      if (!this.isEnabled() || mc.player == null || mc.level == null) return;
      if (this.noMissCooldown.get()) {
         mc.missTime = 0;
      }
      if (this.weaponsOnly.get() && !this.isHoldingWeapon(mc.player)) return;
      if (mc.hitResult instanceof EntityHitResult) return;

      EntityHitResult expandedHit = MeleeAttacks.crosshairHit(mc, this.reach.get(), this.expand.get());
      if (expandedHit != null && this.shouldExpand(expandedHit.getEntity())) {
         mc.hitResult = expandedHit;
         mc.crosshairPickEntity = expandedHit.getEntity();
      }
   }

   @EventHandler
   public void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      this.applyExpandedHit(mc);
   }

   private boolean isHoldingWeapon(LocalPlayer player) {
      ItemStack main = player.getMainHandItem();
      if (main.isEmpty()) return false;
      return main.is(ItemTags.SWORDS) || main.is(ItemTags.AXES) || main.is(Items.MACE);
   }
}
