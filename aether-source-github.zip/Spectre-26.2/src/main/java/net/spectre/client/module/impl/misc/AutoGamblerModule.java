package net.spectre.client.module.impl.misc;

import java.text.NumberFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ThreadLocalRandom;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.protocol.game.ClientboundDisguisedChatPacket;
import net.minecraft.network.protocol.game.ClientboundPlayerChatPacket;
import net.minecraft.network.protocol.game.ClientboundSystemChatPacket;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.config.FriendStore;
import net.spectre.client.event.Stage;
import net.spectre.client.event.impl.PacketReceiveEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;
import net.spectre.client.module.setting.StringSetting;

@Environment(EnvType.CLIENT)
public final class AutoGamblerModule extends ClientModule {
   private static final Pattern STRIP_COLOR = Pattern.compile("(?i)§[0-9A-FK-ORX]");
   private static final Pattern LEADING_PREFIX = Pattern.compile(
      "^(?:(?:\\[[^\\]]{1,32}\\]|\\([^\\]]{1,32}\\)|[✦★*•|]|DonutSMP:?|Donut:?)\\s*)+",
      Pattern.CASE_INSENSITIVE
   );
   private static final Pattern ACCOUNT_NAME = Pattern.compile("^[.*]?[A-Za-z0-9_]{2,20}$");
   private static final Pattern CHAT_SPEAKER_PATTERN = Pattern.compile(
      "^(?:(?:\\[[^\\]]+\\]|\\([^\\]]+\\))\\s*)*[.*]?[A-Za-z0-9_]{2,20}:\\s+"
   );

   // DonutSMP & EssentialsX payment received patterns:
   // 1) "$10,000 has been received from PlayerName." or "$ 105 has been received from .PlayerName"
   private static final Pattern PAY_PATTERN_1 = Pattern.compile(
      "^\\$?\\s*([0-9,]+(?:\\.[0-9]+)?[KMBkmb]?)\\s+has been received from\\s+(?:(?:\\[[^\\]]+\\]|\\([^\\]]+\\))\\s+)?([.*]?[A-Za-z0-9_]{2,20})[.!]*$",
      Pattern.CASE_INSENSITIVE
   );
   // 2) "PlayerName paid you $ 105" or "PlayerName has paid you $10,000."
   private static final Pattern PAY_PATTERN_2 = Pattern.compile(
      "^(?:(?:\\[[^\\]]+\\]|\\([^\\]]+\\))\\s+)?([.*]?[A-Za-z0-9_]{2,20})\\s+(?:has\\s+)?paid you\\s+\\$?\\s*([0-9,]+(?:\\.[0-9]+)?[KMBkmb]?)[.!]*$",
      Pattern.CASE_INSENSITIVE
   );
   // 3) "You received $ 10,000 from PlayerName." or "Received $ 105 from PlayerName"
   private static final Pattern PAY_PATTERN_3 = Pattern.compile(
      "^(?:You\\s+)?(?:have\\s+)?received\\s+\\$?\\s*([0-9,]+(?:\\.[0-9]+)?[KMBkmb]?)\\s+from\\s+(?:(?:\\[[^\\]]+\\]|\\([^\\]]+\\))\\s+)?([.*]?[A-Za-z0-9_]{2,20})[.!]*$",
      Pattern.CASE_INSENSITIVE
   );
   // 4) "PlayerName sent you $ 105" or "PlayerName has sent you $10K"
   private static final Pattern PAY_PATTERN_4 = Pattern.compile(
      "^(?:(?:\\[[^\\]]+\\]|\\([^\\]]+\\))\\s+)?([.*]?[A-Za-z0-9_]{2,20})\\s+(?:has\\s+)?sent you\\s+\\$?\\s*([0-9,]+(?:\\.[0-9]+)?[KMBkmb]?)[.!]*$",
      Pattern.CASE_INSENSITIVE
   );
   // 5) "+ $ 10,000 from PlayerName" or "+$105 from PlayerName"
   private static final Pattern PAY_PATTERN_5 = Pattern.compile(
      "^\\+\\s*\\$?\\s*([0-9,]+(?:\\.[0-9]+)?[KMBkmb]?)\\s+(?:from|received from)\\s+(?:(?:\\[[^\\]]+\\]|\\([^\\]]+\\))\\s+)?([.*]?[A-Za-z0-9_]{2,20})[.!]*$",
      Pattern.CASE_INSENSITIVE
   );

   // Manual Winrate & Game Settings
   private final NumberSetting winChance = this.addSetting(
      "winrate-chance", new NumberSetting("Winrate Chance (%)", 40.0F, 0.0F, 100.0F).step(1.0F)
   );
   private final NumberSetting payoutMultiplier = this.addSetting(
      "payout-multiplier", new NumberSetting("Payout Multiplier (x)", 2.0F, 1.1F, 10.0F).step(0.1F)
   );
   private final ModeSetting gameType = this.addSetting(
      "game-type", new ModeSetting("Game Mode", "Coinflip", "Coinflip", "Dice Roll (1-100)", "Double or Nothing")
   );
   private final NumberSetting minBet = this.addSetting(
      "min-bet", new NumberSetting("Min Bet ($)", 1.0F, 0.01F, 50_000_000.0F).step(1.0F)
   );
   private final NumberSetting maxBet = this.addSetting(
      "max-bet", new NumberSetting("Max Bet ($)", 100_000_000.0F, 1.0F, 1_000_000_000.0F).step(100_000.0F)
   );
   private final BooleanSetting refundInvalid = this.addSetting(
      "refund-invalid", new BooleanSetting("Refund Out-of-Bounds Bets", true)
   );
   private final BooleanSetting replyResults = this.addSetting(
      "reply-results", new BooleanSetting("DM Roll Results to Player", true)
   );
   private final BooleanSetting debugChat = this.addSetting(
      "debug-chat", new BooleanSetting("Debug Payment Messages", true)
   );

   // Auto-Messaging / Advertising Settings
   private final BooleanSetting autoDmPlayers = this.addSetting(
      "auto-dm-players", new BooleanSetting("Auto Message Players", true)
   );
   private final BooleanSetting skipStaff = this.addSetting(
      "skip-staff", new BooleanSetting("Skip Staff List Members", true)
   );
   private final BooleanSetting skipFriends = this.addSetting(
      "skip-friends", new BooleanSetting("Skip Friends List", true)
   );
   private final BooleanSetting pauseIfStaffInRegion = this.addSetting(
      "pause-staff-region", new BooleanSetting("Pause DM If Staff In Region", false)
   );
   private final ModeSetting dmCommand = this.addSetting(
      "dm-command", new ModeSetting("Message Command", "msg", "msg", "w", "tell", "Public Chat")
   );
   private final NumberSetting dmIntervalSec = this.addSetting(
      "dm-interval-sec", new NumberSetting("DM Interval (sec)", 10.0F, 2.0F, 120.0F).step(1.0F)
   );
   private final NumberSetting playerCooldownMin = this.addSetting(
      "player-cooldown-min", new NumberSetting("Per-Player Cooldown (min)", 15.0F, 1.0F, 120.0F).step(1.0F)
   );
   private final BooleanSetting antiSpamSuffix = this.addSetting(
      "anti-spam-suffix", new BooleanSetting("Anti-Spam Random ID", true)
   );
   private final StringSetting inviteMessage = this.addSetting(
      "invite-message",
      new StringSetting(
         "Invite Message",
         "Automated {mult}x Casino! /pay {me} {min}-{max} to roll! Instant auto-payout!"
      )
   );
   private final NumberSetting commandSpacingTicks = this.addSetting(
      "command-spacing-ticks", new NumberSetting("Command Delay (ticks)", 30.0F, 10.0F, 100.0F).step(5.0F)
   );

   // Runtime state
   private final Map<String, Long> messagedPlayers = new HashMap<>();
   private final Queue<String> commandQueue = new ArrayDeque<>();
   private int commandCooldownTicks;
   private int dmTimerTicks;

   // Session statistics
   private int totalBets;
   private int totalWins;
   private int totalLosses;
   private double totalWagered;
   private double totalPaidOut;

   public AutoGamblerModule() {
      super(
         "auto-gambler",
         "Auto Gambler",
         "Messages online players (excluding Staff List members) to pay for gambling and runs an automated game with manual winrate.",
         ModuleCategory.GAMBLING
      );
      this.usesNotifications();

      this.addSetting("simulate-bet", new ActionSetting("Simulate Test Bet ($50K)", this::simulateTestBet));
      this.addSetting("show-stats", new ActionSetting("Print Session Profit & Stats", this::printSessionStats));
      this.addSetting("clear-dm-history", new ActionSetting("Reset Messaged Players Cooldown", () -> {
         int count = this.messagedPlayers.size();
         this.messagedPlayers.clear();
         this.dmTimerTicks = 20;
         ModuleChat.send(this, ModuleChat.body().text("Cleared DM cooldown history for ").value(count).text(" players."));
      }));
      this.addSetting("reset-stats", new ActionSetting("Reset Session Stats", () -> {
         this.totalBets = 0;
         this.totalWins = 0;
         this.totalLosses = 0;
         this.totalWagered = 0.0;
         this.totalPaidOut = 0.0;
         ModuleChat.send(this, ModuleChat.body().good("Reset Auto Gambler session statistics."));
      }));
   }

   @Override
   protected void onEnable() {
      this.commandQueue.clear();
      this.commandCooldownTicks = 0;
      this.dmTimerTicks = 40;
      this.on(TickEvent.TYPE, Stage.PRE, this::onTick);
      this.on(PacketReceiveEvent.TYPE, Stage.PRE, this::onPacketReceive);

      ModuleChat.send(
         this,
         ModuleChat.body()
            .good("Auto Gambler active")
            .text(" | Winrate: ")
            .value(Math.round(this.winChance.get()) + "%")
            .text(" | Multiplier: ")
            .value(String.format(Locale.US, "%.1fx", this.payoutMultiplier.get()))
            .text(" | Range: ")
            .value("$" + formatCompact(this.minBet.get()) + " - $" + formatCompact(this.maxBet.get()))
            .text(" | Staff Filter: ")
            .good("ON")
      );
   }

   @Override
   protected void onDisable() {
      this.commandQueue.clear();
      this.commandCooldownTicks = 0;
   }

   private void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      ClientPacketListener conn = mc.getConnection();
      if (mc.player == null || mc.level == null || conn == null) {
         return;
      }

      if (this.commandCooldownTicks > 0) {
         this.commandCooldownTicks--;
      }

      // Priority 1: Execute queued /pay and result /msg commands
      if (!this.commandQueue.isEmpty() && this.commandCooldownTicks <= 0) {
         String nextCmd = this.commandQueue.poll();
         if (nextCmd != null && !nextCmd.isBlank()) {
            this.dispatchLine(conn, nextCmd);
            int baseDelay = Math.max(10, Math.round(this.commandSpacingTicks.get()));
            int jitter = ThreadLocalRandom.current().nextInt(0, 6);
            this.commandCooldownTicks = baseDelay + jitter;
         }
         return;
      }

      // Priority 2: Auto-message online players (excluding staff)
      if (!this.autoDmPlayers.get()) {
         return;
      }

      if (this.dmTimerTicks > 0) {
         this.dmTimerTicks--;
         return;
      }

      if (this.pauseIfStaffInRegion.get() && StaffListModule.hasStaffInRegion()) {
         this.dmTimerTicks = 100;
         return;
      }

      this.sendNextInvite(mc, conn);
      int intervalTicks = Math.max(40, Math.round(this.dmIntervalSec.get() * 20.0F));
      int jitter = ThreadLocalRandom.current().nextInt(0, 15);
      this.dmTimerTicks = intervalTicks + jitter;
   }

   private void sendNextInvite(Minecraft mc, ClientPacketListener conn) {
      String selfName = mc.player.getGameProfile().name();
      String mode = this.dmCommand.get();
      long now = System.currentTimeMillis();
      long cooldownMs = Math.max(60_000L, Math.round(this.playerCooldownMin.get() * 60_000.0F));

      if ("Public Chat".equals(mode)) {
         String rendered = this.formatInviteText(selfName, "everyone");
         this.dispatchLine(conn, rendered);
         return;
      }

      List<PlayerInfo> candidates = new ArrayList<>(conn.getOnlinePlayers());
      Collections.shuffle(candidates);

      for (PlayerInfo info : candidates) {
         if (info == null || info.getProfile() == null) {
            continue;
         }
         String targetName = info.getProfile().name();
         if (targetName == null || targetName.isBlank() || targetName.equalsIgnoreCase(selfName)) {
            continue;
         }
         if (!ACCOUNT_NAME.matcher(targetName).matches()) {
            continue;
         }

         // Never message staff members in StaffListModule
         if (StaffListModule.isStaffPlayer(info) || StaffListModule.isStaffMember(targetName)) {
            continue;
         }

         // Skip friends if configured
         if (this.skipFriends.get() && FriendStore.getInstance().isFriend(targetName)) {
            continue;
         }

         String key = targetName.toLowerCase(Locale.ROOT);
         Long lastSent = this.messagedPlayers.get(key);
         if (lastSent != null && now - lastSent < cooldownMs) {
            continue;
         }

         this.messagedPlayers.put(key, now);
         String rendered = this.formatInviteText(selfName, targetName);
         String cmd = "/" + mode + " " + targetName + " " + rendered;
         this.dispatchLine(conn, cmd);
         return;
      }
   }

   private String formatInviteText(String selfName, String targetName) {
      String template = this.inviteMessage.get();
      if (template == null || template.isBlank()) {
         template = "Automated {mult}x Casino! /pay {me} {min}-{max} to roll! Instant auto-payout!";
      }

      double minB = this.minBet.get();
      double maxB = this.maxBet.get();
      String multStr = String.format(Locale.US, "%.1f", this.payoutMultiplier.get());
      if (multStr.endsWith(".0")) {
         multStr = multStr.substring(0, multStr.length() - 2);
      }

      String result = template
         .replace("{me}", selfName != null ? selfName : "")
         .replace("%me%", selfName != null ? selfName : "")
         .replace("{player}", targetName != null ? targetName : "")
         .replace("{min}", "$" + formatCompact(minB))
         .replace("{max}", "$" + formatCompact(maxB))
         .replace("{mult}", multStr)
         .replace("{winrate}", Math.round(this.winChance.get()) + "%");

      if (this.antiSpamSuffix.get()) {
         int token = ThreadLocalRandom.current().nextInt(0x100, 0xFFF);
         result = result + " [#" + Integer.toHexString(token) + "]";
      }
      return result;
   }

   private void onPacketReceive(PacketReceiveEvent event) {
      String raw = null;
      if (event.packet instanceof ClientboundSystemChatPacket chat && !chat.overlay()) {
         if (chat.content() != null) {
            raw = chat.content().getString();
         }
      } else if (event.packet instanceof ClientboundDisguisedChatPacket disguised) {
         if (disguised.message() != null) {
            raw = disguised.message().getString();
         }
      } else if (event.packet instanceof ClientboundPlayerChatPacket playerChat) {
         if (playerChat.unsignedContent() != null) {
            raw = playerChat.unsignedContent().getString();
         } else if (playerChat.body() != null) {
            raw = playerChat.body().content();
         }
      }

      if (raw == null || raw.isBlank()) {
         return;
      }

      String clean = STRIP_COLOR.matcher(raw).replaceAll("").trim();
      clean = LEADING_PREFIX.matcher(clean).replaceFirst("").trim();

      // Check if message mentions money transfer
      String lower = clean.toLowerCase(Locale.ROOT);
      boolean looksLikePayment = lower.contains("paid you")
         || lower.contains("has paid")
         || lower.contains("received from")
         || lower.contains("sent you")
         || lower.contains("has been received");

      // Anti-spoof guard: reject private messages, outgoing payment notifications, or player chat
      if (isSpoofOrChatLine(clean)) {
         return;
      }

      ParsedPayment payment = parsePayment(clean);
      if (payment == null) {
         if (looksLikePayment && this.debugChat.get()) {
            ModuleChat.send(this, ModuleChat.body().warn("Unrecognized payment syntax: ").text(clean));
         }
         return;
      }

      Minecraft mc = Minecraft.getInstance();
      if (mc.player != null && payment.sender.equalsIgnoreCase(mc.player.getGameProfile().name())) {
         return;
      }

      if (this.debugChat.get()) {
         ModuleChat.send(
            this,
            ModuleChat.body()
               .good("Payment detected")
               .text(" | Sender: ")
               .name(payment.sender)
               .text(" | Amount: ")
               .value("$" + formatExact(payment.amount))
         );
      }

      // Any online player who pays can gamble (no restriction to messaged players)
      this.handleIncomingPayment(payment.sender, payment.amount);
   }

   private static boolean isSpoofOrChatLine(String line) {
      String lower = line.toLowerCase(Locale.ROOT);
      if (lower.contains("->")
         || lower.contains("<-")
         || lower.contains("whispers")
         || lower.contains("whispered")
         || lower.contains("[msg]")
         || lower.contains("[pm]")
         || lower.contains("says:")
         || lower.contains("has been sent to")
         || lower.contains("you paid")
         || lower.contains("you sent")
         || line.startsWith("<")
         || CHAT_SPEAKER_PATTERN.matcher(line).find()) {
         return true;
      }
      return false;
   }

   private static ParsedPayment parsePayment(String clean) {
      Matcher m1 = PAY_PATTERN_1.matcher(clean);
      if (m1.matches()) {
         double amount = parseMoneyAmount(m1.group(1));
         String sender = m1.group(2);
         if (amount > 0.0 && sender != null) {
            return new ParsedPayment(sender, amount);
         }
      }

      Matcher m2 = PAY_PATTERN_2.matcher(clean);
      if (m2.matches()) {
         String sender = m2.group(1);
         double amount = parseMoneyAmount(m2.group(2));
         if (amount > 0.0 && sender != null) {
            return new ParsedPayment(sender, amount);
         }
      }

      Matcher m3 = PAY_PATTERN_3.matcher(clean);
      if (m3.matches()) {
         double amount = parseMoneyAmount(m3.group(1));
         String sender = m3.group(2);
         if (amount > 0.0 && sender != null) {
            return new ParsedPayment(sender, amount);
         }
      }

      Matcher m4 = PAY_PATTERN_4.matcher(clean);
      if (m4.matches()) {
         String sender = m4.group(1);
         double amount = parseMoneyAmount(m4.group(2));
         if (amount > 0.0 && sender != null) {
            return new ParsedPayment(sender, amount);
         }
      }

      Matcher m5 = PAY_PATTERN_5.matcher(clean);
      if (m5.matches()) {
         double amount = parseMoneyAmount(m5.group(1));
         String sender = m5.group(2);
         if (amount > 0.0 && sender != null) {
            return new ParsedPayment(sender, amount);
         }
      }

      return null;
   }

   private static double parseMoneyAmount(String rawAmount) {
      if (rawAmount == null || rawAmount.isBlank()) {
         return -1.0;
      }
      String s = rawAmount.replace(",", "").replace("$", "").trim().toUpperCase(Locale.ROOT);
      double multiplier = 1.0;
      if (s.endsWith("K")) {
         multiplier = 1_000.0;
         s = s.substring(0, s.length() - 1);
      } else if (s.endsWith("M")) {
         multiplier = 1_000_000.0;
         s = s.substring(0, s.length() - 1);
      } else if (s.endsWith("B")) {
         multiplier = 1_000_000_000.0;
         s = s.substring(0, s.length() - 1);
      }

      try {
         double val = Double.parseDouble(s);
         if (!Double.isFinite(val) || val <= 0.0) {
            return -1.0;
         }
         return val * multiplier;
      } catch (NumberFormatException e) {
         return -1.0;
      }
   }

   private void handleIncomingPayment(String player, double amount) {
      double minB = this.minBet.get();
      double maxB = this.maxBet.get();

      if (amount < minB || amount > maxB) {
         ModuleChat.send(
            this,
            ModuleChat.body()
               .warn("Out-of-bounds bet")
               .text(" from ")
               .name(player)
               .text(": ")
               .value("$" + formatExact(amount))
               .text(" (Allowed: $" + formatCompact(minB) + " - $" + formatCompact(maxB) + ")")
         );

         if (this.refundInvalid.get()) {
            this.queueCommand("/pay " + player + " " + formatPayCommand(amount));
            if (this.replyResults.get()) {
               String replyCmd = this.replyPrefix(player)
                  + "Bet of $"
                  + formatCompact(amount)
                  + " refunded! Allowed bet range: $"
                  + formatCompact(minB)
                  + " - $"
                  + formatCompact(maxB)
                  + ".";
               this.queueCommand(replyCmd);
            }
         }
         return;
      }

      this.executeGamblingRoll(player, amount, false);
   }

   private void executeGamblingRoll(String player, double amount, boolean simulation) {
      double chance = Math.max(0.0, Math.min(100.0, this.winChance.get()));
      boolean won;
      if (chance <= 0.0) {
         won = false;
      } else if (chance >= 100.0) {
         won = true;
      } else {
         won = ThreadLocalRandom.current().nextDouble(0.0, 100.0) < chance;
      }

      double rawPayout = won ? amount * (double)this.payoutMultiplier.get() : 0.0;
      double payout = Math.round(rawPayout * 100.0) / 100.0;
      String outcomeDetail = this.buildOutcomeDescription(won, chance);

      if (!simulation) {
         this.totalBets++;
         this.totalWagered += amount;
         if (won) {
            this.totalWins++;
            this.totalPaidOut += payout;
         } else {
            this.totalLosses++;
         }
      }

      if (won) {
         ModuleChat.send(
            this,
            ModuleChat.body()
               .text(simulation ? "[SIM] " : "")
               .name(player)
               .text(" bet ")
               .value("$" + formatCompact(amount))
               .text(" -> ")
               .good("PLAYER WON!")
               .text(" (" + outcomeDetail + ") | Payout: ")
               .value("$" + formatCompact(payout))
         );

         if (!simulation) {
            this.queueCommand("/pay " + player + " " + formatPayCommand(payout));
            if (this.replyResults.get()) {
               String msg = this.replyPrefix(player)
                  + "[WIN] "
                  + outcomeDetail
                  + "! You won $"
                  + formatCompact(payout)
                  + "! Paid automatically!";
               this.queueCommand(msg);
            }
         }
      } else {
         double netProfit = this.totalWagered - this.totalPaidOut;
         ModuleChat.send(
            this,
            ModuleChat.body()
               .text(simulation ? "[SIM] " : "")
               .name(player)
               .text(" bet ")
               .value("$" + formatCompact(amount))
               .text(" -> ")
               .danger("HOUSE WON!")
               .text(" (" + outcomeDetail + ") | Net Profit: ")
               .good((netProfit >= 0 ? "+$" : "-$") + formatCompact(Math.abs(netProfit)))
         );

         if (!simulation && this.replyResults.get()) {
            String msg = this.replyPrefix(player)
               + "[LOSS] "
               + outcomeDetail
               + ". Better luck next time! /pay again to re-roll!";
            this.queueCommand(msg);
         }
      }
   }

   private String buildOutcomeDescription(boolean won, double winChancePercent) {
      String mode = this.gameType.get();
      if ("Dice Roll (1-100)".equals(mode)) {
         int threshold = Math.max(2, Math.min(100, 100 - (int)Math.round(winChancePercent) + 1));
         int roll;
         if (won) {
            roll = ThreadLocalRandom.current().nextInt(threshold, 101);
         } else {
            roll = ThreadLocalRandom.current().nextInt(1, Math.max(2, threshold));
         }
         return "Rolled " + roll + "/100 (needed " + threshold + "+)";
      } else if ("Double or Nothing".equals(mode)) {
         return won ? "Landed on DOUBLE" : "Landed on NOTHING";
      } else {
         return won ? "Coinflip landed on HEADS" : "Coinflip landed on TAILS";
      }
   }

   private String replyPrefix(String player) {
      String mode = this.dmCommand.get();
      String cmd = "Public Chat".equals(mode) ? "msg" : mode;
      return "/" + cmd + " " + player + " ";
   }

   private void queueCommand(String command) {
      if (command != null && !command.isBlank()) {
         this.commandQueue.offer(command);
      }
   }

   private void dispatchLine(ClientPacketListener conn, String text) {
      if (conn == null || text == null || text.isBlank()) {
         return;
      }
      String trimmed = text.trim();
      if (trimmed.startsWith("/")) {
         String cmd = trimmed.substring(1).trim();
         if (!cmd.isEmpty()) {
            conn.sendCommand(cmd);
         }
      } else {
         conn.sendChat(trimmed);
      }
   }

   private void simulateTestBet() {
      this.executeGamblingRoll("TestPlayer", 50_000.0, true);
   }

   private void printSessionStats() {
      double netProfit = this.totalWagered - this.totalPaidOut;
      ModuleChat.Body body = ModuleChat.body()
         .text("Session Bets: ")
         .value(this.totalBets)
         .text(" (W: ")
         .good(String.valueOf(this.totalWins))
         .text(" / L: ")
         .danger(String.valueOf(this.totalLosses))
         .text(") | Wagered: ")
         .value("$" + formatCompact(this.totalWagered))
         .text(" | Paid: ")
         .value("$" + formatCompact(this.totalPaidOut))
         .text(" | Profit: ");
      if (netProfit >= 0.0) {
         body.good("+$" + formatCompact(netProfit));
      } else {
         body.danger("-$" + formatCompact(Math.abs(netProfit)));
      }
      ModuleChat.send(this, body);
   }

   private static String formatCompact(double value) {
      if (value >= 1_000_000_000.0) {
         return cleanDecimal(value / 1_000_000_000.0) + "B";
      } else if (value >= 1_000_000.0) {
         return cleanDecimal(value / 1_000_000.0) + "M";
      } else if (value >= 1_000.0) {
         return cleanDecimal(value / 1_000.0) + "K";
      } else if (value >= 1.0) {
         return cleanDecimal(value);
      } else {
         return String.format(Locale.US, "%.2f", value);
      }
   }

   private static String cleanDecimal(double val) {
      String s = String.format(Locale.US, "%.2f", val);
      while (s.contains(".") && (s.endsWith("0") || s.endsWith("."))) {
         s = s.substring(0, s.length() - 1);
      }
      return s;
   }

   private static String formatExact(double value) {
      if (value >= 1.0 && Math.abs(value - Math.round(value)) < 0.0001) {
         return NumberFormat.getIntegerInstance(Locale.US).format((long)value);
      }
      return String.format(Locale.US, "%.2f", value);
   }

   private static String formatPayCommand(double amount) {
      if (amount >= 1.0 && Math.abs(amount - Math.round(amount)) < 0.0001) {
         return String.valueOf(Math.round(amount));
      } else {
         return String.format(Locale.US, "%.2f", amount);
      }
   }

   @Environment(EnvType.CLIENT)
   private record ParsedPayment(String sender, double amount) {
   }
}
