package net.spectre.client.gui.mainmenu;

import imgui.ImDrawList;
import imgui.ImFont;
import java.util.List;
import java.util.Locale;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import net.spectre.client.gui.SpectreDraw;
import net.spectre.client.gui.ThemeImages;
import net.spectre.client.gui.WorkspaceMascot;

@Environment(EnvType.CLIENT)
public final class DuskMenu {
   private static final List<MenuAction> UTILITIES = List.of(MenuAction.MODS, MenuAction.LANGUAGE, MenuAction.ACCESSIBILITY);

   private DuskMenu() {
   }

   public static void render(MenuContext c) {
      ImDrawList dl = c.bg();
      float sw = c.width();
      float sh = c.height();
      float s = c.scale();
      float a = c.intro(0.0F);

      // Deep, understated gradient canvas
      dl.addRectFilledMultiColor(
         0.0F, 0.0F, sw, sh,
         SpectreDraw.col(0xff090f19, a), SpectreDraw.col(0xff060a12, a),
         SpectreDraw.col(0xff04070d, a), SpectreDraw.col(0xff080d17, a)
      );

      // Subtle architectural grid
      float gridStep = Math.max(48.0F, Math.round(56.0F * s));
      int gridColor = SpectreDraw.col(0xff72e6ef, 0.024F * a);
      for (float gx = 0.0F; gx < sw; gx += gridStep) {
         dl.addLine(gx, 0.0F, gx, sh, gridColor, 1.0F);
      }
      for (float gy = 0.0F; gy < sh; gy += gridStep) {
         dl.addLine(0.0F, gy, sw, gy, gridColor, 1.0F);
      }

      // Corner technical crosshairs
      float m = 32.0F * s;
      float cl = 7.0F * s;
      int markerColor = SpectreDraw.col(0xff72e6ef, 0.16F * a);
      crosshair(dl, m, m, cl, markerColor);
      crosshair(dl, sw - m, m, cl, markerColor);
      crosshair(dl, m, sh - m, cl, markerColor);
      crosshair(dl, sw - m, sh - m, cl, markerColor);

      // Aesthetic atmospheric background: nebulae, drifting particles, constellation links
      drawAmbientBackground(c, dl, sw, sh, s, a);

      float leftMargin = Math.max(48.0F * s, sw * 0.065F);

      // Top-Left Brand Block
      float brandY = 40.0F * s;
      ImFont nameFont = c.nameFont();
      ImFont tagFont = c.tagFont();
      ImFont bodyFont = c.bodyFont();
      ImFont itemFont = c.itemFont();

      c.spacedText(dl, nameFont, leftMargin, brandY, 5.0F * s, 0xfff8fafc, a, "AETHER");
      float brandH = c.textHeight(nameFont);

      float pipX = leftMargin + 2.0F * s;
      float pipY = brandY + brandH + 9.0F * s;
      dl.addCircleFilled(pipX, pipY, 3.2F * s, SpectreDraw.col(0xff22c55e, a), 12);
      dl.addCircle(pipX, pipY, 5.2F * s, SpectreDraw.col(0xff22c55e, 0.28F * a), 12, 1.0F);
      c.text(dl, tagFont, pipX + 10.0F * s, pipY - c.textHeight(tagFont) * 0.5F, 0xff8da4b8, a, "SYSTEM ACTIVE  //  FABRIC 26.2  //  114 MODULES READY");

      // Top-Right Player Session Card
      float userW = 230.0F * s;
      float userH = 46.0F * s;
      float userX = sw - leftMargin - userW;
      float userY = brandY;

      dl.addRectFilled(userX, userY, userX + userW, userY + userH, SpectreDraw.col(0x350d1522, a), 4.0F * s);
      dl.addRect(userX, userY, userX + userW, userY + userH, SpectreDraw.col(0x283b5066, a), 4.0F * s, 0, 1.0F);

      float faceSize = 30.0F * s;
      float fx = userX + 8.0F * s;
      float fy = userY + (userH - faceSize) * 0.5F;
      PlayerFaces.draw(dl, Minecraft.getInstance().getUser().getProfileId(), false, fx, fy, faceSize, s, a);

      float utX = fx + faceSize + 10.0F * s;
      String playerLabel = c.displayName();
      c.text(dl, bodyFont, utX, userY + 8.0F * s, 0xfff1f5f9, a, playerLabel);
      dl.addCircleFilled(utX + 2.0F * s, userY + 28.0F * s + 3.0F * s, 2.2F * s, SpectreDraw.col(0xff22c55e, a), 8);
      c.text(dl, tagFont, utX + 8.0F * s, userY + 28.0F * s - c.textHeight(tagFont) * 0.5F + 3.0F * s, 0xff64748b, a, "Online");

      // Layout columns
      boolean showStage = sw >= 920.0F * s;
      float deckW = showStage ? Math.min(380.0F * s, sw * 0.36F) : Math.min(420.0F * s, sw - leftMargin * 2.0F);
      float deckX = showStage ? leftMargin : (sw - deckW) * 0.5F;
      float deckY = Math.max(brandY + brandH + 34.0F * s, sh * 0.24F);
      float rowH = 58.0F * s;
      float rowGap = 8.0F * s;

      // Main Navigation Cards
      for (int i = 0; i < MenuAction.MAIN.size(); i++) {
         MenuAction action = MenuAction.MAIN.get(i);
         float y = deckY + i * (rowH + rowGap);
         renderActionCard(c, dl, action, i, deckX, y, deckW, rowH, s, a);
      }

      // Right Stage: Aether Client Hub
      if (showStage) {
         float stageW = Math.min(400.0F * s, sw - deckX - deckW - leftMargin - 30.0F * s);
         float stageX = sw - leftMargin - stageW;
         float stageH = MenuAction.MAIN.size() * rowH + (MenuAction.MAIN.size() - 1) * rowGap;
         renderConsoleCard(c, dl, stageX, deckY, stageW, stageH, s, a);
      }

      // Bottom Bar
      renderBottomBar(c, dl, leftMargin, sh - 42.0F * s, sw - leftMargin * 2.0F, s, a);
   }

   private static void renderActionCard(MenuContext c, ImDrawList dl, MenuAction action, int index, float x, float y, float w, float h, float s, float a) {
      boolean enabled = c.enabled(action);
      float hover = a > 0.5F ? c.control(action, x, y, w, h) : c.hover(action, false);

      float slideX = x + (enabled ? hover * 5.0F * s : 0.0F);
      float entry = c.intro(0.08F + index * 0.04F);

      int bgCol = enabled
         ? SpectreDraw.mix(0x220f1826, 0x481e2e42, hover)
         : 0x140d141e;
      int borderCol = enabled
         ? SpectreDraw.mix(0x22384c60, 0x6672e6ef, hover)
         : 0x141e2b38;

      dl.addRectFilled(slideX, y, slideX + w, y + h, SpectreDraw.col(bgCol, a * entry), 6.0F * s);
      dl.addRect(slideX, y, slideX + w, y + h, SpectreDraw.col(borderCol, a * entry), 6.0F * s, 0, 1.0F);

      // Category Icon
      int iconColor = enabled ? SpectreDraw.mix(0xff64748b, 0xff72e6ef, hover) : 0xff3b4d5c;
      MenuIcons.draw(dl, action, slideX + 22.0F * s, y + h * 0.5F, 7.5F * s, SpectreDraw.col(iconColor, a * entry), 1.3F * s);

      // Non-overlapping vertical text layout
      ImFont tagFont = c.tagFont();
      ImFont itemFont = c.itemFont();
      float titleH = c.textHeight(itemFont);
      float subH = c.textHeight(tagFont);
      float vGap = 4.0F * s;
      float contentH = titleH + vGap + subH;
      float textStartY = y + (h - contentH) * 0.5F;

      // Main action label
      float tx = slideX + 44.0F * s;
      String label = action.label();
      int titleColor = enabled ? SpectreDraw.mix(0xffe2e8f0, 0xffffffff, hover) : 0xff526372;
      c.text(dl, itemFont, tx, textStartY, titleColor, a * entry, label);

      // Subtitle description
      String sub = subtitleFor(action);
      int subColor = enabled ? SpectreDraw.mix(0xff64748b, 0xff94a3b8, hover) : 0xff3d4b57;
      c.text(dl, tagFont, tx, textStartY + titleH + vGap, subColor, a * entry, sub);

      // Subtle right chevron
      if (enabled) {
         float arrX = slideX + w - 22.0F * s + hover * 3.0F * s;
         float arrY = y + h * 0.5F;
         int arrColor = SpectreDraw.mix(0x3572e6ef, 0xff72e6ef, hover);
         chevron(dl, arrX, arrY, 4.5F * s, SpectreDraw.col(arrColor, a * entry), 1.4F * s);
      }
   }

   private static void renderConsoleCard(MenuContext c, ImDrawList dl, float x, float y, float w, float h, float s, float a) {
      dl.addRectFilled(x, y, x + w, y + h, SpectreDraw.col(0x220f1726, a), 8.0F * s);
      dl.addRect(x, y, x + w, y + h, SpectreDraw.col(0x22384d63, a), 8.0F * s, 0, 1.0F);

      // Card Header
      ImFont tagFont = c.tagFont();
      ImFont bodyFont = c.bodyFont();
      c.text(dl, bodyFont, x + 20.0F * s, y + 18.0F * s, 0xfff1f5f9, a, "Aether Client");
      c.text(dl, tagFont, x + w - 74.0F * s, y + 20.0F * s, 0xff38bdf8, 0.9F * a, "v1.0.0");
      dl.addLine(x + 18.0F * s, y + 38.0F * s, x + w - 18.0F * s, y + 38.0F * s, SpectreDraw.col(0xff38bdf8, 0.12F * a), 1.0F);

      // Mascot display
      float mx = x + w * 0.5F;
      float my = y + 102.0F * s;
      dl.addCircle(mx, my, 46.0F * s, SpectreDraw.col(0xff72e6ef, 0.08F * a), 48, 1.0F);
      dl.addCircle(mx, my, 52.0F * s, SpectreDraw.col(0xff72e6ef, 0.04F * a), 48, 1.0F);
      WorkspaceMascot.drawBrand(dl, mx, my, 86.0F * s, 0.88F * a);

      // Chips row
      float chipY = y + 168.0F * s;
      float chipH = 24.0F * s;
      String[] chips = {"Combat · 17", "Movement · 12", "Render · 34", "Utility · 8"};
      float chipGap = 6.0F * s;
      float totalChipsW = (chips.length - 1) * chipGap;
      for (String chip : chips) {
         totalChipsW += c.textWidth(tagFont, chip) + 14.0F * s;
      }
      float startChipX = x + (w - totalChipsW) * 0.5F;
      for (String chip : chips) {
         float cw = c.textWidth(tagFont, chip) + 14.0F * s;
         dl.addRectFilled(startChipX, chipY, startChipX + cw, chipY + chipH, SpectreDraw.col(0x251e293b, a), 4.0F * s);
         dl.addRect(startChipX, chipY, startChipX + cw, chipY + chipH, SpectreDraw.col(0x22475569, a), 4.0F * s, 0, 1.0F);
         c.text(dl, tagFont, startChipX + 7.0F * s, chipY + (chipH - c.textHeight(tagFont)) * 0.5F, 0xff94a3b8, a, chip);
         startChipX += cw + chipGap;
      }

      // Interactive Quick-Launch Bar for Client Workspace
      float btnMargin = 16.0F * s;
      float btnW = w - btnMargin * 2.0F;
      float btnH = 44.0F * s;
      float btnY = y + h - btnH - btnMargin;
      float btnHover = a > 0.5F ? c.control(MenuAction.SPECTRE, x + btnMargin, btnY, btnW, btnH) : c.hover(MenuAction.SPECTRE, false);

      int btnBg = SpectreDraw.mix(0x25122132, 0x600284c7, btnHover);
      int btnBorder = SpectreDraw.mix(0x2e38bdf8, 0x8572e6ef, btnHover);
      dl.addRectFilled(x + btnMargin, btnY, x + btnMargin + btnW, btnY + btnH, SpectreDraw.col(btnBg, a), 6.0F * s);
      dl.addRect(x + btnMargin, btnY, x + btnMargin + btnW, btnY + btnH, SpectreDraw.col(btnBorder, a), 6.0F * s, 0, 1.0F);

      float leftLabelX = x + btnMargin + 16.0F * s;
      int labelColor = SpectreDraw.mix(0xffcce5f7, 0xffffffff, btnHover);
      c.text(dl, bodyFont, leftLabelX, btnY + (btnH - c.textHeight(bodyFont)) * 0.5F, labelColor, a, "Open Client Menu");

      // Keybind badge [RIGHT SHIFT]
      String badge = "Right Shift";
      float badgeW = c.textWidth(tagFont, badge) + 14.0F * s;
      float badgeH = 22.0F * s;
      float badgeX = x + btnMargin + btnW - badgeW - 12.0F * s;
      float badgeY = btnY + (btnH - badgeH) * 0.5F;
      dl.addRectFilled(badgeX, badgeY, badgeX + badgeW, badgeY + badgeH, SpectreDraw.col(0x400f172a, a), 4.0F * s);
      dl.addRect(badgeX, badgeY, badgeX + badgeW, badgeY + badgeH, SpectreDraw.col(0x4072e6ef, a), 4.0F * s, 0, 1.0F);
      c.text(dl, tagFont, badgeX + 7.0F * s, badgeY + (badgeH - c.textHeight(tagFont)) * 0.5F, 0xff72e6ef, a, badge);
   }

   private static void renderBottomBar(MenuContext c, ImDrawList dl, float x, float y, float w, float s, float a) {
      ImFont tagFont = c.tagFont();

      // Left copyright / watermark
      c.text(dl, tagFont, x, y + 8.0F * s, 0xff475569, a, "Aether Client 1.0.0 · Minecraft 26.2 (Fabric)");

      // Right utilities row
      float utilH = 28.0F * s;
      float curX = x + w;

      for (int i = UTILITIES.size() - 1; i >= 0; i--) {
         MenuAction act = UTILITIES.get(i);
         String label = act.label();
         float textW = c.textWidth(tagFont, label);
         float btnW = textW + 28.0F * s;
         curX -= btnW;

         float hover = a > 0.5F ? c.control(act, curX, y, btnW, utilH) : c.hover(act, false);

         int bg = SpectreDraw.mix(0x180f172a, 0x481e293b, hover);
         int border = SpectreDraw.mix(0x20334155, 0x6072e6ef, hover);
         dl.addRectFilled(curX, y, curX + btnW, y + utilH, SpectreDraw.col(bg, a), 4.0F * s);
         dl.addRect(curX, y, curX + btnW, y + utilH, SpectreDraw.col(border, a), 4.0F * s, 0, 1.0F);

         float iconR = 5.0F * s;
         float iconX = curX + 11.0F * s;
         float iconY = y + utilH * 0.5F;
         int iconColor = SpectreDraw.mix(0xff64748b, 0xff72e6ef, hover);
         MenuIcons.draw(dl, act, iconX, iconY, iconR, SpectreDraw.col(iconColor, a), 1.2F * s);

         int textCol = SpectreDraw.mix(0xff8da4b8, 0xfff1f5f9, hover);
         c.text(dl, tagFont, curX + 20.0F * s, y + (utilH - c.textHeight(tagFont)) * 0.5F, textCol, a, label);

         curX -= 8.0F * s;
      }
   }

   private static String subtitleFor(MenuAction action) {
      return switch (action) {
         case SINGLEPLAYER -> "Local Worlds & Schematics";
         case MULTIPLAYER -> "Server Browser & Proxies";
         case REALMS -> "Mojang Cloud Realms";
         case OPTIONS -> "Preferences & Controls";
         case QUIT -> "Exit Application";
         default -> "";
      };
   }

   private static void crosshair(ImDrawList dl, float cx, float cy, float len, int color) {
      dl.addLine(cx - len, cy, cx + len, cy, color, 1.0F);
      dl.addLine(cx, cy - len, cx, cy + len, color, 1.0F);
   }

   private static void cornerBrackets(ImDrawList dl, float x, float y, float w, float h, float len, int color, float line) {
      dl.addLine(x, y, x + len, y, color, line);
      dl.addLine(x, y, x, y + len, color, line);

      dl.addLine(x + w, y, x + w - len, y, color, line);
      dl.addLine(x + w, y, x + w, y + len, color, line);

      dl.addLine(x, y + h, x + len, y + h, color, line);
      dl.addLine(x, y + h, x, y + h - len, color, line);

      dl.addLine(x + w, y + h, x + w - len, y + h, color, line);
      dl.addLine(x + w, y + h, x + w, y + h - len, color, line);
   }

   private static void chevron(ImDrawList dl, float cx, float cy, float r, int color, float line) {
      dl.addLine(cx - r * 0.4F, cy - r * 0.7F, cx + r * 0.4F, cy, color, line);
      dl.addLine(cx + r * 0.4F, cy, cx - r * 0.4F, cy + r * 0.7F, color, line);
   }

   private static void drawAmbientBackground(MenuContext c, ImDrawList dl, float sw, float sh, float s, float a) {
      float t = c.time();
      float lx = c.lookX() * 14.0F * s;
      float ly = c.lookY() * 10.0F * s;

      // 1. Soft atmospheric glow nebulae (breathing light fields)
      float pulse1 = 0.85F + 0.15F * Mth.sin(t * 0.8F);
      float pulse2 = 0.82F + 0.18F * Mth.cos(t * 0.65F);
      drawGlow(dl, sw * 0.74F + lx * 0.5F, sh * 0.42F + ly * 0.5F, 240.0F * s, 0x38bdf8, 0.055F * pulse1 * a);
      drawGlow(dl, sw * 0.24F + lx * 0.4F, sh * 0.60F + ly * 0.4F, 200.0F * s, 0x72e6ef, 0.045F * pulse2 * a);
      drawGlow(dl, sw * 0.50F + lx * 0.2F, sh * 0.15F + ly * 0.2F, 160.0F * s, 0x818cf8, 0.035F * a);

      // Center Sci-Fi Donut Emblem (spinning smoothly with gentle breathing pulse)
      ThemeImages.Texture emblem = SpectreDraw.texture("/assets/spectre/textures/gui/donut_emblem.png");
      if (emblem != null) {
         float cx = sw * 0.5F + lx * 0.35F;
         float cy = sh * 0.5F + ly * 0.35F;
         float emblemSize = Math.min(sw, sh) * 0.64F;
         float pulse = 0.88F + 0.12F * Mth.sin(t * 1.1F);
         float rot = t * 0.08F;

         drawGlow(dl, cx, cy, emblemSize * 0.46F, 0x38bdf8, 0.07F * pulse * a);

         float hw = emblemSize * 0.5F;
         float hh = emblemSize * 0.5F;
         float cos = (float)Math.cos(rot);
         float sin = (float)Math.sin(rot);

         float x1 = cx + (-hw * cos - -hh * sin);
         float y1 = cy + (-hw * sin + -hh * cos);
         float x2 = cx + (hw * cos - -hh * sin);
         float y2 = cy + (hw * sin + -hh * cos);
         float x3 = cx + (hw * cos - hh * sin);
         float y3 = cy + (hw * sin + hh * cos);
         float x4 = cx + (-hw * cos - hh * sin);
         float y4 = cy + (-hw * sin + hh * cos);

         dl.addImageQuad(
            emblem.id(),
            x1, y1, x2, y2, x3, y3, x4, y4,
            0.0F, 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 0.0F, 1.0F,
            SpectreDraw.col(0xffffffff, 0.55F * pulse * a)
         );
      }

      // 2. Subtle scanning grid data pulse
      float scanY = ((t * 85.0F * s) % (sh + 160.0F * s)) - 80.0F * s;
      int scanLineColor = SpectreDraw.col(0xff72e6ef, 0.045F * a);
      dl.addLine(0.0F, scanY, sw, scanY, scanLineColor, 1.5F * s);

      // 3. Floating dust & starfield particles with smooth looping and parallax
      final int count = 48;
      float[] px = new float[count];
      float[] py = new float[count];

      for (int i = 0; i < count; i++) {
         float seedX = (float)((i * 1973 + 31) % 1000) / 1000.0F;
         float seedY = (float)((i * 3571 + 67) % 1000) / 1000.0F;
         float speed = 0.4F + (float)((i * 593) % 100) / 100.0F * 0.6F;
         float size = (1.1F + (float)((i * 281) % 100) / 100.0F * 1.5F) * s;

         float rawX = (seedX * sw + t * (speed * 9.0F * s) + lx * (speed * 0.8F)) % sw;
         if (rawX < 0.0F) rawX += sw;
         float rawY = (seedY * sh - t * (speed * 14.0F * s) + ly * (speed * 0.8F)) % sh;
         if (rawY < 0.0F) rawY += sh;

         px[i] = rawX;
         py[i] = rawY;

         float twinkle = 0.4F + 0.6F * (0.5F + 0.5F * Mth.sin(t * (1.2F + speed) + i));
         int pCol = (i % 3 == 0) ? 0xff72e6ef : (i % 3 == 1) ? 0xff38bdf8 : 0xffe2e8f0;

         dl.addCircleFilled(rawX, rawY, size, SpectreDraw.col(pCol, 0.28F * twinkle * a), 8);
         if (size > 1.8F * s) {
            dl.addCircle(rawX, rawY, size * 2.2F, SpectreDraw.col(pCol, 0.08F * twinkle * a), 8, 1.0F);
         }
      }

      // Constellation mesh lines between nearby particles
      float maxDistSq = (70.0F * s) * (70.0F * s);
      for (int i = 0; i < count; i++) {
         for (int j = i + 1; j < count; j++) {
            float dx = px[i] - px[j];
            float dy = py[i] - py[j];
            float dSq = dx * dx + dy * dy;
            if (dSq < maxDistSq) {
               float distFactor = 1.0F - (dSq / maxDistSq);
               int linkCol = SpectreDraw.col(0xff72e6ef, 0.055F * distFactor * a);
               dl.addLine(px[i], py[i], px[j], py[j], linkCol, 1.0F);
            }
         }
      }

      // 4. Subtle technical telemetry labels along bottom edges
      ImFont tagFont = c.tagFont();
      c.text(dl, tagFont, 40.0F * s, sh - 20.0F * s, 0xff475569, 0.35F * a, "SYS_GRID // LAT 45.109 // LON -12.441");
      c.text(dl, tagFont, sw - 190.0F * s, sh - 20.0F * s, 0xff475569, 0.35F * a, "AETHER KERNEL // SYNCED");
   }

   private static void drawGlow(ImDrawList dl, float cx, float cy, float radius, int rgb, float maxAlpha) {
      int steps = 12;
      for (int i = steps; i >= 1; i--) {
         float r = radius * (i / (float)steps);
         float t = (float)i / steps;
         float falloff = (1.0F - t) * (1.0F - t);
         dl.addCircleFilled(cx, cy, r, SpectreDraw.col(rgb, maxAlpha * falloff), 32);
      }
   }
}
