package net.spectre.client.module.impl.misc;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.common.ClientboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ClientboundPingPacket;
import net.minecraft.network.protocol.common.ServerboundKeepAlivePacket;
import net.minecraft.network.protocol.common.ServerboundPongPacket;
import net.minecraft.network.protocol.game.ClientboundAnimatePacket;
import net.minecraft.network.protocol.game.ClientboundBlockUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundDamageEventPacket;
import net.minecraft.network.protocol.game.ClientboundExplodePacket;
import net.minecraft.network.protocol.game.ClientboundLevelParticlesPacket;
import net.minecraft.network.protocol.game.ClientboundMoveEntityPacket;
import net.minecraft.network.protocol.game.ClientboundRotateHeadPacket;
import net.minecraft.network.protocol.game.ClientboundSectionBlocksUpdatePacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.network.protocol.game.ClientboundSoundEntityPacket;
import net.minecraft.network.protocol.game.ClientboundSoundPacket;
import net.minecraft.network.protocol.game.ServerboundAttackPacket;
import net.minecraft.network.protocol.game.ServerboundChatAckPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandPacket;
import net.minecraft.network.protocol.game.ServerboundChatCommandSignedPacket;
import net.minecraft.network.protocol.game.ServerboundChatPacket;
import net.minecraft.network.protocol.game.ServerboundClientCommandPacket;
import net.minecraft.network.protocol.game.ServerboundClientTickEndPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClickPacket;
import net.minecraft.network.protocol.game.ServerboundContainerClosePacket;
import net.minecraft.network.protocol.game.ServerboundInteractPacket;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundMoveVehiclePacket;
import net.minecraft.network.protocol.game.ServerboundPaddleBoatPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerActionPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundSetCarriedItemPacket;
import net.minecraft.network.protocol.game.ServerboundSwingPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemOnPacket;
import net.minecraft.network.protocol.game.ServerboundUseItemPacket;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.impl.PacketReceiveNettyEvent;
import net.spectre.client.event.impl.PacketSendEvent;
import net.spectre.client.gui.PacketCancellerPanel;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.BooleanSetting;

@Environment(EnvType.CLIENT)
public final class PacketCancellerModule extends ClientModule {

   public static PacketCancellerModule INSTANCE;

   public static final class PacketEntry {
      public final String id;
      public final String name;
      public final String category;
      public final boolean serverbound;
      public final Class<?> packetClass;
      public final String description;
      public boolean cancelled;
      public long observedCount;
      public long cancelledCount;

      public PacketEntry(String id, String name, String category, boolean serverbound, Class<?> packetClass, String description) {
         this.id = id;
         this.name = name;
         this.category = category;
         this.serverbound = serverbound;
         this.packetClass = packetClass;
         this.description = description;
         this.cancelled = false;
      }
   }

   public final BooleanSetting cancelServerbound = this.addSetting("cancel-serverbound", new BooleanSetting("Cancel Outgoing", true));
   public final BooleanSetting cancelClientbound = this.addSetting("cancel-clientbound", new BooleanSetting("Cancel Incoming", false));
   public final BooleanSetting logChat = this.addSetting("log-chat", new BooleanSetting("Log Cancelled to Chat", false));

   // Quick Presets
   public final BooleanSetting blinkMovement = this.addSetting("blink-movement", new BooleanSetting("Blink / Freeze Movement", false));
   public final BooleanSetting muteSwings = this.addSetting("mute-swings", new BooleanSetting("Mute Arm Swings", false));
   public final BooleanSetting muteKeepAlive = this.addSetting("mute-keepalive", new BooleanSetting("Mute KeepAlive Ping", false));
   public final BooleanSetting muteInteractions = this.addSetting("mute-interactions", new BooleanSetting("Mute Interactions", false));
   public final BooleanSetting muteExplosions = this.addSetting("mute-explosions", new BooleanSetting("Mute Incoming Explosions", false));
   public final BooleanSetting muteParticles = this.addSetting("mute-particles", new BooleanSetting("Mute Incoming Particles", false));

   private final List<PacketEntry> packets = new CopyOnWriteArrayList<>();
   private final Map<String, PacketEntry> packetById = new ConcurrentHashMap<>();

   private long totalPacketsSeen = 0;
   private long totalPacketsCancelled = 0;

   public PacketCancellerModule() {
      super(
         "packet-canceller",
         "Packet Canceller",
         "Intercepts and drops specific network packets. Includes dedicated sub-menu and live traffic monitor.",
         ModuleCategory.MISC
      );
      INSTANCE = this;

      this.addSetting("open-submenu", new ActionSetting("Open Packet Sub-Menu", PacketCancellerPanel::open));

      this.initPacketRegistry();
      this.loadConfig();
   }

   private void register(String id, String name, String category, boolean serverbound, Class<?> packetClass, String desc) {
      PacketEntry entry = new PacketEntry(id, name, category, serverbound, packetClass, desc);
      this.packets.add(entry);
      this.packetById.put(id, entry);
   }

   private void initPacketRegistry() {
      // --- SERVERBOUND (Outgoing) ---
      // Movement
      this.register("sb_move_pos", "Move Position (XYZ)", "Movement", true, ServerboundMovePlayerPacket.Pos.class, "Sends player XYZ position coordinates");
      this.register("sb_move_pos_rot", "Move Position & Rotation", "Movement", true, ServerboundMovePlayerPacket.PosRot.class, "Sends player XYZ position and pitch/yaw rotation");
      this.register("sb_move_rot", "Move Rotation (Look)", "Movement", true, ServerboundMovePlayerPacket.Rot.class, "Sends player look direction (pitch/yaw)");
      this.register("sb_move_status", "Move Status (OnGround)", "Movement", true, ServerboundMovePlayerPacket.StatusOnly.class, "Sends player on-ground status without position changes");
      this.register("sb_move_vehicle", "Move Vehicle / Boat", "Movement", true, ServerboundMoveVehiclePacket.class, "Sends ridden vehicle or boat position/velocity");
      this.register("sb_paddle_boat", "Paddle Boat State", "Movement", true, ServerboundPaddleBoatPacket.class, "Sends boat paddling animations");

      // Combat & Actions
      this.register("sb_swing", "Arm Swing Animation", "Combat & Actions", true, ServerboundSwingPacket.class, "Sends client attack swing animation");
      this.register("sb_attack", "Attack Entity", "Combat & Actions", true, ServerboundAttackPacket.class, "Sends attack packet to damage an entity");
      this.register("sb_interact", "Interact With Entity", "Combat & Actions", true, ServerboundInteractPacket.class, "Sends entity interaction (trading, mounting, petting)");
      this.register("sb_use_item", "Use Item / Eat / Block", "Combat & Actions", true, ServerboundUseItemPacket.class, "Sends item activation (eating, drinking, drawing bow)");
      this.register("sb_use_item_on", "Use Item On Block", "Combat & Actions", true, ServerboundUseItemOnPacket.class, "Sends block placement or block right-click interaction");
      this.register("sb_player_action", "Player Action (Mine / Swap)", "Combat & Actions", true, ServerboundPlayerActionPacket.class, "Sends digging, dropping items, offhand swapping");
      this.register("sb_player_command", "Player Command (Sprint / Sneak)", "Combat & Actions", true, ServerboundPlayerCommandPacket.class, "Sends sprinting, sneaking, elytra open commands");

      // Inventory & Containers
      this.register("sb_container_click", "Container Slot Click", "Inventory", true, ServerboundContainerClickPacket.class, "Sends inventory/chest slot click packets");
      this.register("sb_container_close", "Container Close", "Inventory", true, ServerboundContainerClosePacket.class, "Sends container or GUI close notification");
      this.register("sb_set_carried", "Hotbar Carried Slot", "Inventory", true, ServerboundSetCarriedItemPacket.class, "Sends held hotbar slot changes");

      // Network & Protocol
      this.register("sb_keep_alive", "Keep Alive Response", "Network & Protocol", true, ServerboundKeepAlivePacket.class, "Responds to server keep-alive ping requests");
      this.register("sb_pong", "Pong Latency Response", "Network & Protocol", true, ServerboundPongPacket.class, "Responds to server ping latency measurements");
      this.register("sb_client_command", "Client Command (Respawn)", "Network & Protocol", true, ServerboundClientCommandPacket.class, "Sends respawn or stats request");
      this.register("sb_tick_end", "Client Tick End", "Network & Protocol", true, ServerboundClientTickEndPacket.class, "Signals end of client tick phase");

      // Chat & Commands
      this.register("sb_chat", "Public Chat Message", "Chat & Commands", true, ServerboundChatPacket.class, "Sends standard in-game chat messages");
      this.register("sb_chat_cmd", "Chat Slash Command", "Chat & Commands", true, ServerboundChatCommandPacket.class, "Sends commands to server (/command)");
      this.register("sb_chat_signed_cmd", "Signed Chat Command", "Chat & Commands", true, ServerboundChatCommandSignedPacket.class, "Sends cryptographically signed commands");
      this.register("sb_chat_ack", "Chat Acknowledgment", "Chat & Commands", true, ServerboundChatAckPacket.class, "Sends chat message signature receipt");

      // --- CLIENTBOUND (Incoming) ---
      // World & Effects
      this.register("cb_explode", "Incoming Explosion", "World & Effects", false, ClientboundExplodePacket.class, "Incoming explosion physics, blast push, and destruction");
      this.register("cb_particles", "Level Particles", "World & Effects", false, ClientboundLevelParticlesPacket.class, "Incoming particle effects spawned by server");
      this.register("cb_sound", "World Sound Effect", "World & Effects", false, ClientboundSoundPacket.class, "Incoming world sound effects");
      this.register("cb_sound_entity", "Entity Sound Effect", "World & Effects", false, ClientboundSoundEntityPacket.class, "Incoming sounds attached to entities");
      this.register("cb_block_update", "Block State Update", "World & Effects", false, ClientboundBlockUpdatePacket.class, "Incoming single block state updates");
      this.register("cb_section_blocks", "Multi-Block Section Update", "World & Effects", false, ClientboundSectionBlocksUpdatePacket.class, "Incoming chunk section block updates");

      // Entities & Combat
      this.register("cb_move_entity", "Entity Position Updates", "Entities & Combat", false, ClientboundMoveEntityPacket.class, "Incoming position updates for nearby entities");
      this.register("cb_set_motion", "Velocity / Knockback", "Entities & Combat", false, ClientboundSetEntityMotionPacket.class, "Incoming player velocity and combat knockback");
      this.register("cb_rotate_head", "Entity Head Rotation", "Entities & Combat", false, ClientboundRotateHeadPacket.class, "Incoming entity look rotations");
      this.register("cb_animate", "Entity Animation (Hurt / Swing)", "Entities & Combat", false, ClientboundAnimatePacket.class, "Incoming entity attack and hurt animations");
      this.register("cb_damage", "Damage Event", "Entities & Combat", false, ClientboundDamageEventPacket.class, "Incoming damage event notifications");

      // Network & Protocol
      this.register("cb_keep_alive", "Server Keep Alive Ping", "Network & Protocol", false, ClientboundKeepAlivePacket.class, "Incoming keep-alive check from server");
      this.register("cb_ping", "Server Ping Latency Check", "Network & Protocol", false, ClientboundPingPacket.class, "Incoming ping measurement from server");
   }

   @Override
   protected void onEnable() {
      this.on(PacketSendEvent.TYPE, this::onPacketSend);
      this.on(PacketReceiveNettyEvent.TYPE, this::onPacketReceive);
   }

   private void onPacketSend(PacketSendEvent event) {
      if (!this.isEnabled()) return;
      Packet<?> packet = event.packet;
      if (packet == null) return;

      this.totalPacketsSeen++;

      if (this.shouldCancel(packet, true)) {
         event.setCancelled(true);
         this.totalPacketsCancelled++;
         this.recordCancellation(packet, true);
         if (this.logChat.get()) {
            ModuleChat.send(this, "Dropped outgoing: " + packet.getClass().getSimpleName());
         }
      } else {
         this.recordObservation(packet, true);
      }
   }

   private void onPacketReceive(PacketReceiveNettyEvent event) {
      if (!this.isEnabled()) return;
      Packet<?> packet = event.packet;
      if (packet == null) return;

      this.totalPacketsSeen++;

      if (this.shouldCancel(packet, false)) {
         event.setCancelled(true);
         this.totalPacketsCancelled++;
         this.recordCancellation(packet, false);
         if (this.logChat.get()) {
            ModuleChat.send(this, "Dropped incoming: " + packet.getClass().getSimpleName());
         }
      } else {
         this.recordObservation(packet, false);
      }
   }

   public boolean shouldCancel(Packet<?> packet, boolean serverbound) {
      if (serverbound) {
         if (!this.cancelServerbound.get()) return false;

         // Quick Presets
         if (this.blinkMovement.get() && (packet instanceof ServerboundMovePlayerPacket || packet instanceof ServerboundMoveVehiclePacket)) {
            return true;
         }
         if (this.muteSwings.get() && packet instanceof ServerboundSwingPacket) {
            return true;
         }
         if (this.muteKeepAlive.get() && packet instanceof ServerboundKeepAlivePacket) {
            return true;
         }
         if (this.muteInteractions.get() && (packet instanceof ServerboundInteractPacket || packet instanceof ServerboundAttackPacket || packet instanceof ServerboundUseItemPacket || packet instanceof ServerboundUseItemOnPacket)) {
            return true;
         }
      } else {
         if (!this.cancelClientbound.get()) return false;

         if (this.muteExplosions.get() && packet instanceof ClientboundExplodePacket) {
            return true;
         }
         if (this.muteParticles.get() && packet instanceof ClientboundLevelParticlesPacket) {
            return true;
         }
      }

      // Check specific packet toggle in registry
      for (PacketEntry entry : this.packets) {
         if (entry.serverbound == serverbound && entry.cancelled) {
            if (entry.packetClass.isInstance(packet)) {
               return true;
            }
         }
      }

      return false;
   }

   private void recordCancellation(Packet<?> packet, boolean serverbound) {
      for (PacketEntry entry : this.packets) {
         if (entry.serverbound == serverbound && entry.packetClass.isInstance(packet)) {
            entry.cancelledCount++;
            entry.observedCount++;
            return;
         }
      }
   }

   private void recordObservation(Packet<?> packet, boolean serverbound) {
      for (PacketEntry entry : this.packets) {
         if (entry.serverbound == serverbound && entry.packetClass.isInstance(packet)) {
            entry.observedCount++;
            return;
         }
      }
   }

   public List<PacketEntry> getPackets() {
      return this.packets;
   }

   public PacketEntry getPacket(String id) {
      return this.packetById.get(id);
   }

   public long getTotalPacketsSeen() {
      return this.totalPacketsSeen;
   }

   public long getTotalPacketsCancelled() {
      return this.totalPacketsCancelled;
   }

   public int getActiveCancelledCount() {
      int count = 0;
      for (PacketEntry p : this.packets) {
         if (p.cancelled) count++;
      }
      return count;
   }

   public void setPacketCancelled(String id, boolean cancelled) {
      PacketEntry entry = this.packetById.get(id);
      if (entry != null) {
         entry.cancelled = cancelled;
         this.saveConfig();
      }
   }

   public void setAllCancelled(boolean serverbound, boolean cancelled) {
      for (PacketEntry p : this.packets) {
         if (p.serverbound == serverbound) {
            p.cancelled = cancelled;
         }
      }
      this.saveConfig();
   }

   public void invertSelection(boolean serverbound) {
      for (PacketEntry p : this.packets) {
         if (p.serverbound == serverbound) {
            p.cancelled = !p.cancelled;
         }
      }
      this.saveConfig();
   }

   public void clearCounters() {
      this.totalPacketsSeen = 0;
      this.totalPacketsCancelled = 0;
      for (PacketEntry p : this.packets) {
         p.observedCount = 0;
         p.cancelledCount = 0;
      }
   }

   private Path configFile() {
      return FabricLoader.getInstance().getConfigDir().resolve("spectre/packet_canceller.txt");
   }

   public void saveConfig() {
      try {
         Path path = this.configFile();
         Files.createDirectories(path.getParent());
         StringBuilder sb = new StringBuilder();
         for (PacketEntry p : this.packets) {
            if (p.cancelled) {
               sb.append(p.id).append("\n");
            }
         }
         Files.writeString(path, sb.toString());
      } catch (IOException ignored) {}
   }

   public void loadConfig() {
      try {
         Path path = this.configFile();
         if (!Files.exists(path)) return;
         List<String> lines = Files.readAllLines(path);
         Set<String> set = new HashSet<>(lines);
         for (PacketEntry p : this.packets) {
            p.cancelled = set.contains(p.id);
         }
      } catch (IOException ignored) {}
   }
}
