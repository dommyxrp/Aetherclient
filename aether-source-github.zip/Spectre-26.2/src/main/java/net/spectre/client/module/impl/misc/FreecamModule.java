package net.spectre.client.module.impl.misc;

import com.example.client.mixin.AccessorMovementClientInput;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.CameraType;
import net.minecraft.client.Minecraft;
import net.minecraft.client.Options;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundPlayerPositionPacket;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Input;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.EventHandler;
import net.spectre.client.event.impl.PacketAppliedEvent;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.gui.ChallengeToast;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public final class FreecamModule extends ClientModule {
   public static volatile FreecamModule active;

   private final NumberSetting speed = this.addSetting("speed", new NumberSetting("Flight Speed", 1.0F, 0.1F, 20.0F).step(0.1F));
   private final NumberSetting verticalSpeed = this.addSetting("vertical-speed", new NumberSetting("Vertical Speed", 1.0F, 0.2F, 5.0F).step(0.05F));
   private final BooleanSetting smoothing = this.addSetting("smoothing", new BooleanSetting("Smooth Movement", true));
   private final BooleanSetting sprintBoost = this.addSetting("sprint-boost", new BooleanSetting("Sprint (Ctrl) Boost", true));
   private final BooleanSetting showOwnBody = this.addSetting("show-own-body", new BooleanSetting("Show Player Body", true));
   private final BooleanSetting showHands = this.addSetting("show-hands", new BooleanSetting("Show Hands", false));
   private final BooleanSetting freezePlayer = this.addSetting("freeze-player", new BooleanSetting("Freeze Player (AntiCheat Safe)", true));
   private final BooleanSetting bodyFollowsKeys = this.addSetting("body-uses-movement-keys", new BooleanSetting("Keys Move Body", false));
   private final BooleanSetting scrollSpeed = this.addSetting("scroll-speed", new BooleanSetting("Scroll Wheel Speed", true));
   private final BooleanSetting autoDisableOnDamage = this.addSetting("disable-on-damage", new BooleanSetting("Auto Disable on Damage", true));
   private final BooleanSetting autoDisableOnTeleport = this.addSetting("disable-on-teleport", new BooleanSetting("Auto Disable on Teleport", true));

   private Vec3 pos = Vec3.ZERO;
   private Vec3 prev = Vec3.ZERO;
   private float yaw;
   private float pitch;
   private boolean flyingBefore;
   private boolean cullBefore;
   private CameraType viewBefore;
   private boolean viewPushed;
   private boolean waiting;
   private boolean live;
   private float lastHealth = -1.0F;

   public FreecamModule() {
      super("freecam", "Freecam", "Detached 6DOF spectator camera with AntiCheat safety.", ModuleCategory.MISC);
   }

   @Override
   public boolean persistEnabled() {
      return false;
   }

   @Override
   protected void onEnable() {
      Minecraft mc = Minecraft.getInstance();
      this.waiting = true;
      this.live = false;
      if (mc.player != null) {
         this.lastHealth = mc.player.getHealth();
      }
      this.on(TickEvent.TYPE, this::onTick);
   }

   @Override
   protected void onDisable() {
      Minecraft mc = Minecraft.getInstance();
      boolean wasLive = this.live;
      this.waiting = false;
      this.live = false;
      if (active == this) {
         active = null;
      }

      if (this.viewPushed) {
         mc.options.setCameraType(this.viewBefore != null ? this.viewBefore : CameraType.FIRST_PERSON);
         this.viewPushed = false;
      }

      if (wasLive) {
         mc.smartCull = this.cullBefore;
         if (mc.gameMode != null) {
            mc.gameMode.stopDestroyBlock();
         }

         if (mc.player != null) {
            mc.player.getAbilities().flying = this.flyingBefore;
         }
      }
   }

   @EventHandler
   public void onPacketApplied(PacketAppliedEvent event) {
      if (!this.live) return;
      if (this.autoDisableOnTeleport.get() && event.packet instanceof ClientboundPlayerPositionPacket) {
         ModuleChat.send(this, ModuleChat.body().warn("Freecam disabled: ").text("Player was teleported by server"));
         this.setEnabled(false);
      }
   }

   private void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      this.open(mc);
      LocalPlayer player = mc.player;
      if (this.live && player != null) {
         // Auto-disable if attacked or taking damage
         if (this.autoDisableOnDamage.get() && player.getHealth() < this.lastHealth) {
            ModuleChat.send(this, ModuleChat.body().danger("Freecam closed! ").text("You took damage!"));
            ChallengeToast.addOrUpdate(new ItemStack(Items.SHIELD), "Freecam", Component.literal("Closed: Damage taken"), true);
            this.setEnabled(false);
            return;
         }
         this.lastHealth = player.getHealth();

         this.prev = this.pos;
         if (player.getAbilities().instabuild) {
            player.getAbilities().flying = false;
         }

         this.stepCamera(mc.options);
      }
   }

   private void open(Minecraft mc) {
      LocalPlayer player = mc.player;
      if (this.waiting && player != null && mc.level != null) {
         this.flyingBefore = player.getAbilities().flying;
         this.pos = this.prev = new Vec3(player.getX(), player.getY() + player.getEyeHeight(Pose.STANDING), player.getZ());
         this.yaw = player.getYRot();
         this.pitch = player.getXRot();
         this.viewPushed = false;

         if (this.showOwnBody.get()) {
            this.viewBefore = mc.options.getCameraType();
            if (this.viewBefore.isFirstPerson()) {
               mc.options.setCameraType(CameraType.THIRD_PERSON_BACK);
               this.viewPushed = true;
            }
         }

         this.waiting = false;
         this.live = true;
         active = this;
         this.cullBefore = mc.smartCull;
         mc.smartCull = false;

         drive(mc);
      }
   }

   private void stepCamera(Options options) {
      double ahead = (options.keyUp.isDown() ? 1 : 0) - (options.keyDown.isDown() ? 1 : 0);
      double side = (options.keyLeft.isDown() ? 1 : 0) - (options.keyRight.isDown() ? 1 : 0);
      double rise = (options.keyJump.isDown() ? 1 : 0) - (options.keyShift.isDown() ? 1 : 0);

      double sprintMult = (this.sprintBoost.get() && options.keySprint.isDown()) ? 2.2 : 1.0;
      double step = this.speed.get() * sprintMult * (this.smoothing.get() ? 0.45 : 0.85);

      Vec3 look = Vec3.directionFromRotation(0.0F, this.yaw);
      Vec3 left = new Vec3(look.z, 0.0, -look.x);

      this.pos = this.pos.add(
         (look.x * ahead + left.x * side) * step,
         rise * step * this.verticalSpeed.get(),
         (look.z * ahead + left.z * side) * step
      );
   }

   public static void drive(Minecraft mc) {
      FreecamModule module = active;
      if (module != null && mc.player != null) {
         module.pushWalk(mc);
      }
   }

   private void pushWalk(Minecraft mc) {
      LocalPlayer player = mc.player;
      if (player == null) return;

      if (this.bodyFollowsKeys.get()) {
         Options options = mc.options;
         boolean forward = options.keyUp.isDown();
         boolean back = options.keyDown.isDown();
         boolean left = options.keyLeft.isDown();
         boolean right = options.keyRight.isDown();
         boolean jump = options.keyJump.isDown();
         boolean sneak = options.keyShift.isDown();
         boolean sprint = options.keySprint.isDown();

         player.input.keyPresses = new Input(forward, back, left, right, jump, sneak, sprint);
         float sideways = (left ? 1.0F : 0.0F) - (right ? 1.0F : 0.0F);
         float ahead = (forward ? 1.0F : 0.0F) - (back ? 1.0F : 0.0F);
         ((AccessorMovementClientInput)player.input).spectre$setMoveVector(new Vec2(sideways, ahead).normalized());
         player.setShiftKeyDown(sneak);
      } else {
         // Freeze real player body so GrimAC and other anticheats never detect anomalous motion
         player.input.keyPresses = new Input(false, false, false, false, false, false, false);
         ((AccessorMovementClientInput)player.input).spectre$setMoveVector(Vec2.ZERO);
         player.setShiftKeyDown(false);

         if (this.freezePlayer.get()) {
            Vec3 vel = player.getDeltaMovement();
            player.setDeltaMovement(0.0, vel.y > 0 ? 0.0 : vel.y, 0.0);
         }
      }
   }

   public boolean drawsSelf(Entity entity, Player viewer) {
      Minecraft mc = Minecraft.getInstance();
      return this.showOwnBody.get() && mc.player != null && entity == mc.player && viewer == mc.player;
   }

   public boolean keepHands() {
      return this.showHands.get();
   }

   public boolean showBody() {
      return this.showOwnBody.get();
   }

   public static boolean scroll(double amount) {
      FreecamModule module = active;
      if (module != null && module.scrollSpeed.get() && amount != 0.0) {
         float current = module.speed.get();
         float factor = amount > 0.0 ? 1.25F : 0.8F;
         module.speed.set(Mth.clamp(current * factor, 0.1F, 20.0F));
         return true;
      } else {
         return false;
      }
   }

   public void turn(double yRot, double xRot) {
      this.yaw += (float)yRot * 0.15F;
      this.pitch = Mth.clamp(this.pitch + (float)xRot * 0.15F, -90.0F, 90.0F);
   }

   public double getX(float tickDelta) {
      return Mth.lerp((double)tickDelta, this.prev.x, this.pos.x);
   }

   public double getY(float tickDelta) {
      return Mth.lerp((double)tickDelta, this.prev.y, this.pos.y);
   }

   public double getZ(float tickDelta) {
      return Mth.lerp((double)tickDelta, this.prev.z, this.pos.z);
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPitch() {
      return this.pitch;
   }
}
