package net.spectre.client.module.impl.combat;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.protocol.game.ServerboundMovePlayerPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket;
import net.minecraft.network.protocol.game.ServerboundPlayerCommandPacket.Action;
import net.minecraft.tags.ItemTags;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.Vec3;
import net.spectre.client.event.EventHandler;
import net.spectre.client.event.impl.PreAttackEntityEvent;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.ModeSetting;
import net.spectre.client.module.setting.NumberSetting;

@Environment(EnvType.CLIENT)
public final class CriticalsModule extends ClientModule {
   private final ModeSetting mode = this.addSetting("mode", new ModeSetting("Mode", "Smart Fall", "Smart Fall", "Packet", "Jump"));
   private final BooleanSetting sprintReset = this.addSetting("sprint-reset", new BooleanSetting("Sprint Reset for Crits", true));
   private final BooleanSetting weaponsOnly = this.addSetting("weapons-only", new BooleanSetting("Weapons Only", true));
   private final NumberSetting packetOffset = this.addSetting("packet-offset", new NumberSetting("Packet Offset", 0.0625F, 0.01F, 0.12F).step(0.005F));

   public CriticalsModule() {
      super("criticals", "Criticals", "Forces sword and melee hits to land as critical strikes for 150% damage.", ModuleCategory.COMBAT);
      this.packetOffset.visibleWhen(() -> this.mode.is("Packet"));
   }

   @EventHandler
   public void onPreAttack(PreAttackEntityEvent event) {
      Minecraft mc = Minecraft.getInstance();
      LocalPlayer player = mc.player;
      if (player == null || mc.level == null) return;

      if (this.weaponsOnly.get() && !this.isHoldingWeapon(player)) {
         return;
      }

      Entity target = event.target;
      if (!(target instanceof LivingEntity)) return;

      if (player.isInWater() || player.onClimbable() || player.getAbilities().flying || player.isFallFlying() || player.isPassenger()) {
         return;
      }

      String m = this.mode.get();
      if ("Packet".equals(m)) {
         if (player.onGround()) {
            ClientPacketListener conn = mc.getConnection();
            if (conn != null) {
               Vec3 p = player.position();
               double offset = this.packetOffset.get();
               // Send ascending then descending positions before the attack packet
               conn.send(new ServerboundMovePlayerPacket.Pos(p.x, p.y + offset, p.z, false, false));
               conn.send(new ServerboundMovePlayerPacket.Pos(p.x, p.y + 0.00001, p.z, false, false));
            }
         }
      } else if ("Jump".equals(m)) {
         if (player.onGround()) {
            player.jumpFromGround();
            event.setCancelled(true);
            return;
         }
      } else if ("Smart Fall".equals(m)) {
         // If player is in the air and still ascending (not falling), delay attack
         if (!player.onGround() && player.getDeltaMovement().y > 0.0) {
            event.setCancelled(true);
            return;
         }
      }

      // Crit Sprint Reset: Sprinting converts hits into knockback strikes and blocks criticals
      if (this.sprintReset.get() && player.isSprinting()) {
         ClientPacketListener conn = mc.getConnection();
         if (conn != null) {
            conn.send(new ServerboundPlayerCommandPacket(player, Action.STOP_SPRINTING));
         }
         player.setSprinting(false);
      }
   }

   private boolean isHoldingWeapon(LocalPlayer player) {
      ItemStack main = player.getMainHandItem();
      if (main.isEmpty()) return false;
      return main.is(ItemTags.SWORDS) || main.is(ItemTags.AXES) || main.is(Items.MACE);
   }
}
