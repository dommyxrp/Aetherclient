package net.spectre.client.gui;

import imgui.ImColor;
import imgui.ImDrawList;
import imgui.ImGui;
import imgui.flag.ImGuiCol;
import imgui.flag.ImGuiStyleVar;
import imgui.flag.ImGuiWindowFlags;
import imgui.type.ImBoolean;
import imgui.type.ImString;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.spectre.client.imgui.ImGuiManager;
import net.spectre.client.module.impl.misc.PacketCancellerModule;
import net.spectre.client.module.impl.misc.PacketCancellerModule.PacketEntry;

/**
 * Dedicated Sub-Menu for the Packet Canceller module.
 * Provides fine-grained selection of outgoing and incoming packets,
 * group toggles, search filtering, quick presets, and live traffic analytics.
 */
public final class PacketCancellerPanel {

   private static boolean open = false;
   private static int activeTab = 0; // 0 = Serverbound, 1 = Clientbound, 2 = Live Monitor
   private static final ImString searchFilter = new ImString(64);

   private static int studioColor(int rgb, float alpha) {
      int a = (int)(Math.max(0, Math.min(1, alpha)) * 255);
      return GuiPalette.abgr((a << 24) | (rgb & 0xFFFFFF));
   }

   public static void open() {
      open = true;
   }

   public static void close() {
      open = false;
   }

   public static void toggle() {
      open = !open;
   }

   public static boolean isOpen() {
      return open;
   }

   public static void renderModal() {
      if (!open) return;

      PacketCancellerModule mod = PacketCancellerModule.INSTANCE;
      if (mod == null) return;

      float sw = ImGui.getIO().getDisplaySizeX();
      float sh = ImGui.getIO().getDisplaySizeY();

      float w = Math.min(880, sw - 48);
      float h = Math.min(640, sh - 48);
      float x = (sw - w) / 2.0F;
      float y = (sh - h) / 2.0F;

      // Dark backdrop dim
      ImDrawList bgList = ImGui.getBackgroundDrawList();
      bgList.addRectFilled(0, 0, sw, sh, studioColor(0x000000, 0.65F));

      ImGui.setNextWindowPos(x, y, 1);
      ImGui.setNextWindowSize(w, h, 1);
      ImGui.pushStyleVar(ImGuiStyleVar.WindowPadding, 0F, 0F);
      ImGui.pushStyleVar(ImGuiStyleVar.WindowRounding, 8.0F);
      ImGui.pushStyleColor(ImGuiCol.WindowBg, studioColor(0x070B12, 0.98F));
      ImGui.pushStyleColor(ImGuiCol.Border, studioColor(0x1B2C42, 1.0F));

      int winFlags = ImGuiWindowFlags.NoTitleBar | ImGuiWindowFlags.NoResize | ImGuiWindowFlags.NoCollapse;
      if (ImGui.begin("##packet_canceller_dialog", winFlags)) {
         ImDrawList dl = ImGui.getWindowDrawList();
         float wx = ImGui.getWindowPosX(), wy = ImGui.getWindowPosY();

         // Card outer border & technical cyan header line
         dl.addRect(wx, wy, wx + w, wy + h, studioColor(0x22384C, 1.0F), 8, 0, 1.5F);
         dl.addLine(wx + 20, wy, wx + 180, wy, studioColor(0x72E6EF, 0.85F), 2.5F);

         // --- TOP HEADER ---
         dl.addRectFilled(wx, wy, wx + w, wy + 64, studioColor(0x0B121E, 1.0F), 8);
         dl.addLine(wx, wy + 64, wx + w, wy + 64, studioColor(0x182438, 1.0F), 1.0F);

         SpectreWidgets.text(dl, ImGuiManager.getInstance().titleFont(), wx + 20, wy + 16, 0xFFF8FAFC, "PACKET CANCELLER");
         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), wx + 242, wy + 23, 0xFF64748B, "// NETWORK FILTER SUB-MENU");

         // Master module toggle pill
         float pillW = 140, pillH = 32;
         float pillX = wx + w - pillW - 64, pillY = wy + 16;
         ImGui.setCursorPos(w - pillW - 64, 16);
         boolean enabled = mod.isEnabled();
         if (ImGui.button(enabled ? "MODULE: ACTIVE ##mod_tog" : "MODULE: OFF ##mod_tog", pillW, pillH)) {
            mod.toggle();
         }

         // Close 'X' button
         ImGui.setCursorPos(w - 48, 16);
         if (ImGui.button("X ##close_canceller_dialog", 32, 32)) {
            close();
         }

         // --- METRICS & PRESETS BAR ---
         float metricY = 72;
         dl.addRectFilled(wx + 16, wy + metricY, wx + w - 16, wy + metricY + 44, studioColor(0x0D1624, 0.8F), 6);
         dl.addRect(wx + 16, wy + metricY, wx + w - 16, wy + metricY + 44, studioColor(0x1B2A3D, 0.8F), 6);

         int activeCount = mod.getActiveCancelledCount();
         long dropped = mod.getTotalPacketsCancelled();
         long seen = mod.getTotalPacketsSeen();
         double dropRate = seen > 0 ? (dropped * 100.0 / seen) : 0.0;

         String statStr = String.format(Locale.ROOT, "Active Filters: %d | Total Intercepted: %d | Dropped: %d (%.1f%%)",
            activeCount, seen, dropped, dropRate);
         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudTextFont(), wx + 30, wy + metricY + 12, 0xFF72E6EF, statStr);

         // --- TABS BAR ---
         float tabY = 124;
         ImGui.setCursorPos(20, tabY);

         boolean isSb = activeTab == 0;
         boolean isCb = activeTab == 1;
         boolean isMon = activeTab == 2;

         if (ImGui.button(isSb ? "[ Serverbound (Outgoing) ]" : "Serverbound (Outgoing)", 200, 32)) activeTab = 0;
         ImGui.sameLine();
         if (ImGui.button(isCb ? "[ Clientbound (Incoming) ]" : "Clientbound (Incoming)", 200, 32)) activeTab = 1;
         ImGui.sameLine();
         if (ImGui.button(isMon ? "[ Live Monitor & Stats ]" : "Live Monitor & Stats", 180, 32)) activeTab = 2;

         // Quick presets
         ImGui.sameLine();
         if (ImGui.button("Select All ##sel_all", 90, 32)) {
            if (activeTab == 0) mod.setAllCancelled(true, true);
            else if (activeTab == 1) mod.setAllCancelled(false, true);
         }
         ImGui.sameLine();
         if (ImGui.button("Clear ##clr_all", 65, 32)) {
            if (activeTab == 0) mod.setAllCancelled(true, false);
            else if (activeTab == 1) mod.setAllCancelled(false, false);
         }
         ImGui.sameLine();
         if (ImGui.button("Invert ##inv_all", 65, 32)) {
            if (activeTab == 0) mod.invertSelection(true);
            else if (activeTab == 1) mod.invertSelection(false);
         }

         // Search bar & Preset Buttons row
         float searchY = 164;
         ImGui.setCursorPos(20, searchY);
         ImGui.pushItemWidth(260);
         ImGui.inputTextWithHint("##packet_search", "Search packet name or id...", searchFilter);
         ImGui.popItemWidth();

         ImGui.sameLine();
         if (ImGui.button("Blink (Freeze Move) ##p_blink", 150, 26)) {
            mod.setPacketCancelled("sb_move_pos", true);
            mod.setPacketCancelled("sb_move_pos_rot", true);
            mod.setPacketCancelled("sb_move_rot", true);
            mod.setPacketCancelled("sb_move_status", true);
            mod.setPacketCancelled("sb_move_vehicle", true);
         }
         ImGui.sameLine();
         if (ImGui.button("Mute Swings ##p_swings", 110, 26)) {
            mod.setPacketCancelled("sb_swing", true);
         }
         ImGui.sameLine();
         if (ImGui.button("Mute KeepAlive ##p_keep", 130, 26)) {
            mod.setPacketCancelled("sb_keep_alive", true);
            mod.setPacketCancelled("sb_pong", true);
         }
         ImGui.sameLine();
         if (ImGui.button("Reset Counters ##rst_cnt", 120, 26)) {
            mod.clearCounters();
         }

         // --- MAIN CONTENT AREA ---
         float contentY = 198;
         float contentH = h - contentY - 48;
         ImGui.setCursorPos(20, contentY);

         if (ImGui.beginChild("##packet_canceller_scroll", w - 40, contentH, true, ImGuiWindowFlags.None)) {
            if (activeTab == 0 || activeTab == 1) {
               renderPacketList(mod, activeTab == 0);
            } else {
               renderLiveMonitor(mod);
            }
         }
         ImGui.endChild();

         // --- BOTTOM BAR ---
         float footerY = h - 38;
         dl.addLine(wx, wy + footerY, wx + w, wy + footerY, studioColor(0x182438, 1.0F), 1.0F);

         String filterQuery = searchFilter.get().trim();
         String footerText = filterQuery.isEmpty()
            ? "Tip: Ticked packets will be blocked immediately when Packet Canceller is enabled."
            : "Filter active: '" + filterQuery + "' (Press ESC or X to close sub-menu)";
         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), wx + 24, wy + footerY + 10, 0xFF64748B, footerText);

         ImGui.setCursorPos(w - 110, footerY + 6);
         if (ImGui.button("Done ##done_btn", 90, 26)) {
            close();
         }
      }
      ImGui.end();

      ImGui.popStyleColor(2);
      ImGui.popStyleVar(2);
   }

   private static void renderPacketList(PacketCancellerModule mod, boolean serverbound) {
      String query = searchFilter.get().toLowerCase(Locale.ROOT).trim();
      List<PacketEntry> list = mod.getPackets();

      // Group packets by category
      Map<String, List<PacketEntry>> categories = new LinkedHashMap<>();
      for (PacketEntry entry : list) {
         if (entry.serverbound != serverbound) continue;
         if (!query.isEmpty()) {
            boolean match = entry.name.toLowerCase(Locale.ROOT).contains(query)
               || entry.id.toLowerCase(Locale.ROOT).contains(query)
               || entry.category.toLowerCase(Locale.ROOT).contains(query)
               || entry.packetClass.getSimpleName().toLowerCase(Locale.ROOT).contains(query);
            if (!match) continue;
         }
         categories.computeIfAbsent(entry.category, k -> new ArrayList<>()).add(entry);
      }

      if (categories.isEmpty()) {
         ImGui.setCursorPosY(ImGui.getCursorPosY() + 20);
         ImGui.textColored(ImColor.rgba(148, 163, 184, 255), "No packets matched your search filter.");
         return;
      }

      for (Map.Entry<String, List<PacketEntry>> cat : categories.entrySet()) {
         String catName = cat.getKey();
         List<PacketEntry> catPackets = cat.getValue();

         // Category banner
         ImGui.pushStyleColor(ImGuiCol.Button, studioColor(0x111C2C, 0.9F)); // Button bg
         ImGui.pushStyleColor(ImGuiCol.ButtonHovered, studioColor(0x16253B, 1.0F)); // Hover
         float availW = ImGui.getContentRegionAvailX();
         float btnW = Math.max(80, availW - 120);
         ImGui.button("  " + catName.toUpperCase(Locale.ROOT) + " (" + catPackets.size() + ") ##cat_hdr_" + catName, btnW, 26);
         ImGui.popStyleColor(2);

         ImGui.sameLine();
         if (ImGui.button("Toggle All ##tog_" + catName, 110, 26)) {
            boolean allOn = true;
            for (PacketEntry p : catPackets) {
               if (!p.cancelled) { allOn = false; break; }
            }
            for (PacketEntry p : catPackets) {
               mod.setPacketCancelled(p.id, !allOn);
            }
         }

         ImGui.dummy(0, 4);

         // Packet entries
         for (PacketEntry entry : catPackets) {
            ImGui.pushID(entry.id);

            float curY = ImGui.getCursorPosY();
            float rx = ImGui.getWindowPosX() + ImGui.getCursorPosX();
            float ry = ImGui.getWindowPosY() + curY - ImGui.getScrollY();
            float rw = ImGui.getContentRegionAvailX();

            ImDrawList dl = ImGui.getWindowDrawList();
            int cardBg = entry.cancelled ? 0x1A141A : 0x0A121E;
            int cardBorder = entry.cancelled ? 0xEF4444 : 0x1B2C42;

            dl.addRectFilled(rx, ry, rx + rw, ry + 44, studioColor(cardBg, 0.9F), 6);
            dl.addRect(rx, ry, rx + rw, ry + 44, studioColor(cardBorder, entry.cancelled ? 0.7F : 0.4F), 6);

            ImGui.setCursorPos(12, curY + 11);
            if (ImGui.checkbox("##chk_" + entry.id, entry.cancelled)) {
               mod.setPacketCancelled(entry.id, !entry.cancelled);
            }

            ImGui.sameLine();
            ImGui.setCursorPos(44, curY + 6);
            SpectreWidgets.text(dl, ImGuiManager.getInstance().hudTextFont(), rx + 44, ry + 5,
               entry.cancelled ? 0xFFFCA5A5 : 0xFFF8FAFC, entry.name);

            SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + 44, ry + 24,
               0xFF64748B, entry.description + " [" + entry.packetClass.getSimpleName() + "]");

            // Stats pill on the right
            String stats = String.format(Locale.ROOT, "Dropped: %d | Seen: %d", entry.cancelledCount, entry.observedCount);
            int statCol = entry.cancelledCount > 0 ? 0xFFF87171 : 0xFF64748B;
            SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + rw - 170, ry + 13, statCol, stats);

            ImGui.setCursorPosY(curY + 48);
            ImGui.popID();
         }

         ImGui.dummy(0, 8);
      }
   }

   private static void renderLiveMonitor(PacketCancellerModule mod) {
      List<PacketEntry> list = mod.getPackets();

      ImGui.textColored(ImColor.rgba(114, 230, 239, 255), "REAL-TIME PACKET TRAFFIC MONITOR");
      ImGui.textColored(ImColor.rgba(148, 163, 184, 255), "Inspect packets intercepted, dropped, or forwarded during this session.");
      ImGui.dummy(0, 6);

      float rw = ImGui.getContentRegionAvailX();
      float curY = ImGui.getCursorPosY();
      float rx = ImGui.getWindowPosX() + ImGui.getCursorPosX();
      float ry = ImGui.getWindowPosY() + curY - ImGui.getScrollY();

      // Table header
      ImDrawList dl = ImGui.getWindowDrawList();
      dl.addRectFilled(rx, ry, rx + rw, ry + 28, studioColor(0x111C2C, 1.0F), 4);
      SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + 12, ry + 7, 0xFF94A3B8, "PACKET IDENTIFIER");
      SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + 300, ry + 7, 0xFF94A3B8, "DIRECTION");
      SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + 430, ry + 7, 0xFF94A3B8, "STATUS");
      SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + 560, ry + 7, 0xFF94A3B8, "TOTAL OBSERVED");
      SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rx + 700, ry + 7, 0xFF94A3B8, "TOTAL CANCELLED");

      ImGui.setCursorPosY(curY + 34);

      for (PacketEntry entry : list) {
         if (entry.observedCount == 0 && entry.cancelledCount == 0 && !entry.cancelled) continue;

         float rowY = ImGui.getCursorPosY();
         float rrx = ImGui.getWindowPosX() + ImGui.getCursorPosX();
         float rry = ImGui.getWindowPosY() + rowY - ImGui.getScrollY();

         int rowBg = entry.cancelled ? 0x181016 : 0x0A121E;
         dl.addRectFilled(rrx, rry, rrx + rw, rry + 26, studioColor(rowBg, 0.7F), 4);

         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rrx + 12, rry + 6,
            entry.cancelled ? 0xFFFCA5A5 : 0xFFF8FAFC, entry.name + " (" + entry.packetClass.getSimpleName() + ")");

         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rrx + 300, rry + 6,
            entry.serverbound ? 0xFF38BDF8 : 0xFFA78BFA, entry.serverbound ? "Outgoing" : "Incoming");

         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rrx + 430, rry + 6,
            entry.cancelled ? 0xFFEF4444 : 0xFF22C55E, entry.cancelled ? "[ DROPPED ]" : "[ PASSING ]");

         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rrx + 560, rry + 6,
            0xFFF8FAFC, String.valueOf(entry.observedCount));

         SpectreWidgets.text(dl, ImGuiManager.getInstance().hudLabelFont(), rrx + 700, rry + 6,
            entry.cancelledCount > 0 ? 0xFFEF4444 : 0xFF64748B, String.valueOf(entry.cancelledCount));

         ImGui.setCursorPosY(rowY + 28);
      }
   }
}
