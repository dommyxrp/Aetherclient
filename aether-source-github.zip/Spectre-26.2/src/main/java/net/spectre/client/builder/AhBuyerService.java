package net.spectre.client.builder;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.multiplayer.MultiPlayerGameMode;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.inventory.ContainerInput;
import net.minecraft.world.inventory.ShulkerBoxMenu;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemLore;

/**
 * Automates purchasing schematic materials from /ah and organizing them into
 * the exact shulker box slots required by SupplyDepotPlan.
 */
public final class AhBuyerService {
    public static final AhBuyerService INSTANCE = new AhBuyerService();

    public enum State {
        IDLE,
        COOLDOWN,
        SENDING_COMMAND,
        WAITING_FOR_AH_CONTAINER,
        ANALYZING_LISTINGS,
        CONFIRMING_PURCHASE,
        WAITING_FOR_SHULKER,
        PACKING_SHULKER,
        PAUSED,
        FINISHED,
        ERROR
    }

    private State state = State.IDLE;
    private String statusMessage = "Idle. Ready to source materials.";
    private MaterialPlan activePlan;
    private SupplyDepotPlan activeDepot;

    // Configuration
    private int actionDelayTicks = 12; // ~600ms between actions for anti-cheat safety
    private boolean autoConfirm = true;
    private boolean autoPackShulkers = true;
    private double maxPricePerItem = 0.0; // 0 = unlimited
    private boolean useUnderscores = false;

    // Runtime state
    private int tickTimer = 0;
    private int timeoutTimer = 0;
    private int currentItemIndex = 0;
    private int activeBoxIndex = 0;
    private int prePurchaseCount = 0;
    private int lastBoughtDelta = 0;
    private String currentTargetItem = null;
    private long currentTargetNeeded = 0;
    private final Map<String, Long> purchasedCounts = new HashMap<>();
    private final Set<Integer> completedBoxes = new HashSet<>();
    private final Set<Integer> failedSlotsThisPage = new HashSet<>();
    private int lastClickedSlot = -1;

    private static final Pattern PRICE_PATTERN = Pattern.compile("(?i)(?:\\$|price:?|cost:?|coins:?)?\\s*([0-9]+(?:,[0-9]{3})*(?:\\.[0-9]+)?)\\s*([kmb])?");

    private AhBuyerService() {}

    public State getState() { return state; }
    public boolean running() { return state != State.IDLE && state != State.FINISHED && state != State.ERROR; }
    public boolean paused() { return state == State.PAUSED; }
    public String status() { return statusMessage; }

    public int getActionDelayTicks() { return actionDelayTicks; }
    public void setActionDelayTicks(int ticks) { this.actionDelayTicks = Math.max(4, Math.min(60, ticks)); }

    public boolean isAutoConfirm() { return autoConfirm; }
    public void setAutoConfirm(boolean autoConfirm) { this.autoConfirm = autoConfirm; }

    public boolean isAutoPackShulkers() { return autoPackShulkers; }
    public void setAutoPackShulkers(boolean autoPack) { this.autoPackShulkers = autoPack; }

    public double getMaxPricePerItem() { return maxPricePerItem; }
    public void setMaxPricePerItem(double maxPrice) { this.maxPricePerItem = Math.max(0.0, maxPrice); }

    public boolean isUseUnderscores() { return useUnderscores; }
    public void setUseUnderscores(boolean useUnderscores) { this.useUnderscores = useUnderscores; }

    public int getActiveBoxIndex() { return activeBoxIndex; }
    public int getTotalBoxes() { return activeDepot != null ? activeDepot.boxes() : 0; }
    public String getCurrentTargetItem() { return currentTargetItem; }
    public long getCurrentTargetNeeded() { return currentTargetNeeded; }

    public void start(MaterialPlan plan) {
        if (plan == null || plan.rows().isEmpty()) {
            statusMessage = "Cannot start: no schematic materials planned.";
            return;
        }
        var mc = Minecraft.getInstance();
        if (mc.player == null || mc.getConnection() == null) {
            statusMessage = "Cannot start: not connected to a world.";
            return;
        }

        this.activePlan = plan;
        this.activeDepot = SupplyDepotPlan.pack(plan);
        this.currentItemIndex = 0;
        this.activeBoxIndex = 0;
        this.purchasedCounts.clear();
        this.completedBoxes.clear();
        this.tickTimer = 5;
        this.timeoutTimer = 0;
        this.state = State.COOLDOWN;
        this.statusMessage = "Starting /ah sourcing for " + plan.rows().size() + " materials...";
        logChat("§b[AH Buyer] Started sourcing for " + plan.rows().size() + " materials (" + activeDepot.boxes() + " shulkers planned).§r");
    }

    public void pause() {
        if (state == State.PAUSED) {
            state = State.COOLDOWN;
            tickTimer = 5;
            statusMessage = "Resumed /ah sourcing.";
            logChat("§b[AH Buyer] Resumed.§r");
        } else if (running()) {
            state = State.PAUSED;
            statusMessage = "Paused /ah sourcing.";
            logChat("§e[AH Buyer] Paused.§r");
        }
    }

    public void stop() {
        this.state = State.IDLE;
        this.statusMessage = "Stopped /ah sourcing.";
        var mc = Minecraft.getInstance();
        if (mc.player != null && mc.player.containerMenu != null && mc.player.containerMenu != mc.player.inventoryMenu) {
            mc.player.closeContainer();
        }
        logChat("§c[AH Buyer] Stopped.§r");
    }

    public void tick(Minecraft client) {
        if (!running() || state == State.PAUSED) return;

        LocalPlayer player = client.player;
        MultiPlayerGameMode gameMode = client.gameMode;
        if (player == null || gameMode == null || client.getConnection() == null) {
            stop();
            return;
        }

        // Check if shulker box is opened and auto-pack is active
        if (autoPackShulkers && player.containerMenu instanceof ShulkerBoxMenu shulkerMenu) {
            if (state != State.PACKING_SHULKER) {
                state = State.PACKING_SHULKER;
                tickTimer = 3;
            }
        }

        if (tickTimer > 0) {
            tickTimer--;
            return;
        }

        switch (state) {
            case COOLDOWN -> handleCooldown(client, player);
            case SENDING_COMMAND -> handleSendCommand(client, player);
            case WAITING_FOR_AH_CONTAINER -> handleWaitingForAh(client, player);
            case ANALYZING_LISTINGS -> handleAnalyzingListings(client, player, gameMode);
            case CONFIRMING_PURCHASE -> handleConfirmingPurchase(client, player, gameMode);
            case WAITING_FOR_SHULKER -> handleWaitingForShulker(client, player);
            case PACKING_SHULKER -> handlePackingShulker(client, player, gameMode);
            default -> {}
        }
    }

    private void handleCooldown(Minecraft client, LocalPlayer player) {
        // Find next item that still needs to be purchased
        if (activePlan == null || currentItemIndex >= activePlan.rows().size()) {
            // All rows checked! Check if shulkers still need packing
            if (activeBoxIndex < (activeDepot != null ? activeDepot.boxes() : 0)) {
                state = State.WAITING_FOR_SHULKER;
                statusMessage = "Materials purchased. Open Shulker Box #" + (activeBoxIndex + 1) + " to pack.";
                logChat("§a[AH Buyer] Sourcing complete! Open Shulker Box #" + (activeBoxIndex + 1) + " to pack items.§r");
            } else {
                state = State.FINISHED;
                statusMessage = "All schematic materials purchased and organized!";
                logChat("§a[AH Buyer] All schematic materials purchased and packed successfully!§r");
            }
            return;
        }

        var row = activePlan.rows().get(currentItemIndex);
        currentTargetItem = row.item();
        long totalNeeded = row.required();
        long alreadyPurchased = purchasedCounts.getOrDefault(currentTargetItem, 0L);
        long inInventory = countInInventory(player, currentTargetItem);
        long currentHeld = Math.max(alreadyPurchased, inInventory);

        if (currentHeld >= totalNeeded) {
            // Already have enough of this item, advance to next
            currentItemIndex++;
            tickTimer = 2;
            return;
        }

        currentTargetNeeded = totalNeeded - currentHeld;

        // Check if player inventory is completely full
        if (freeInventorySlots(player) <= 0) {
            state = State.WAITING_FOR_SHULKER;
            statusMessage = "Inventory full. Open Shulker Box #" + (activeBoxIndex + 1) + " to pack items.";
            logChat("§e[AH Buyer] Inventory full! Open Shulker Box #" + (activeBoxIndex + 1) + " to pack items.§r");
            return;
        }

        state = State.SENDING_COMMAND;
        tickTimer = 2;
    }

    private void handleSendCommand(Minecraft client, LocalPlayer player) {
        String cleanName = currentTargetItem.replace("minecraft:", "");
        if (!useUnderscores) {
            cleanName = cleanName.replace('_', ' ');
        }

        statusMessage = "Searching /ah for: " + cleanName + " (" + currentTargetNeeded + " needed)";
        logChat("§7[AH Buyer] Querying /ah " + cleanName + "...§r");

        failedSlotsThisPage.clear();
        lastClickedSlot = -1;
        client.getConnection().sendCommand("ah " + cleanName);
        state = State.WAITING_FOR_AH_CONTAINER;
        timeoutTimer = 0;
        tickTimer = actionDelayTicks;
    }

    private void handleWaitingForAh(Minecraft client, LocalPlayer player) {
        timeoutTimer++;
        if (player.containerMenu instanceof ChestMenu) {
            state = State.ANALYZING_LISTINGS;
            timeoutTimer = 0;
            tickTimer = 4; // Give items 4 ticks to load completely
            return;
        }

        if (timeoutTimer > 50) { // ~2.5 seconds timeout
            logChat("§c[AH Buyer] /ah menu did not open (timed out). Retrying...§r");
            state = State.COOLDOWN;
            tickTimer = 20;
        }
    }

    private void handleAnalyzingListings(Minecraft client, LocalPlayer player, MultiPlayerGameMode gameMode) {
        if (!(player.containerMenu instanceof ChestMenu menu)) {
            state = State.COOLDOWN;
            tickTimer = actionDelayTicks;
            return;
        }

        int containerSize = menu.getRowCount() * 9;
        // Typically row 1 to 5 (up to containerSize - 9)
        int listingSlots = Math.max(0, containerSize - 9);

        int bestSlot = -1;
        double lowestUnitPrice = Double.MAX_VALUE;
        int bestStackCount = 0;

        for (int i = 0; i < listingSlots; i++) {
            if (failedSlotsThisPage.contains(i)) continue;
            ItemStack stack = menu.getSlot(i).getItem();
            if (stack.isEmpty()) continue;

            String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
            if (id.equalsIgnoreCase(currentTargetItem)) {
                double price = parsePrice(stack);
                int count = stack.getCount();
                double unitPrice = count > 0 ? price / count : price;

                if (maxPricePerItem > 0 && unitPrice > maxPricePerItem) {
                    continue; // Exceeds user price cap
                }

                if (unitPrice < lowestUnitPrice) {
                    lowestUnitPrice = unitPrice;
                    bestSlot = i;
                    bestStackCount = count;
                }
            }
        }

        if (bestSlot != -1) {
            // Found a valid listing! Click to buy
            prePurchaseCount = countInInventory(player, currentTargetItem);
            lastBoughtDelta = bestStackCount;
            statusMessage = "Buying slot #" + bestSlot + " (" + bestStackCount + "x for $" + String.format("%.1f", lowestUnitPrice * bestStackCount) + ")...";
            logChat("§b[AH Buyer] Purchasing " + bestStackCount + "x " + formatItemName(currentTargetItem) + " from slot " + bestSlot + " ($" + String.format("%.0f", lowestUnitPrice * bestStackCount) + ")...§r");

            lastClickedSlot = bestSlot;
            gameMode.handleContainerInput(menu.containerId, bestSlot, 0, ContainerInput.PICKUP, player);
            state = State.CONFIRMING_PURCHASE;
            timeoutTimer = 0;
            tickTimer = 6;
            return;
        }

        // Not found on this page, look for Next Page button
        int nextSlot = findNextPageSlot(menu, containerSize);
        if (nextSlot != -1) {
            failedSlotsThisPage.clear();
            lastClickedSlot = -1;
            statusMessage = "Navigating to next /ah page...";
            gameMode.handleContainerInput(menu.containerId, nextSlot, 0, ContainerInput.PICKUP, player);
            state = State.WAITING_FOR_AH_CONTAINER;
            tickTimer = actionDelayTicks;
            return;
        }

        // No listing available
        logChat("§e[AH Buyer] No matching listings found for " + formatItemName(currentTargetItem) + ". Skipping to next item.§r");
        statusMessage = "No listings for " + formatItemName(currentTargetItem) + ". Skipping.";
        player.closeContainer();
        currentItemIndex++;
        state = State.COOLDOWN;
        tickTimer = actionDelayTicks;
    }

    private void handleConfirmingPurchase(Minecraft client, LocalPlayer player, MultiPlayerGameMode gameMode) {
        timeoutTimer++;

        // 1. Check if a confirmation dialog is active
        if (autoConfirm && player.containerMenu != null && player.containerMenu != player.inventoryMenu) {
            int confirmSlot = findConfirmSlot(player.containerMenu);
            if (confirmSlot != -1) {
                statusMessage = "Confirming purchase...";
                gameMode.handleContainerInput(player.containerMenu.containerId, confirmSlot, 0, ContainerInput.PICKUP, player);
                tickTimer = actionDelayTicks;
                return;
            }
        }

        // 2. Check if inventory count increased
        int currentCount = countInInventory(player, currentTargetItem);
        int delta = currentCount - prePurchaseCount;

        if (delta > 0) {
            purchasedCounts.merge(currentTargetItem, (long) delta, Long::sum);
            long totalPurchased = purchasedCounts.get(currentTargetItem);
            logChat("§a[AH Buyer] Purchased +" + delta + " " + formatItemName(currentTargetItem) + "! (" + totalPurchased + " acquired)§r");

            if (currentCount >= currentTargetNeeded || totalPurchased >= (activePlan != null ? activePlan.rows().get(currentItemIndex).required() : 0)) {
                statusMessage = "Requirement satisfied for " + formatItemName(currentTargetItem);
                player.closeContainer();
                currentItemIndex++;
                state = State.COOLDOWN;
                tickTimer = actionDelayTicks;
            } else if (freeInventorySlots(player) <= 0) {
                player.closeContainer();
                state = State.WAITING_FOR_SHULKER;
                statusMessage = "Inventory full. Open Shulker Box #" + (activeBoxIndex + 1) + " to pack items.";
                tickTimer = 5;
            } else {
                // Continue buying current item
                state = State.ANALYZING_LISTINGS;
                tickTimer = actionDelayTicks;
            }
            return;
        }

        // 3. Timeout check
        if (timeoutTimer > 40) {
            logChat("§7[AH Buyer] Purchase cycle finished or timed out. Checking next step...§r");
            if (player.containerMenu != null && player.containerMenu != player.inventoryMenu) {
                player.closeContainer();
            }
            state = State.COOLDOWN;
            tickTimer = actionDelayTicks;
        }
    }

    private void handleWaitingForShulker(Minecraft client, LocalPlayer player) {
        if (player.containerMenu instanceof ShulkerBoxMenu) {
            state = State.PACKING_SHULKER;
            tickTimer = 3;
            statusMessage = "Shulker Box open. Packing planned slots for Box #" + (activeBoxIndex + 1) + "...";
            return;
        }

        statusMessage = "Waiting for Shulker Box #" + (activeBoxIndex + 1) + " to be opened...";
    }

    private void handlePackingShulker(Minecraft client, LocalPlayer player, MultiPlayerGameMode gameMode) {
        if (!(player.containerMenu instanceof ShulkerBoxMenu shulkerMenu)) {
            state = State.WAITING_FOR_SHULKER;
            statusMessage = "Shulker box closed. Re-open to resume packing.";
            return;
        }

        if (activeDepot == null || activeBoxIndex >= activeDepot.boxes()) {
            player.closeContainer();
            state = State.COOLDOWN;
            tickTimer = 5;
            return;
        }

        // Find all planned slots for activeBoxIndex
        List<SupplyDepotPlan.Slot> boxSlots = activeDepot.slots().stream()
                .filter(s -> s.box() == activeBoxIndex)
                .toList();

        boolean allSlotsSatisfied = true;
        for (var target : boxSlots) {
            int shulkerSlot = target.slot();
            if (shulkerSlot < 0 || shulkerSlot >= 27) continue;

            ItemStack inBox = shulkerMenu.getSlot(shulkerSlot).getItem();
            String targetId = target.item();
            int targetCount = target.count();

            boolean matches = !inBox.isEmpty() && BuiltInRegistries.ITEM.getKey(inBox.getItem()).toString().equalsIgnoreCase(targetId);
            if (matches && inBox.getCount() >= targetCount) {
                continue; // This slot is fully satisfied
            }

            allSlotsSatisfied = false;

            // Find matching item in player inventory slots (27 to 62)
            int invSlot = findItemInPlayerMenuSlots(shulkerMenu, targetId);
            if (invSlot != -1) {
                statusMessage = "Moving " + formatItemName(targetId) + " into Shulker slot " + (shulkerSlot + 1) + "...";
                // 1. Pick up from player inventory
                gameMode.handleContainerInput(shulkerMenu.containerId, invSlot, 0, ContainerInput.PICKUP, player);
                // 2. Deposit into shulker slot
                gameMode.handleContainerInput(shulkerMenu.containerId, shulkerSlot, 0, ContainerInput.PICKUP, player);
                // 3. If mouse holds remainder, deposit back into player slot
                if (!shulkerMenu.getCarried().isEmpty()) {
                    gameMode.handleContainerInput(shulkerMenu.containerId, invSlot, 0, ContainerInput.PICKUP, player);
                }

                tickTimer = Math.max(3, actionDelayTicks / 2);
                return; // Perform one transfer per cycle for smoothness
            } else {
                // Item not in inventory, need to buy more from /ah
                logChat("§7[AH Buyer] Missing " + formatItemName(targetId) + " for Box #" + (activeBoxIndex + 1) + ". Closing shulker to buy from /ah...§r");
                player.closeContainer();
                state = State.COOLDOWN;
                tickTimer = actionDelayTicks;
                return;
            }
        }

        if (allSlotsSatisfied) {
            completedBoxes.add(activeBoxIndex);
            logChat("§a[AH Buyer] Shulker Box #" + (activeBoxIndex + 1) + " fully packed (27/27 slots)!§r");
            activeBoxIndex++;
            player.closeContainer();

            if (activeBoxIndex >= activeDepot.boxes()) {
                state = State.FINISHED;
                statusMessage = "All " + activeDepot.boxes() + " shulker boxes packed successfully!";
                logChat("§a[AH Buyer] All " + activeDepot.boxes() + " shulkers are fully packed and ready for construction!§r");
            } else {
                state = State.COOLDOWN;
                statusMessage = "Box #" + activeBoxIndex + " packed. Opening next box or sourcing remaining materials...";
                tickTimer = actionDelayTicks;
            }
        }
    }

    /** Manually packs the currently opened shulker box matching activeBoxIndex. */
    public void packCurrentShulkerManual() {
        var mc = Minecraft.getInstance();
        if (mc.player == null || !(mc.player.containerMenu instanceof ShulkerBoxMenu)) {
            statusMessage = "Cannot pack: no Shulker Box is currently open.";
            logChat("§c[AH Buyer] Open a Shulker Box before clicking Pack Shulker.§r");
            return;
        }
        if (activeDepot == null) {
            statusMessage = "Cannot pack: no active schematic depot plan.";
            return;
        }
        state = State.PACKING_SHULKER;
        tickTimer = 0;
        statusMessage = "Manual packing started for Shulker Box #" + (activeBoxIndex + 1) + "...";
    }

    private int findItemInPlayerMenuSlots(ShulkerBoxMenu menu, String targetItemId) {
        // Shulker container slots: 0..26. Player inventory: 27..62
        for (int i = 27; i < menu.slots.size(); i++) {
            ItemStack stack = menu.getSlot(i).getItem();
            if (!stack.isEmpty()) {
                String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
                if (id.equalsIgnoreCase(targetItemId)) {
                    return i;
                }
            }
        }
        return -1;
    }

    private int findNextPageSlot(ChestMenu menu, int containerSize) {
        // Look in bottom row (containerSize - 9 to containerSize - 1)
        for (int i = Math.max(0, containerSize - 9); i < containerSize; i++) {
            ItemStack stack = menu.getSlot(i).getItem();
            if (stack.isEmpty()) continue;
            if (stack.is(Items.ARROW) || stack.is(Items.PAPER)) {
                String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
                if (name.contains("next") || name.contains("page") || name.contains("forward") || name.contains("»")) {
                    return i;
                }
            }
        }
        // Fallback: check slot 53 (standard bottom-right in 54-slot chest)
        if (containerSize >= 54) {
            ItemStack slot53 = menu.getSlot(53).getItem();
            if (!slot53.isEmpty()) {
                return 53;
            }
        }
        return -1;
    }

    private int findConfirmSlot(AbstractContainerMenu menu) {
        for (int i = 0; i < menu.slots.size(); i++) {
            ItemStack stack = menu.getSlot(i).getItem();
            if (stack.isEmpty()) continue;

            String itemId = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
            boolean isGreenItem = itemId.contains("green") || itemId.contains("lime") || itemId.contains("emerald");

            String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
            if (isGreenItem || name.contains("confirm") || name.contains("purchase") || name.contains("buy now") || name.contains("accept")) {
                if (!name.contains("cancel") && !name.contains("back") && !name.contains("decline")) {
                    return i;
                }
            }
        }
        return -1;
    }

    public static double parsePrice(ItemStack stack) {
        if (stack == null || stack.isEmpty()) return Double.MAX_VALUE;

        ItemLore lore = stack.getOrDefault(DataComponents.LORE, ItemLore.EMPTY);
        for (Component c : lore.lines()) {
            String str = c.getString().toLowerCase(Locale.ROOT);
            if (str.contains("price") || str.contains("cost") || str.contains("$") || str.contains("coins")) {
                Double val = extractPriceNumber(str);
                if (val != null) return val;
            }
        }

        String name = stack.getHoverName().getString().toLowerCase(Locale.ROOT);
        if (name.contains("$") || name.contains("coins")) {
            Double val = extractPriceNumber(name);
            if (val != null) return val;
        }

        return 0.0;
    }

    private static Double extractPriceNumber(String text) {
        Matcher m = PRICE_PATTERN.matcher(text);
        while (m.find()) {
            try {
                String numStr = m.group(1).replace(",", "");
                double val = Double.parseDouble(numStr);
                String unit = m.group(2);
                if (unit != null) {
                    switch (unit.toLowerCase(Locale.ROOT)) {
                        case "k" -> val *= 1_000.0;
                        case "m" -> val *= 1_000_000.0;
                        case "b" -> val *= 1_000_000_000.0;
                    }
                }
                if (val > 0) return val;
            } catch (Exception ignored) {}
        }
        return null;
    }

    public static int countInInventory(LocalPlayer player, String targetItem) {
        if (player == null || targetItem == null) return 0;
        int count = 0;
        for (int i = 0; i < player.getInventory().getContainerSize(); i++) {
            ItemStack stack = player.getInventory().getItem(i);
            if (!stack.isEmpty()) {
                String id = BuiltInRegistries.ITEM.getKey(stack.getItem()).toString();
                if (id.equalsIgnoreCase(targetItem)) {
                    count += stack.getCount();
                }
            }
        }
        return count;
    }

    public static int freeInventorySlots(LocalPlayer player) {
        if (player == null) return 0;
        int free = 0;
        for (int i = 9; i < 36; i++) {
            if (player.getInventory().getItem(i).isEmpty()) {
                free++;
            }
        }
        return free;
    }

    private static String formatItemName(String itemId) {
        if (itemId == null) return "item";
        String s = itemId.replace("minecraft:", "").replace('_', ' ');
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    public void onChatMessage(String text) {
        if (!running() || text == null || text.isBlank()) return;

        // Check for DonutSMP purchase confirmation: e.g. "You bought 16 Ender Pearls for $ 4.6K"
        if (text.contains("You bought ") && text.contains(" for $")) {
            Matcher m = Pattern.compile("(?i)You bought\\s+(\\d+)\\s+(.+?)\\s+for\\s+\\$").matcher(text);
            if (m.find()) {
                try {
                    int count = Integer.parseInt(m.group(1));
                    String name = m.group(2).trim();
                    logChat("§a[AH Buyer] Confirmed purchase of " + count + "x " + name + "!§r");
                    if (currentTargetItem != null) {
                        purchasedCounts.merge(currentTargetItem, (long) count, Long::sum);
                    }
                    failedSlotsThisPage.clear();
                    state = State.COOLDOWN;
                    tickTimer = 3;
                    return;
                } catch (Exception ignored) {}
            }
        }

        // Check if listing was already bought by someone else on DonutSMP
        if (text.contains("This item was already bought") || text.contains("Item is no longer available")) {
            if (lastClickedSlot != -1) {
                failedSlotsThisPage.add(lastClickedSlot);
            }
            logChat("§e[AH Buyer] Listing already bought! Snapping to next available listing...§r");
            state = State.ANALYZING_LISTINGS;
            tickTimer = 3;
            return;
        }

        // Check if out of balance
        if (text.contains("You cannot afford") || text.contains("Not enough money") || text.contains("You don't have enough money")) {
            logChat("§c[AH Buyer] Insufficient funds to continue purchasing! Stopping.§r");
            stop();
        }
    }

    public void onPacket(net.minecraft.network.protocol.Packet<?> packet) {
        if (packet instanceof net.minecraft.network.protocol.game.ClientboundSystemChatPacket chat && chat.content() != null) {
            onChatMessage(chat.content().getString());
        }
    }

    private static void logChat(String message) {
        var mc = Minecraft.getInstance();
        if (mc.gui != null && mc.gui.hud != null && mc.gui.hud.getChat() != null) {
            mc.gui.hud.getChat().addClientSystemMessage(Component.literal(message));
        }
    }
}
