package net.spectre.client.module.impl.misc;

import dev.doughbay.fabric.DoughBayClient;
import dev.doughbay.fabric.TallyBridge;
import dev.doughbay.fabric.automation.AutomationSessionController;
import net.minecraft.client.Minecraft;
import net.spectre.client.SpectreClientMod;
import net.spectre.client.gui.ImGuiScreen;
import net.spectre.client.gui.TallyPanel;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.setting.ActionSetting;
import net.spectre.client.module.setting.NumberSetting;
import net.spectre.client.tally.TallyPresets;

/**
 * Tally Trading Module for DonutSMP.
 * Provides active toggle control in ClickGUI, spend limit settings,
 * strategy presets, and direct integration with Tally's automated trading engine.
 */
public final class TallyModule extends ClientModule {

    private static TallyModule instance;

    private final NumberSetting maxPerTrade = this.addSetting("max-per-trade",
            new NumberSetting("Max Spend Per Trade ($M)", 25.0f, 0.1f, 500.0f).step(0.5f));
    private final NumberSetting maxPerSession = this.addSetting("max-per-session",
            new NumberSetting("Max Spend Per Session ($M)", 100.0f, 1.0f, 2000.0f).step(5.0f));
    private final ActionSetting applyStarter = this.addSetting("apply-starter",
            new ActionSetting("Preset: Starter / Low Balance", () -> TallyPresets.apply(TallyPresets.Preset.STARTER_LOW_BALANCE)));
    private final ActionSetting applyWhale = this.addSetting("apply-whale",
            new ActionSetting("Preset: Whale / High Value", () -> TallyPresets.apply(TallyPresets.Preset.WHALE_HIGH_VALUE)));
    private final ActionSetting applyBalanced = this.addSetting("apply-balanced",
            new ActionSetting("Preset: Balanced Default", () -> TallyPresets.apply(TallyPresets.Preset.BALANCED_DEFAULT)));
    private final ActionSetting openSubpanel = this.addSetting("open-subpanel",
            new ActionSetting("Open Tally Subpanel", TallyPanel::open));
    private final ActionSetting openNativeDesk = this.addSetting("open-native-desk",
            new ActionSetting("Open Native Tally Desk", () -> TallyBridge.openDoughBayScreen(Minecraft.getInstance())));

    public TallyModule() {
        super("tally", "Tally Trader", "In-client market analytics, valuation engine, and automated DonutSMP auction house flipper.", ModuleCategory.TALLY);
        instance = this;
    }

    public static TallyModule instance() {
        return instance;
    }

    public static boolean isModuleEnabled() {
        return instance != null && instance.isEnabled();
    }

    public void setLimits(float tradeM, float sessionM) {
        this.maxPerTrade.set(tradeM);
        this.maxPerSession.set(sessionM);
    }

    @Override
    public boolean isAction() {
        return false; // Toggleable module with active switch!
    }

    @Override
    public boolean persistEnabled() {
        return false; // Never auto-enable on client startup
    }

    @Override
    public void onEnable() {
        try {
            TallyBridge.onModuleEnabled();

            long tradeCap = (long) (maxPerTrade.get() * 1_000_000L);
            long sessionCap = (long) (maxPerSession.get() * 1_000_000L);
            String server = "donutsmp.net";
            Minecraft mc = Minecraft.getInstance();
            try {
                if (mc.getCurrentServer() != null && mc.getCurrentServer().ip != null && !mc.getCurrentServer().ip.isBlank()) {
                    server = mc.getCurrentServer().ip.trim();
                } else if (mc.hasSingleplayerServer() || mc.isLocalServer()) {
                    server = "singleplayer";
                }
            } catch (Throwable ignored) {}

            DoughBayClient.setDonutAutomation(true, tradeCap, sessionCap, server);

            var session = DoughBayClient.automationSessionController();
            if (session != null) {
                var snap = session.snapshot();
                if (snap.recoveredSession() && snap.unresolvedExposure()) {
                    session.forceReset(mc);
                } else if (snap.state() == AutomationSessionController.State.PAUSED) {
                    var res = session.resumeFromPlayer();
                    if (res != null && !res.ok()) {
                        session.forceReset(mc);
                    }
                } else if (snap.state() == AutomationSessionController.State.STOPPED) {
                    var policy = DoughBayClient.continuousPolicy();
                    if (policy != null) {
                        var res = session.start(policy, AutomationSessionController.RunMode.CONTINUOUS);
                        if (res != null && !res.ok() && res.detail() != null && res.detail().toLowerCase().contains("recovered")) {
                            session.forceReset(mc);
                            session.start(policy, AutomationSessionController.RunMode.CONTINUOUS);
                        }
                    }
                }
            }
        } catch (Throwable t) {
            SpectreClientMod.LOGGER.error("[Tally] Failed to start trading session: {}", t.getMessage(), t);
        }
    }

    @Override
    public void onDisable() {
        try {
            long tradeCap = (long) (maxPerTrade.get() * 1_000_000L);
            long sessionCap = (long) (maxPerSession.get() * 1_000_000L);
            DoughBayClient.setDonutAutomation(false, tradeCap, sessionCap, "donutsmp.net");
            var session = DoughBayClient.automationSessionController();
            if (session != null && session.snapshot().active()) {
                session.emergencyStop();
            }
            var driver = DoughBayClient.executionDriver();
            if (driver != null && driver.inspect().armed()) {
                driver.emergencyStop();
            }
            Minecraft mc = Minecraft.getInstance();
            if (mc != null && mc.gui != null && mc.gui.screen() != null) {
                String pkg = mc.gui.screen().getClass().getPackageName();
                if (pkg.startsWith("dev.doughbay")) {
                    mc.gui.setScreen(null);
                }
            }
        } catch (Throwable t) {
            SpectreClientMod.LOGGER.error("[Tally] Failed to stop trading session: {}", t.getMessage(), t);
        }
    }

    @Override
    public boolean mascotTaskActive() {
        try {
            var session = DoughBayClient.automationSessionController();
            return session != null && session.snapshot().active();
        } catch (Throwable t) {
            return false;
        }
    }
}
