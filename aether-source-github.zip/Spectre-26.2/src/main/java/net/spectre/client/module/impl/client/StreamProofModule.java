package net.spectre.client.module.impl.client;

import com.mojang.blaze3d.platform.InputConstants;
import java.lang.reflect.Method;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.Minecraft;
import net.spectre.client.chat.ModuleChat;
import net.spectre.client.event.impl.TickEvent;
import net.spectre.client.input.ModuleKeybinds;
import net.spectre.client.module.ClientModule;
import net.spectre.client.module.ModuleCategory;
import net.spectre.client.module.ModuleRegistry;
import net.spectre.client.module.impl.misc.NameProtectModule;
import net.spectre.client.module.impl.misc.NoInvLeakModule;
import net.spectre.client.module.setting.BooleanSetting;
import net.spectre.client.module.setting.KeySetting;
import net.spectre.client.module.setting.ModeSetting;
import org.lwjgl.glfw.GLFW;

@Environment(EnvType.CLIENT)
public final class StreamProofModule extends ClientModule {
   private static volatile StreamProofModule active;
   private final ModeSetting mode = this.addSetting("mode", new ModeSetting("Capture Mode", "OBS Bypass", "OBS Bypass", "Full Stealth"));
   private final BooleanSetting censorCoords = this.addSetting("censor-coords", new BooleanSetting("Censor Coordinates", true));
   private final BooleanSetting protectName = this.addSetting("protect-name", new BooleanSetting("Name Protection", true));
   private final BooleanSetting protectInventory = this.addSetting("protect-inventory", new BooleanSetting("Hide Inventory", false));
   private final BooleanSetting maskServer = this.addSetting("mask-server", new BooleanSetting("Mask Server IP", true));
   private final KeySetting panicKey = this.addSetting("panic-key", new KeySetting("Panic Key", -1));
   private boolean panicWasDown;
   private String lastMode = "";

   public StreamProofModule() {
      super(
         "stream-proof",
         "Stream Proof",
         "Protects your stream by masking sensitive data and excluding overlays from window captures while keeping them visible on your monitor.",
         ModuleCategory.CLIENT
      );
      this.usesNotifications();
   }

   @Override
   protected void onEnable() {
      active = this;
      this.lastMode = this.mode.get();
      this.on(TickEvent.TYPE, this::onTick);

      this.applyWindowAffinity(true);

      if (this.protectName.get()) {
         NameProtectModule nameProtect = ModuleRegistry.get(NameProtectModule.class);
         if (nameProtect != null && !nameProtect.isEnabled()) {
            nameProtect.setEnabled(true);
         }
      }
      if (this.protectInventory.get()) {
         NoInvLeakModule invLeak = ModuleRegistry.get(NoInvLeakModule.class);
         if (invLeak != null && !invLeak.isEnabled()) {
            invLeak.setEnabled(true);
         }
      }
      if (this.notificationsOn()) {
         if ("OBS Bypass".equals(this.mode.get())) {
            ModuleChat.send(this, "Stream Proof active [OBS Bypass]. Overlays visible on screen, sensitive details protected.");
         } else {
            ModuleChat.send(this, "Stream Proof active [Full Stealth]. Client visuals hidden from screen.");
         }
      }
   }

   @Override
   protected void onDisable() {
      active = null;
      this.applyWindowAffinity(false);

      if (this.protectName.get()) {
         NameProtectModule nameProtect = ModuleRegistry.get(NameProtectModule.class);
         if (nameProtect != null && nameProtect.isEnabled()) {
            nameProtect.setEnabled(false);
         }
      }
      if (this.protectInventory.get()) {
         NoInvLeakModule invLeak = ModuleRegistry.get(NoInvLeakModule.class);
         if (invLeak != null && invLeak.isEnabled()) {
            invLeak.setEnabled(false);
         }
      }
   }

   private void onTick(TickEvent event) {
      Minecraft mc = Minecraft.getInstance();
      if (mc != null && mc.getWindow() != null && this.panicKey.value() != -1) {
         boolean down = isDown(mc, this.panicKey.value());
         if (down && !this.panicWasDown && mc.isWindowActive()) {
            this.toggle();
         }
         this.panicWasDown = down;
      }

      String currentMode = this.mode.get();
      if (!currentMode.equals(this.lastMode)) {
         this.lastMode = currentMode;
      }
   }

   private void applyWindowAffinity(boolean enable) {
   }

   private static boolean isDown(Minecraft mc, int key) {
      if (!ModuleKeybinds.isBindable(key)) {
         return false;
      } else {
         return key >= 1000
            ? GLFW.glfwGetMouseButton(mc.getWindow().handle(), key - 1000) == 1
            : InputConstants.isKeyDown(mc.getWindow(), key);
      }
   }

   public static StreamProofModule get() {
      return ModuleRegistry.get(StreamProofModule.class);
   }

   public String getMode() {
      return this.mode.get();
   }

   public static boolean isActive() {
      StreamProofModule module = active;
      return module != null && module.isEnabled();
   }

   public static boolean isHiding3D() {
      StreamProofModule module = active;
      if (module == null || !module.isEnabled()) return false;
      return "Full Stealth".equals(module.mode.get());
   }

   public static boolean isHiding2D() {
      StreamProofModule module = active;
      if (module == null || !module.isEnabled()) return false;
      return "Full Stealth".equals(module.mode.get());
   }

   public static boolean isHidingHud() {
      StreamProofModule module = active;
      if (module == null || !module.isEnabled()) return false;
      return "Full Stealth".equals(module.mode.get());
   }

   public static boolean isHidingToasts() {
      StreamProofModule module = active;
      if (module == null || !module.isEnabled()) return false;
      return "Full Stealth".equals(module.mode.get());
   }

   public static boolean isHidingAlerts() {
      StreamProofModule module = active;
      if (module == null || !module.isEnabled()) return false;
      return "Full Stealth".equals(module.mode.get());
   }

   public static boolean isHidingMenu() {
      return false;
   }

   public static boolean isHidingChat() {
      StreamProofModule module = active;
      if (module == null || !module.isEnabled()) return false;
      return "Full Stealth".equals(module.mode.get());
   }

   public static boolean isCensoringCoords() {
      StreamProofModule module = active;
      return module != null && module.isEnabled() && module.censorCoords.get();
   }

   public static boolean isNameProtectionEnabled() {
      StreamProofModule module = active;
      return module != null && module.isEnabled() && module.protectName.get();
   }

   public static boolean isMaskingServer() {
      StreamProofModule module = active;
      return module != null && module.isEnabled() && module.maskServer.get();
   }
}
