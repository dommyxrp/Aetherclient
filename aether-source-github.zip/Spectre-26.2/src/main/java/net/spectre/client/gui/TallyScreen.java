package net.spectre.client.gui;

import dev.doughbay.fabric.DoughBayClient;
import dev.doughbay.fabric.TallyBridge;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

/**
 * Dedicated Minecraft Screen for Tally Trading Desk.
 * Allows launching either the ClickGUI Subpanel or the full native DoughBay Desk.
 */
public final class TallyScreen extends Screen {

    public TallyScreen() {
        super(Component.literal("Tally Trading Desk"));
    }

    @Override
    protected void init() {
        TallyBridge.ensureInitialized();
        int btnW = 150, btnH = 20;
        int y = this.height - 32;

        addRenderableWidget(Button.builder(Component.literal("Open ClickGUI Subpanel"), b -> {
            onClose();
            TallyPanel.open();
            minecraft.gui.setScreen(new ImGuiScreen());
        }).bounds(16, y, btnW, btnH).build());

        addRenderableWidget(Button.builder(Component.literal("Open Native Tally Desk"), b -> {
            onClose();
            TallyBridge.openDoughBayScreen(minecraft);
        }).bounds(174, y, btnW, btnH).build());

        addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose())
                .bounds(this.width - btnW - 16, y, btnW, btnH).build());
    }

    @Override
    public void extractBackground(GuiGraphicsExtractor g, int mx, int my, float tick) {
        g.fill(0, 0, width, height, 0xF00A0F17);
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float delta) {
        var session = TallyBridge.sessionSnapshot();
        var market = TallyBridge.marketSnapshot();
        var ledger = TallyBridge.ledgerSnapshot();

        // Header
        g.text(this.font, "TALLY TRADING DESK // DONUTSMP ENGINE", 16, 14, 0xFF72E6EF, false);
        String state = session != null ? session.state().name() : "OFFLINE";
        g.text(this.font, "Engine State: " + state + " • Automated Execution & Valuation Engine", 16, 26, 0xFF94A3B8, false);

        // Key stats
        int y = 50;
        g.fill(16, y, width - 16, y + 42, 0x50101824);

        long profit = ledger != null ? ledger.realizedProfit() : 0;
        int oppCount = market != null && market.opportunities() != null ? market.opportunities().size() : 0;
        long balance = market != null ? market.accountBalance() : 0;

        String statLine = String.format("Realized Profit: +$%s   |   Active Signals: %d Flips   |   DonutSMP Balance: %s",
                TallyPanel.formatMoney(profit), oppCount, balance > 0 ? ("$" + TallyPanel.formatMoney(balance)) : "Auto-Tracking");
        g.text(this.font, statLine, 24, y + 16, 0xFFF8FAFC, false);

        y += 56;
        g.text(this.font, "Active Opportunities:", 16, y, 0xFF72E6EF, false);
        y += 14;

        if (market == null || market.opportunities() == null || market.opportunities().isEmpty()) {
            g.text(this.font, "Scanning order books for underpriced listings...", 24, y, 0xFF64748B, false);
        } else {
            int shown = Math.min(5, market.opportunities().size());
            for (int i = 0; i < shown; i++) {
                var opp = market.opportunities().get(i);
                String itemName = opp.listing() != null ? TallyPanel.formatItemName(opp.listing().itemKey()) : "Item";
                String line = String.format("• %s | Buy: $%s -> Target: $%s | Profit: +$%s (%.1f%% ROI)",
                        itemName, TallyPanel.formatMoney(opp.buyPrice()),
                        TallyPanel.formatMoney(opp.recommendedSellPrice()),
                        TallyPanel.formatMoney((long) opp.expectedNetProfit()),
                        opp.expectedRoiPercent());
                g.text(this.font, line, 24, y, 0xFF94A3B8, false);
                y += 14;
            }
        }
    }
}
