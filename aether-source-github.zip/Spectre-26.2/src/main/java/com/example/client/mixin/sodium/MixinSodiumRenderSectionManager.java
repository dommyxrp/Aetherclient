package com.example.client.mixin.sodium;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.core.SectionPos;
import net.spectre.client.module.impl.misc.FreecamModule;
import net.spectre.client.module.impl.render.FreelookModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Pseudo
@Mixin(targets = "net.caffeinemc.mods.sodium.client.render.chunk.RenderSectionManager")
public abstract class MixinSodiumRenderSectionManager {

   @ModifyVariable(method = "finalizeRenderLists", at = @At("HEAD"), argsOnly = true, ordinal = 0)
   private boolean spectre$forceRenderOutOfGraphInFreecam(boolean updateChunksImmediately) {
      if (FreecamModule.active != null || FreelookModule.throughBlocks()) {
         return true;
      }
      return updateChunksImmediately;
   }

   @Inject(method = "isOutOfGraph", at = @At("HEAD"), cancellable = true)
   private void spectre$outOfGraphInFreecam(SectionPos pos, CallbackInfoReturnable<Boolean> cir) {
      if (FreecamModule.active != null || FreelookModule.throughBlocks()) {
         cir.setReturnValue(true);
      }
   }

   @Inject(method = "isBoxVisible", at = @At("HEAD"), cancellable = true)
   private void spectre$boxVisibleInFreecam(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, CallbackInfoReturnable<Boolean> cir) {
      if (FreecamModule.active != null || FreelookModule.throughBlocks()) {
         cir.setReturnValue(true);
      }
   }
}
