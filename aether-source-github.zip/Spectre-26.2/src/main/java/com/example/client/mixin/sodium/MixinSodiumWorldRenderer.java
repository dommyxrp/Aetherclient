package com.example.client.mixin.sodium;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.spectre.client.module.impl.misc.FreecamModule;
import net.spectre.client.module.impl.render.FreelookModule;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Environment(EnvType.CLIENT)
@Pseudo
@Mixin(targets = "net.caffeinemc.mods.sodium.client.render.SodiumWorldRenderer")
public abstract class MixinSodiumWorldRenderer {

   @Inject(method = "isSectionReady", at = @At("HEAD"), cancellable = true)
   private void spectre$sectionReadyInFreecam(int x, int y, int z, CallbackInfoReturnable<Boolean> cir) {
      if (FreecamModule.active != null || FreelookModule.throughBlocks()) {
         cir.setReturnValue(true);
      }
   }

   @Inject(method = "isBoxVisible", at = @At("HEAD"), cancellable = true)
   private void spectre$worldBoxVisibleInFreecam(double minX, double minY, double minZ, double maxX, double maxY, double maxZ, CallbackInfoReturnable<Boolean> cir) {
      if (FreecamModule.active != null || FreelookModule.throughBlocks()) {
         cir.setReturnValue(true);
      }
   }

   @Inject(method = "isEntityVisible", at = @At("HEAD"), cancellable = true)
   private void spectre$entityVisibleInFreecam(CallbackInfoReturnable<Boolean> cir) {
      if (FreecamModule.active != null || FreelookModule.throughBlocks()) {
         cir.setReturnValue(true);
      }
   }
}
